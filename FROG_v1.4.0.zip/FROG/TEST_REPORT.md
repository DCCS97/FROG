# FROG v1.4.0 Test Report

Test date: 2026-07-13  
Environment: Linux/Python test environment. The Windows PyInstaller executable must still be built and executed on Windows.

## Automated suite

Command:

```text
python -m unittest discover -s tests -v
```

Result:

```text
Ran 37 tests in 0.220s
OK
```

Coverage includes:

- Seed reproducibility and repeated-value consistency
- Later-occurrence gender cues for full names
- Label-anchored account-number behaviour
- Luhn-valid card generation
- Labelled-invalid versus unlabelled-invalid IBAN handling
- UK IBAN/sort-code/account-number relationship preservation
- Compact sort codes in XML, JSON and Splunk key/value data
- XML namespaces, attributes and CDATA
- HTML-escaped and double-escaped XML detection
- Broken entities and XML tag names split by display wrapping
- Surname, first-name and middle-name structured fields
- Full DOB aliases and split `DD` / `MM` / `YY` / `YYYY` components
- One valid synthetic date shared by adjacent split DOB components
- Labelled client/originating IP addresses and MAC addresses
- Irish and Spanish IBAN country/length/checksum preservation
- International telephone calling-country preservation
- Independent address-country contexts in adjacent JSON objects
- Persistent non-sensitive preferences with seed exclusion
- JSON/XML pretty-printing and plain-log layout preservation
- Dual-pane input/output pretty-printing
- Custom rules and known-names file support

## Reported escaped Bank Wizard-style regression

Input excerpt:

```text
xmlns:bwa="http://api.bankwizardabsolute.com/dataverification/types"&gt;&lt;REQUEST
t;&lt;SURNAME&gt;DAVIS&lt;/SURNAME&gt;&lt;DATEOFBIRTH_DD&gt;19&lt;/DATEOFBIRTH_DD&gt;&lt;DAT
SER_ID&gt;CROSSCOREBWAPROD01&lt;/USER_ID&gt;
```

With seed `INC123456789`, FROG now detects the escaped tags despite the malformed outer payload and changes the available PII while leaving unrelated operational fields intact:

```text
...&lt;SURNAME&gt;BARKER&lt;/SURNAME&gt;&lt;DATEOFBIRTH_DD&gt;25&lt;/DATEOFBIRTH_DD&gt;...
...CROSSCOREBWAPROD01...
```

The exact malformed payload supplied by the user is retained as an automated regression test.

## Split DOB consistency demonstration

Input:

```text
&lt;SURNAME&gt;DAVIS&lt;/SURNAME&gt;
&lt;DATEOFBIRTH_DD&gt;19&lt;/DATEOFBIRTH_DD&gt;
&lt;DATEOFBIRTH_MM&gt;07&lt;/DATEOFBIRTH_MM&gt;
&lt;DATEOFBIRTH_YYYY&gt;1984&lt;/DATEOFBIRTH_YYYY&gt;
```

With seed `INC123456789`:

```text
&lt;SURNAME&gt;BARKER&lt;/SURNAME&gt;
&lt;DATEOFBIRTH_DD&gt;07&lt;/DATEOFBIRTH_DD&gt;
&lt;DATEOFBIRTH_MM&gt;02&lt;/DATEOFBIRTH_MM&gt;
&lt;DATEOFBIRTH_YYYY&gt;1969&lt;/DATEOFBIRTH_YYYY&gt;
```

The generated date `07/02/1969` is calendar-valid and all three fields are derived from the same deterministic synthetic date.

## Detection-view behaviour

FROG v1.4.0 creates a temporary detection-only view when escaped markup is present. It can:

1. Decode common HTML/XML entities such as `&lt;`, `&gt;`, `&quot;` and numeric entities.
2. Decode two common layers of escaping, such as `&amp;lt;SURNAME&amp;gt;`.
3. Repair an entity split by a display newline, such as `&g\nt;`.
4. Repair a newline splitting an XML field name, such as `<DATEOFBIRTH_\nDD>`.
5. Map every detected character back to the source offsets.
6. Replace only the source value, preserving the original escaping and line layout.

The decoded view is never copied, saved or shown as the user's log unless the separate Pretty Print feature intentionally reformats a supported payload.

## Network-identifier demonstration

Labelled client IP and MAC values are scrubbed:

```text
&lt;IP_ADDRESS_ORIG_CLIENT&gt;82.165.43.101&lt;/IP_ADDRESS_ORIG_CLIENT&gt;
&lt;CLIENT_MAC_ADDRESS&gt;00:11:22:33:44:55&lt;/CLIENT_MAC_ADDRESS&gt;
```

Example generated forms:

```text
&lt;IP_ADDRESS_ORIG_CLIENT&gt;192.0.2.212&lt;/IP_ADDRESS_ORIG_CLIENT&gt;
&lt;CLIENT_MAC_ADDRESS&gt;B6:3D:55:AD:A4:02&lt;/CLIENT_MAC_ADDRESS&gt;
```

Public IPv4 values use the documentation-only `192.0.2.0/24` range. Synthetic MAC values use the locally administered/unicast bits rather than a real manufacturer OUI.

## GUI smoke test

Command:

```text
xvfb-run -a python main.py --smoke-test
```

Result:

```text
GUI_SMOKE_OK
```

The tkinter application launched, exercised all four visual profiles, auto-scrubbed a pasted payload, formatted both panes, restored the original input layout and closed without an exception.

## Performance checks

Representative local benchmark in this environment:

```text
1,250,000 plain-log characters / 50,000 detections: 4.518 seconds
420,000 escaped-XML characters / 10,000 detections: 2.159 seconds
```

These figures are environment-specific and are not a formal Windows performance guarantee.

## Packaging status

The Python source, 37-test suite and headless GUI launch were verified here. A genuine Windows `.exe` cannot be built or executed in this Linux environment. Run `build_windows_exe.bat` on Windows to create `dist\FROG.exe`.

## Known limitations

- No rule-based program can guarantee detection of every possible PII representation.
- The new normalisation layer handles common escaped/double-escaped markup and obvious display-wrap damage; severely truncated tags may remain impossible to interpret reliably.
- Empty fields such as `<IP_ADDRESS_ORIG_CLIENT />` contain no value to replace.
- Generic `USER_ID` fields are not automatically scrubbed because they frequently identify system/service accounts rather than people. Add an organisation-specific custom rule where required.
- Output must still receive a final visual review before being shared.
- FROG remains a local risk-reduction/pseudonymisation aid rather than a certified DLP control.
