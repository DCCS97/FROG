@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\pythonw.exe" (
  start "" ".venv\Scripts\pythonw.exe" main.py
  exit /b 0
)
where pyw >nul 2>&1
if not errorlevel 1 (
  start "" pyw main.py
  exit /b 0
)
where pythonw >nul 2>&1
if not errorlevel 1 (
  start "" pythonw main.py
  exit /b 0
)
echo FROG is not set up yet. Run setup_no_admin.bat first.
pause
