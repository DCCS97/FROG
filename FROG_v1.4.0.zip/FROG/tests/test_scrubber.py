from __future__ import annotations

import re
import tempfile
import unittest
from pathlib import Path

from frog.engine import REDACT_PREAMBLE, SYNTHETIC_PREAMBLE, Scrubber
from frog.generators import canonical_phone, digits_only, iban_is_valid, luhn_is_valid


class ScrubberTests(unittest.TestCase):
    def setUp(self) -> None:
        self.scrubber = Scrubber()

    def test_consistency_and_gender_cue_on_later_occurrence(self) -> None:
        source = (
            "2026-07-13 09:00 Customer Name: Alex Morgan\n"
            "2026-07-13 09:02 profile lookup completed for Alex Morgan\n"
            "2026-07-13 09:04 Alex Morgan called back; she confirmed the failed payment was hers.\n"
        )
        result = self.scrubber.scrub(source, seed="case-42", include_preamble=False)
        name_entries = [entry for entry in result.mapping if entry.kind == "NAME"]
        self.assertEqual(len(name_entries), 1)
        entry = name_entries[0]
        self.assertEqual(entry.occurrences, 3)
        self.assertEqual(entry.metadata.get("gender"), "female")
        self.assertNotIn("Alex Morgan", result.text)
        self.assertEqual(result.text.count(entry.fake), 3)

    def test_seed_is_reproducible(self) -> None:
        source = "Email: user@example.org\nSort code: 12-34-56\n"
        first = self.scrubber.scrub(source, seed="same-case", include_preamble=False)
        second = self.scrubber.scrub(source, seed="same-case", include_preamble=False)
        other = self.scrubber.scrub(source, seed="different-case", include_preamble=False)
        self.assertEqual(first.text, second.text)
        self.assertNotEqual(first.text, other.text)

    def test_card_is_luhn_valid_and_preserves_digit_count(self) -> None:
        source = "card=4111 1111 1111 1111"
        result = self.scrubber.scrub(source, seed="cards", include_preamble=False)
        card = next(entry for entry in result.mapping if entry.kind == "CARD_NUMBER")
        self.assertTrue(luhn_is_valid(card.fake))
        self.assertEqual(len(digits_only(card.fake)), 16)
        self.assertRegex(card.fake, r"^\d{4} \d{4} \d{4} \d{4}$")

    def test_account_number_requires_label(self) -> None:
        source = "trace=12345678 Account Number: 87654321"
        result = self.scrubber.scrub(source, mode="redact", include_preamble=False)
        self.assertIn("trace=12345678", result.text)
        self.assertNotIn("87654321", result.text)
        self.assertEqual(sum(entry.kind == "ACCOUNT_NUMBER" for entry in result.mapping), 1)

    def test_iban_replacement_is_valid_and_same_shape(self) -> None:
        source = "IBAN: GB82 WEST 1234 5698 7654 32"
        result = self.scrubber.scrub(source, seed="iban", include_preamble=False)
        entry = next(item for item in result.mapping if item.kind == "IBAN")
        self.assertTrue(iban_is_valid(entry.fake))
        self.assertEqual(len(entry.fake), len("GB82 WEST 1234 5698 7654 32"))

    def test_labelled_invalid_checksum_iban_is_still_scrubbed(self) -> None:
        source = '"iban": "GB29BARC20451288102938",'
        self.assertFalse(iban_is_valid("GB29BARC20451288102938"))

        result = self.scrubber.scrub(source, seed="json-iban", include_preamble=False)

        entries = [item for item in result.mapping if item.kind == "IBAN"]
        self.assertEqual(len(entries), 1)
        self.assertNotIn("GB29BARC20451288102938", result.text)
        self.assertTrue(iban_is_valid(entries[0].fake))
        self.assertEqual(len(entries[0].fake), len("GB29BARC20451288102938"))

    def test_unlabelled_invalid_checksum_iban_shape_is_not_scrubbed(self) -> None:
        source = "downstream token GB29BARC20451288102938 was rejected"
        result = self.scrubber.scrub(source, seed="json-iban", include_preamble=False)
        self.assertEqual(result.text, source)
        self.assertFalse(any(item.kind == "IBAN" for item in result.mapping))

    def test_json_routing_data_scrubs_iban_sort_code_and_account_number(self) -> None:
        source = (
            '"routing_data": {\n'
            '  "sort_code": "20-45-12",\n'
            '  "account_number": "88102938",\n'
            '  "iban": "GB29BARC20451288102938"\n'
            '}'
        )
        result = self.scrubber.scrub(source, seed="reported-case", include_preamble=False)

        self.assertNotIn("20-45-12", result.text)
        self.assertNotIn("88102938", result.text)
        self.assertNotIn("GB29BARC20451288102938", result.text)
        self.assertEqual(result.stats.get("SORT_CODE"), 1)
        self.assertEqual(result.stats.get("ACCOUNT_NUMBER"), 1)
        self.assertEqual(result.stats.get("IBAN"), 1)

        fake_sort = next(item.fake for item in result.mapping if item.kind == "SORT_CODE")
        fake_account = next(item.fake for item in result.mapping if item.kind == "ACCOUNT_NUMBER")
        fake_iban = next(item.fake for item in result.mapping if item.kind == "IBAN")
        compact_iban = re.sub(r"[^A-Z0-9]", "", fake_iban.upper())
        self.assertEqual(compact_iban[8:14], digits_only(fake_sort))
        self.assertEqual(compact_iban[14:22], digits_only(fake_account))
        self.assertTrue(iban_is_valid(fake_iban))
        self.assertIn("RELATIONSHIP: embeds the matching fake sort code/account number", result.mapping_text())

    def test_known_names_file_catches_unlabelled_name(self) -> None:
        source = "Escalated by Sam O'Neil after timeout."
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "names.txt"
            path.write_text("Sam O'Neil\n", encoding="utf-8")
            result = self.scrubber.scrub(source, seed="known", include_preamble=False, known_names_path=path)
        self.assertNotIn("Sam O'Neil", result.text)
        self.assertEqual(result.mapping[0].kind, "NAME")

    def test_preamble_is_mode_aware(self) -> None:
        source = "Email: user@example.org"
        synthetic = self.scrubber.scrub(source, seed="x", mode="synthetic", include_preamble=True)
        redacted = self.scrubber.scrub(source, seed="x", mode="redact", include_preamble=True)
        self.assertTrue(synthetic.text.startswith(SYNTHETIC_PREAMBLE))
        self.assertTrue(redacted.text.startswith(REDACT_PREAMBLE))

    def test_redaction_placeholder_is_consistent(self) -> None:
        source = "Customer Name: John Smith\nMr John Smith called.\n"
        result = self.scrubber.scrub(source, mode="redact", include_preamble=False)
        placeholders = re.findall(r"\[NAME_\d+\]", result.text)
        self.assertEqual(len(placeholders), 2)
        self.assertEqual(len(set(placeholders)), 1)

    def test_same_phone_in_local_and_international_format_stays_linked(self) -> None:
        source = "mobile=07700 900123 alternate=+44 7700 900123"
        result = self.scrubber.scrub(source, seed="phones", include_preamble=False)
        entries = [entry for entry in result.mapping if entry.kind == "PHONE"]
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0].occurrences, 2)
        self.assertEqual(len(entries[0].rendered_fakes), 2)
        self.assertRegex(result.text, r"0\d{4} \d{6}")
        self.assertRegex(result.text, r"\+44 \d{4} \d{6}")

    def test_custom_rule_file_is_loaded_without_core_changes(self) -> None:
        custom_json = r"""[
          {"name":"case_id","kind":"CASE_ID","regex":"caseId\\s*[:=]\\s*(?P<value>CASE-[A-Z0-9]{6})","generator":"mask"}
        ]"""
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "custom_rules.json"
            path.write_text(custom_json, encoding="utf-8")
            result = Scrubber(path).scrub("caseId=CASE-AB12CD", seed="custom", include_preamble=False)
        self.assertNotIn("CASE-AB12CD", result.text)
        self.assertEqual(result.mapping[0].kind, "CASE_ID")

    def test_labelled_account_can_end_with_full_stop(self) -> None:
        result = self.scrubber.scrub("Account Number: 87654321.", mode="redact", include_preamble=False)
        self.assertIn("[ACCOUNT_NUMBER_1].", result.text)


    def test_compact_sort_code_inside_xml_tag_is_scrubbed(self) -> None:
        source = "<sortcode>123456</sortcode>"
        result = self.scrubber.scrub(source, seed="INC123456789", include_preamble=False)

        self.assertNotIn("123456", result.text)
        self.assertRegex(result.text, r"^<sortcode>\d{6}</sortcode>$")
        self.assertEqual(result.stats.get("SORT_CODE"), 1)
        entry = next(item for item in result.mapping if item.kind == "SORT_CODE")
        self.assertEqual(len(digits_only(entry.fake)), 6)

    def test_xml_elements_scrub_all_supported_structured_pii(self) -> None:
        source = (
            "<customerProfile>\n"
            "  <accountHolder>Marcus Vance-Delgado</accountHolder>\n"
            "  <emailAddress>m.vancedelgado@protonmail.com</emailAddress>\n"
            "  <phoneNumber>447700900077</phoneNumber>\n"
            "  <nationalInsuranceNumber>AB123456C</nationalInsuranceNumber>\n"
            "  <postalCode>M3 2ER</postalCode>\n"
            "  <dateOfBirth>04/11/1985</dateOfBirth>\n"
            "  <cardNumber>4111111111111111</cardNumber>\n"
            "  <sortCode>123456</sortCode>\n"
            "  <accountNumber>12345678</accountNumber>\n"
            "  <iban>GB00BARC12345612345678</iban>\n"
            "</customerProfile>\n"
            "Marcus Vance-Delgado confirmed that he owns the account.\n"
        )
        result = self.scrubber.scrub(source, seed="xml-all-fields", include_preamble=False)

        for original in (
            "Marcus Vance-Delgado",
            "m.vancedelgado@protonmail.com",
            "447700900077",
            "AB123456C",
            "M3 2ER",
            "04/11/1985",
            "4111111111111111",
            "123456",
            "12345678",
            "GB00BARC12345612345678",
        ):
            self.assertNotIn(original, result.text)

        for tag in (
            "accountHolder",
            "emailAddress",
            "phoneNumber",
            "nationalInsuranceNumber",
            "postalCode",
            "dateOfBirth",
            "cardNumber",
            "sortCode",
            "accountNumber",
            "iban",
        ):
            self.assertIn(f"<{tag}>", result.text)
            self.assertIn(f"</{tag}>", result.text)

        expected_kinds = {
            "NAME",
            "EMAIL",
            "PHONE",
            "NINO",
            "POSTCODE",
            "DATE_OF_BIRTH",
            "CARD_NUMBER",
            "SORT_CODE",
            "ACCOUNT_NUMBER",
            "IBAN",
        }
        self.assertTrue(expected_kinds.issubset({entry.kind for entry in result.mapping}))
        name = next(entry for entry in result.mapping if entry.kind == "NAME")
        self.assertEqual(name.metadata.get("gender"), "male")

        fake_sort = next(entry.fake for entry in result.mapping if entry.kind == "SORT_CODE")
        fake_account = next(entry.fake for entry in result.mapping if entry.kind == "ACCOUNT_NUMBER")
        fake_iban = next(entry.fake for entry in result.mapping if entry.kind == "IBAN")
        compact_iban = re.sub(r"[^A-Z0-9]", "", fake_iban.upper())
        self.assertEqual(compact_iban[8:14], digits_only(fake_sort))
        self.assertEqual(compact_iban[14:22], digits_only(fake_account))
        self.assertTrue(iban_is_valid(fake_iban))

    def test_namespaced_xml_attributes_and_cdata_are_scrubbed(self) -> None:
        source = (
            '<bank:payment bank:sortCode="654321" accountNumber="87654321" '
            'email="person@example.org">\n'
            '  <bank:iban><![CDATA[GB00BARC65432187654321]]></bank:iban>\n'
            '  <bank:phone><![CDATA[0044 7700 900123]]></bank:phone>\n'
            '</bank:payment>'
        )
        result = self.scrubber.scrub(source, seed="xml-variants", include_preamble=False)

        for original in (
            "654321",
            "87654321",
            "person@example.org",
            "GB00BARC65432187654321",
            "0044 7700 900123",
        ):
            self.assertNotIn(original, result.text)
        self.assertIn("<bank:iban><![CDATA[", result.text)
        self.assertIn("]]></bank:iban>", result.text)
        self.assertIn('bank:sortCode="', result.text)
        self.assertIn('accountNumber="', result.text)

    def test_compact_sort_code_in_json_and_splunk_key_value_is_scrubbed(self) -> None:
        source = '"sort_code":"123456" sortCode=654321 bank-sort-code|112233'
        result = self.scrubber.scrub(source, seed="compact-sort", include_preamble=False)

        self.assertNotIn("123456", result.text)
        self.assertNotIn("654321", result.text)
        self.assertNotIn("112233", result.text)
        self.assertEqual(result.stats.get("SORT_CODE"), 3)

    def test_bare_44_phone_links_to_local_and_plus_44_forms(self) -> None:
        source = (
            "<phone>447700900123</phone> "
            "mobile=07700 900123 alternate=+44 7700 900123"
        )
        result = self.scrubber.scrub(source, seed="phone-formats", include_preamble=False)
        entries = [entry for entry in result.mapping if entry.kind == "PHONE"]

        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0].occurrences, 3)
        self.assertNotIn("447700900123", result.text)
        self.assertNotIn("07700 900123", result.text)
        self.assertNotIn("+44 7700 900123", result.text)

    def test_dob_aliases_include_dob_and_camel_case_date_of_birth(self) -> None:
        source = (
            "<dob>04/11/1985</dob> "
            'dateOfBirth="1985-11-04" '
            "birth-date=04-11-1985"
        )
        result = self.scrubber.scrub(source, seed="dob-aliases", include_preamble=False)
        self.assertNotIn("04/11/1985", result.text)
        self.assertNotIn("1985-11-04", result.text)
        self.assertNotIn("04-11-1985", result.text)
        self.assertEqual(result.stats.get("DATE_OF_BIRTH"), 3)

    def test_international_ibans_preserve_country_length_shape_and_checksum(self) -> None:
        source = (
            'spanishIban="ES9121000418450200051332" '
            '<iban>IE29AIBK93115212345678</iban>'
        )
        result = self.scrubber.scrub(source, seed="international-ibans", include_preamble=False)
        entries = [entry for entry in result.mapping if entry.kind == "IBAN"]
        self.assertEqual(len(entries), 2)
        by_country = {re.sub(r"[^A-Z0-9]", "", entry.fake.upper())[:2]: entry for entry in entries}
        self.assertEqual(set(by_country), {"ES", "IE"})
        self.assertEqual(len(re.sub(r"[^A-Z0-9]", "", by_country["ES"].fake)), 24)
        self.assertEqual(len(re.sub(r"[^A-Z0-9]", "", by_country["IE"].fake)), 22)
        self.assertTrue(iban_is_valid(by_country["ES"].fake))
        self.assertTrue(iban_is_valid(by_country["IE"].fake))

    def test_international_phone_keeps_calling_country_and_local_defaults_to_gb(self) -> None:
        source = "mobile=+48 512 345 678 backup=07700 900123"
        result = self.scrubber.scrub(source, seed="international-phones", include_preamble=False)
        entries = [entry for entry in result.mapping if entry.kind == "PHONE"]
        self.assertEqual(len(entries), 2)
        polish = next(entry for entry in entries if entry.metadata.get("country_code") == "PL")
        british = next(entry for entry in entries if entry.metadata.get("country_code") == "GB")
        self.assertTrue(polish.fake.startswith("+48"))
        self.assertTrue(canonical_phone(polish.fake).startswith("+48"))
        self.assertTrue(british.fake.startswith("0"))

    def test_addresses_keep_their_own_country_context_independently_of_iban(self) -> None:
        source = '''{
          "irish_address": {
            "street": "12 O'Connell Street",
            "city": "Dublin",
            "postal_code": "D02 X285",
            "country": "Ireland"
          },
          "iban": "IE29AIBK93115212345678",
          "uk_address": {
            "street": "82 Deansgate",
            "city": "Manchester",
            "postal_code": "M3 2ER",
            "country": "United Kingdom"
          }
        }'''
        result = self.scrubber.scrub(source, seed="mixed-origin", include_preamble=False)
        self.assertNotIn("O'Connell Street", result.text)
        self.assertNotIn("Deansgate", result.text)
        self.assertIn('"country": "Ireland"', result.text)
        self.assertIn('"country": "United Kingdom"', result.text)
        address_entries = [
            entry for entry in result.mapping if entry.kind in {"STREET_ADDRESS", "CITY", "POSTCODE"}
        ]
        self.assertEqual(
            [entry.metadata.get("country_code") for entry in address_entries].count("IE"),
            3,
        )
        self.assertEqual(
            [entry.metadata.get("country_code") for entry in address_entries].count("GB"),
            3,
        )
        iban = next(entry for entry in result.mapping if entry.kind == "IBAN")
        self.assertEqual(iban.metadata.get("country_code"), "IE")

    def test_pretty_print_formats_json_but_plain_mode_preserves_layout(self) -> None:
        source = '{"email":"person@example.org","nested":{"sortCode":"123456"}}'
        plain = self.scrubber.scrub(
            source, seed="pretty", include_preamble=False, pretty_print=False
        )
        pretty = self.scrubber.scrub(
            source, seed="pretty", include_preamble=False, pretty_print=True
        )
        self.assertNotIn("\n", plain.text)
        self.assertIn("\n  ", pretty.text)
        self.assertEqual(pretty.format_name, "json")
        self.assertTrue(pretty.syntax_spans)

    def test_pretty_print_leaves_unrecognised_plain_log_unchanged(self) -> None:
        source = "2026-07-13 INFO ordinary unstructured line"
        result = self.scrubber.scrub(
            source, seed="pretty-plain", include_preamble=False, pretty_print=True
        )
        self.assertEqual(result.text, source)
        self.assertEqual(result.format_name, "plain")

    def test_pretty_print_auto_detects_xml(self) -> None:
        source = '<customer><dob>04/11/1985</dob><email>person@example.org</email></customer>'
        result = self.scrubber.scrub(
            source, seed="pretty-xml", include_preamble=False, pretty_print=True
        )
        self.assertEqual(result.format_name, "xml")
        self.assertIn("\n  <dob>", result.text)
        self.assertNotIn("04/11/1985", result.text)
        self.assertNotIn("person@example.org", result.text)

    def test_html_escaped_xml_scrubs_surname_and_split_dob_components(self) -> None:
        source = (
            'xmlns:bwa="http://api.bankwizardabsolute.com/dataverification/types"'
            '&gt;&lt;REQUEST&gt;&lt;SURNAME&gt;DAVIS&lt;/SURNAME&gt;'
            '&lt;DATEOFBIRTH_\nDD&gt;19&lt;/DATEOFBIRTH_DD&gt;'
            '&lt;DATEOFBIRTH_MM&gt;07&lt;/DATEOFBIRTH_MM&gt;'
            '&lt;DATEOFBIRTH_YYYY&gt;1984&lt;/DATEOFBIRTH_YYYY&gt;'
            '&lt;/REQUEST&gt;'
        )
        result = self.scrubber.scrub(
            source, seed="INC123456789", include_preamble=False
        )

        self.assertNotIn("DAVIS", result.text)
        self.assertNotIn("DD&gt;19&lt;/DATEOFBIRTH_DD", result.text)
        self.assertNotIn("MM&gt;07&lt;/DATEOFBIRTH_MM", result.text)
        self.assertNotIn("YYYY&gt;1984&lt;/DATEOFBIRTH_YYYY", result.text)
        self.assertIn("&lt;SURNAME&gt;", result.text)
        self.assertIn("&lt;DATEOFBIRTH_\nDD&gt;", result.text)
        self.assertEqual(result.stats.get("SURNAME"), 1)
        self.assertEqual(result.stats.get("DATE_OF_BIRTH_DAY"), 1)
        self.assertEqual(result.stats.get("DATE_OF_BIRTH_MONTH"), 1)
        self.assertEqual(result.stats.get("DATE_OF_BIRTH_YEAR"), 1)

        fake_day = next(
            entry.fake for entry in result.mapping if entry.kind == "DATE_OF_BIRTH_DAY"
        )
        fake_month = next(
            entry.fake for entry in result.mapping if entry.kind == "DATE_OF_BIRTH_MONTH"
        )
        fake_year = next(
            entry.fake for entry in result.mapping if entry.kind == "DATE_OF_BIRTH_YEAR"
        )
        from datetime import date

        date(int(fake_year), int(fake_month), int(fake_day))

    def test_double_escaped_and_broken_entity_markup_is_detected(self) -> None:
        source = (
            "&amp;lt;SURNAME&amp;gt;DAVIS&amp;lt;/SURNAME&amp;gt; "
            "&lt;SURNAME&g\nt;SMITH&lt;/SURNAME&gt;"
        )
        result = self.scrubber.scrub(source, seed="escaped", include_preamble=False)
        self.assertNotIn("DAVIS", result.text)
        self.assertNotIn("SMITH", result.text)
        self.assertEqual(result.stats.get("SURNAME"), 2)
        self.assertIn("&amp;lt;SURNAME&amp;gt;", result.text)
        self.assertIn("&lt;SURNAME&g\nt;", result.text)

    def test_labelled_client_ip_and_mac_are_scrubbed_in_escaped_xml(self) -> None:
        source = (
            "&lt;IP_ADDRESS_ORIG_CLIENT&gt;82.165.43.101"
            "&lt;/IP_ADDRESS_ORIG_CLIENT&gt;"
            "&lt;CLIENT_MAC_ADDRESS&gt;00:11:22:33:44:55"
            "&lt;/CLIENT_MAC_ADDRESS&gt;"
        )
        result = self.scrubber.scrub(source, seed="network-identifiers", include_preamble=False)
        self.assertNotIn("82.165.43.101", result.text)
        self.assertNotIn("00:11:22:33:44:55", result.text)
        self.assertEqual(result.stats.get("IP_ADDRESS"), 1)
        self.assertEqual(result.stats.get("MAC_ADDRESS"), 1)
        fake_ip = next(entry.fake for entry in result.mapping if entry.kind == "IP_ADDRESS")
        self.assertTrue(fake_ip.startswith("192.0.2."))


    def test_reported_malformed_bankwizard_payload_scrubs_available_pii(self) -> None:
        source = (
            'xmlns:bwa="http://api.bankwizardabsolute.com/dataverification/types"'
            '&gt;&lt;REQUEST\nt;&lt;SURNAME&gt;DAVIS&lt;/SURNAME&gt;'
            '&lt;DATEOFBIRTH_DD&gt;19&lt;/DATEOFBIRTH_DD&gt;&lt;DAT\n'
            'SER_ID&gt;CROSSCOREBWAPROD01&lt;/USER_ID&gt;'
            '&lt;IP_ADDRESS_ORIG_CLIENT /&gt;&lt;CLIENT_MAC_A\n'
            'TYPE_OF_CHECK&gt;VERIFY&lt;/TYPE_OF_CHECK&gt;'
        )
        result = self.scrubber.scrub(
            source, seed="INC123456789", include_preamble=False
        )
        self.assertNotIn("DAVIS", result.text)
        self.assertNotIn("DD&gt;19&lt;/DATEOFBIRTH_DD", result.text)
        self.assertIn("CROSSCOREBWAPROD01", result.text)
        self.assertIn("VERIFY", result.text)
        self.assertEqual(result.stats.get("SURNAME"), 1)
        self.assertEqual(result.stats.get("DATE_OF_BIRTH_DAY"), 1)


    def test_html_escaped_xml_applies_all_existing_structured_rules(self) -> None:
        source = (
            "&lt;EMAIL&gt;person@example.org&lt;/EMAIL&gt;"
            "&lt;PHONE&gt;+353 85 123 4567&lt;/PHONE&gt;"
            "&lt;SORTCODE&gt;123456&lt;/SORTCODE&gt;"
            "&lt;ACCOUNTNUMBER&gt;87654321&lt;/ACCOUNTNUMBER&gt;"
            "&lt;IBAN&gt;IE29AIBK93115212345678&lt;/IBAN&gt;"
            "&lt;POSTALCODE&gt;D02 X285&lt;/POSTALCODE&gt;"
            "&lt;CUSTOMERNAME&gt;Jane Doe&lt;/CUSTOMERNAME&gt;"
        )
        result = self.scrubber.scrub(source, seed="escaped-all", include_preamble=False)
        for original in (
            "person@example.org",
            "+353 85 123 4567",
            "123456",
            "87654321",
            "IE29AIBK93115212345678",
            "D02 X285",
            "Jane Doe",
        ):
            self.assertNotIn(original, result.text)
        self.assertTrue(
            {"EMAIL", "PHONE", "SORT_CODE", "ACCOUNT_NUMBER", "IBAN", "POSTCODE", "NAME"}
            .issubset({entry.kind for entry in result.mapping})
        )



if __name__ == "__main__":
    unittest.main()
