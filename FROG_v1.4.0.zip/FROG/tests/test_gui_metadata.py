from __future__ import annotations

import unittest
import tempfile
from pathlib import Path

from frog.gui import (
    APPEARANCE_DARK,
    APPEARANCE_LIGHT,
    AUTO_SCRUB_DELAY_MS,
    INPUT_PRETTY_DELAY_MS,
    PALETTES,
    PRETTY_PRINT_LABEL,
    STYLE_MODERN,
    STYLE_RETRO,
    asset_path,
)
from frog.settings import load_preferences, save_preferences


class GuiMetadataTests(unittest.TestCase):
    def test_all_four_visual_profiles_are_defined(self) -> None:
        expected = {
            (STYLE_RETRO, APPEARANCE_LIGHT),
            (STYLE_RETRO, APPEARANCE_DARK),
            (STYLE_MODERN, APPEARANCE_LIGHT),
            (STYLE_MODERN, APPEARANCE_DARK),
        }
        self.assertEqual(set(PALETTES), expected)
        for palette in PALETTES.values():
            for required_key in ("bg", "surface", "text", "input_bg", "input_fg", "accent", "border"):
                self.assertIn(required_key, palette)

    def test_brand_assets_required_by_gui_exist(self) -> None:
        for filename in ("frog_icon.ico", "frog_icon.png", "frog_header.png", "frog_about.png"):
            with self.subTest(filename=filename):
                self.assertTrue(asset_path(filename).is_file())

    def test_auto_scrub_uses_a_short_debounce(self) -> None:
        self.assertGreaterEqual(AUTO_SCRUB_DELAY_MS, 250)
        self.assertLessEqual(AUTO_SCRUB_DELAY_MS, 1000)


    def test_input_pretty_print_runs_before_auto_scrub(self) -> None:
        self.assertGreaterEqual(INPUT_PRETTY_DELAY_MS, 100)
        self.assertLess(INPUT_PRETTY_DELAY_MS, AUTO_SCRUB_DELAY_MS)

    def test_pretty_print_label_covers_both_panes(self) -> None:
        label = PRETTY_PRINT_LABEL.lower()
        self.assertIn("input", label)
        self.assertIn("output", label)

    def test_non_sensitive_ui_preferences_round_trip(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "settings.json"
            save_preferences(
                {
                    "mode": "redact",
                    "include_preamble": False,
                    "auto_scrub": True,
                    "pretty_print": True,
                    "interface_style": STYLE_MODERN,
                    "appearance": APPEARANCE_DARK,
                    # Unknown/sensitive-looking keys are deliberately discarded.
                    "seed": "INC123456789",
                },
                path,
            )
            loaded = load_preferences(path)
        self.assertEqual(loaded["mode"], "redact")
        self.assertFalse(loaded["include_preamble"])
        self.assertTrue(loaded["auto_scrub"])
        self.assertTrue(loaded["pretty_print"])
        self.assertEqual(loaded["interface_style"], STYLE_MODERN)
        self.assertEqual(loaded["appearance"], APPEARANCE_DARK)
        self.assertNotIn("seed", loaded)


if __name__ == "__main__":
    unittest.main()
