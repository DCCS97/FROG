from __future__ import annotations

from frog.engine import Scrubber


SAMPLE = r'''{
  "customerName": "Alex Morgan",
  "dob": "04/11/1985",
  "phone": "+353 85 123 4567",
  "address": {
    "street": "12 O'Connell Street",
    "city": "Dublin",
    "postal_code": "D02 X285",
    "country": "Ireland"
  },
  "iban": "IE29AIBK93115212345678",
  "supplier_phone": "+48 512 345 678",
  "supplier_iban": "ES9121000418450200051332"
}
Alex Morgan called later; she confirmed the failed payment was hers.
'''


if __name__ == "__main__":
    result = Scrubber().scrub(
        SAMPLE,
        seed="INC123456789",
        include_preamble=False,
        pretty_print=True,
    )
    print("BEFORE\n------")
    print(SAMPLE)
    print("\nAFTER\n-----")
    print(result.text)
    print("\nLOCAL-ONLY MAPPING\n------------------")
    print(result.mapping_text())
