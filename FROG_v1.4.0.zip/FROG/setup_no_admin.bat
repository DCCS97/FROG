@echo off
setlocal
cd /d "%~dp0"

echo FROG no-admin setup
 echo ===================
echo.

where py >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_CMD=py"
) else (
    where python >nul 2>&1
    if not errorlevel 1 (
        set "PYTHON_CMD=python"
    ) else (
        where python3 >nul 2>&1
        if not errorlevel 1 (
            set "PYTHON_CMD=python3"
        ) else (
            echo ERROR: Python could not be found.
            echo Install Python for your user account or use a pre-built FROG.exe.
            goto :error
        )
    )
)

if not exist ".venv\Scripts\python.exe" (
    "%PYTHON_CMD%" -m venv .venv
    if errorlevel 1 goto :error
)

set "VENV_PYTHON=%CD%\.venv\Scripts\python.exe"
"%VENV_PYTHON%" -m pip install --upgrade pip
if errorlevel 1 goto :error
"%VENV_PYTHON%" -m pip install -r requirements.txt
if errorlevel 1 goto :error

echo.
echo FROG is installed locally in this folder. No administrator rights were used.
echo Run it with run_frog.bat
pause
exit /b 0

:error
echo.
echo Setup failed.
pause
exit /b 1
