from __future__ import annotations

import argparse

from frog.gui import main


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="FROG local PII scrubber")
    parser.add_argument("--smoke-test", action="store_true", help="Create and close the GUI once")
    args = parser.parse_args()
    raise SystemExit(main(smoke_test=args.smoke_test))
