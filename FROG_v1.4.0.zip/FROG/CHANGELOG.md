# Changelog

## 1.4.0 — 2026-07-13

- Added a mapped detection-view pipeline for HTML/XML entity decoding without modifying the original pasted log.
- Added support for double-escaped XML, entities split by display wrapping and newlines inside XML tag names.
- Added labelled surname/family-name, first/forename and middle-name fields with case-preserving synthetic replacements.
- Added split DOB components (`DD`, `MM`, `YY`, `YYYY`) and linked adjacent components to one valid synthetic date.
- Added labelled client/originating IP-address detection with classification-preserving synthetic ranges.
- Added labelled and distinctively formatted MAC-address detection with locally administered synthetic values.
- Added regression tests based on the escaped Bank Wizard-style payload supplied by the user.
- Expanded the automated suite from 32 to 37 tests.

## 1.3.1 — 2026-07-13

- Extended the remembered Pretty Print toggle to format and syntax-highlight both the input and output panes.
- Added debounced input formatting after paste/edit so compact JSON/XML becomes readable before or during scrubbing.
- Added safe restoration of the original input layout when Pretty Print is disabled and the formatted input has not been edited.
- Generalised syntax highlighting so the same colour rules are applied consistently to both panes and across theme changes.
- Expanded the GUI smoke test to verify dual-pane pretty-printing and reversible input layout.

## 1.3.0 — 2026-07-13

- Confirmed and expanded DOB aliases including `dob`, `d.o.b`, `dateOfBirth`, `birthDate` and `bornOn` across structured formats.
- Generalised IBAN handling across countries while preserving source country code, length, character shape, separators and MOD-97 validity.
- Added offline international telephone parsing/generation with calling-country preservation; local numbers default to GB.
- Added structured full-address, street/address-line, city, international postal-code and selected region detection.
- Added country-context inference from JSON/XML/Splunk country fields, with smallest-enclosing-JSON-object isolation for adjacent records.
- Added country-localised Faker address generation and origin metadata in the local-only mapping.
- Added persistent non-sensitive UI preferences in `%APPDATA%\FROG\settings.json`; seeds, logs and mappings are never stored there.
- Added optional automatic JSON/XML pretty-printing and display-only syntax highlighting.
- Updated no-admin scripts to work when `py` is unavailable but `python` exists.
- Added `phonenumbers` and `pycountry` as offline runtime dependencies.
- Expanded automated regression coverage from 22 to 30 tests.

## 1.2.0 — 2026-07-13

- Added structured-field detection for all built-in PII types across common log encodings.
- Added compact UK sort-code handling when a field is explicitly labelled, including `<sortcode>123456</sortcode>`.
- Added XML element, namespace, CDATA and attribute support.
- Expanded JSON, Splunk key/value and pipe-delimited labelled-field handling.
- Added support for UK telephone values written with bare `44` or `0044` prefixes in labelled fields.
- Labelled card values are scrubbed even when source Luhn validation fails.

## 1.1.0 — 2026-07-13

- Added Retro/Modern and Light/Dark interface switching.
- Added debounced auto-scrub, stale-result protection and thread-safe GUI result handling.
- Integrated supplied FROG branding artwork.

## 1.0.1 — 2026-07-13

- Scrub labelled IBAN fields even when the source checksum is invalid.
- Preserve the relationship between UK IBANs and separate sort-code/account-number values.

## 1.0.0 — 2026-07-13

- Initial local PII scrubber, mapping window, seeded pseudonymisation, redaction mode, custom rules and retro interface.
