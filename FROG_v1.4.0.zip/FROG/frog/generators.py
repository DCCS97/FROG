from __future__ import annotations

import ipaddress
import re
import string
import unicodedata
from datetime import date
from random import Random
from typing import Any

import phonenumbers
from faker import Faker
from phonenumbers import PhoneNumberFormat, PhoneNumberType

from .countries import country_name
from .models import SyntheticValue


LETTERS = string.ascii_uppercase
NINO_FIRST = "ABCEGHJKLMNPRSTWXYZ"
NINO_SECOND = "ABCEGHJKLMNPRSTWXYZ"


def digits_only(value: str) -> str:
    return "".join(ch for ch in value if ch.isdigit())


def alnum_only(value: str) -> str:
    return "".join(ch for ch in value if ch.isalnum())


def canonical_exact(value: str) -> str:
    return " ".join(value.strip().split()).casefold()


def canonical_name(value: str) -> str:
    return " ".join(value.strip().split()).casefold()


def canonical_email(value: str) -> str:
    return value.strip().casefold()


def canonical_digits(value: str) -> str:
    return digits_only(value)


def canonical_alnum(value: str) -> str:
    return alnum_only(value).upper()


def canonical_phone(value: str) -> str:
    """Normalise a phone to E.164, assuming GB only when no country is supplied."""

    raw = value.strip()
    digits = digits_only(raw)
    if raw.startswith("00"):
        raw = "+" + digits[2:]
    elif raw.startswith("+"):
        raw = "+" + digits
    elif digits.startswith("44") and not raw.startswith("0"):
        # Splunk/XML often strips the + from an otherwise international number.
        raw = "+" + digits
    try:
        parsed = phonenumbers.parse(raw, "GB")
        if parsed.country_code and parsed.national_number:
            return phonenumbers.format_number(parsed, PhoneNumberFormat.E164)
    except phonenumbers.NumberParseException:
        pass
    return digits


def _ascii_slug(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value)
    ascii_value = normalized.encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^a-z0-9]+", ".", ascii_value.casefold()).strip(".")
    return slug or "user"


def _fill_digits(template: str, digits: str) -> str:
    out: list[str] = []
    index = 0
    for ch in template:
        if ch.isdigit():
            if index >= len(digits):
                out.append(ch)
            else:
                out.append(digits[index])
                index += 1
        else:
            out.append(ch)
    if index < len(digits):
        out.append(digits[index:])
    return "".join(out)


def _fill_alnum(template: str, compact: str) -> str:
    out: list[str] = []
    index = 0
    for ch in template:
        if ch.isalnum():
            if index >= len(compact):
                out.append(ch)
            else:
                replacement = compact[index]
                if ch.islower():
                    replacement = replacement.lower()
                out.append(replacement)
                index += 1
        else:
            out.append(ch)
    if index < len(compact):
        out.append(compact[index:])
    return "".join(out)


def render_plain(value: SyntheticValue, _original: str) -> str:
    return value.base


def render_digits(value: SyntheticValue, original: str) -> str:
    return _fill_digits(original, value.base)


def render_alnum(value: SyntheticValue, original: str) -> str:
    return _fill_alnum(original, value.base)


def generate_email(_real: str, rng: Random, faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    first = _ascii_slug(faker.first_name())
    last = _ascii_slug(faker.last_name())
    suffix = rng.randint(10, 9999)
    return SyntheticValue(f"{first}.{last}{suffix}@example.com")


def generate_name(_real: str, _rng: Random, faker: Faker, metadata: dict[str, Any]) -> SyntheticValue:
    gender = metadata.get("gender")
    if gender == "male":
        return SyntheticValue(faker.name_male())
    if gender == "female":
        return SyntheticValue(faker.name_female())
    return SyntheticValue(faker.name())


def generate_first_name(_real: str, _rng: Random, faker: Faker, metadata: dict[str, Any]) -> SyntheticValue:
    gender = metadata.get("gender")
    if gender == "male":
        return SyntheticValue(faker.first_name_male())
    if gender == "female":
        return SyntheticValue(faker.first_name_female())
    return SyntheticValue(faker.first_name())


def generate_surname(_real: str, _rng: Random, faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    return SyntheticValue(faker.last_name())


def render_preserve_case(value: SyntheticValue, original: str) -> str:
    rendered = value.base
    letters = [character for character in original if character.isalpha()]
    if letters and all(character.isupper() for character in letters):
        return rendered.upper()
    if letters and all(character.islower() for character in letters):
        return rendered.lower()
    if original.istitle():
        return rendered.title()
    return rendered


def generate_digits(real: str, rng: Random, _faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    length = len(digits_only(real))
    generated = "".join(str(rng.randrange(10)) for _ in range(length))
    if length and not digits_only(real).startswith("0") and generated.startswith("0"):
        generated = str(rng.randrange(1, 10)) + generated[1:]
    return SyntheticValue(generated)


def generate_sort_code(_real: str, rng: Random, _faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    return SyntheticValue("".join(str(rng.randrange(10)) for _ in range(6)))


def luhn_is_valid(value: str) -> bool:
    digits = digits_only(value)
    if not 13 <= len(digits) <= 19:
        return False
    total = 0
    parity = len(digits) % 2
    for index, char in enumerate(digits):
        digit = int(char)
        if index % 2 == parity:
            digit *= 2
            if digit > 9:
                digit -= 9
        total += digit
    return total % 10 == 0


def _luhn_check_digit(partial: str) -> str:
    for candidate in range(10):
        full = partial + str(candidate)
        if luhn_is_valid(full):
            return str(candidate)
    raise RuntimeError("Unable to create Luhn check digit")


def generate_card(real: str, rng: Random, _faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    length = len(digits_only(real))
    # A conspicuously synthetic prefix reduces the chance of creating a live-looking PAN,
    # while the final digit still passes Luhn for software-path testing.
    prefix = ("999999" if length >= 7 else "9" * max(1, length - 1))[: max(0, length - 1)]
    body_len = max(0, length - 1 - len(prefix))
    partial = prefix + "".join(str(rng.randrange(10)) for _ in range(body_len))
    return SyntheticValue(partial + _luhn_check_digit(partial))


def iban_is_valid(value: str) -> bool:
    compact = alnum_only(value).upper()
    if not 15 <= len(compact) <= 34 or not re.fullmatch(r"[A-Z]{2}\d{2}[A-Z0-9]+", compact):
        return False
    rearranged = compact[4:] + compact[:4]
    expanded = "".join(str(ord(ch) - 55) if ch.isalpha() else ch for ch in rearranged)
    remainder = 0
    for chunk_start in range(0, len(expanded), 9):
        remainder = int(str(remainder) + expanded[chunk_start : chunk_start + 9]) % 97
    return remainder == 1


def _iban_check_digits(country: str, bban: str) -> str:
    rearranged = bban + country + "00"
    expanded = "".join(str(ord(ch) - 55) if ch.isalpha() else ch for ch in rearranged)
    remainder = 0
    for chunk_start in range(0, len(expanded), 9):
        remainder = int(str(remainder) + expanded[chunk_start : chunk_start + 9]) % 97
    return f"{98 - remainder:02d}"


def rebuild_uk_iban(
    generated: SyntheticValue,
    *,
    sort_code: str | None = None,
    account_number: str | None = None,
) -> SyntheticValue:
    """Embed linked fake UK sort/account values and recalculate MOD-97 digits."""

    compact = alnum_only(generated.base).upper()
    if len(compact) != 22 or not compact.startswith("GB"):
        return generated

    bban = list(compact[4:])  # 4-char bank code + 6-char sort code + 8-char account
    if sort_code is not None:
        sort_digits = digits_only(sort_code)
        if len(sort_digits) == 6:
            bban[4:10] = sort_digits
    if account_number is not None:
        account_digits = digits_only(account_number)
        if len(account_digits) == 8:
            bban[10:18] = account_digits

    bban_text = "".join(bban)
    return SyntheticValue("GB" + _iban_check_digits("GB", bban_text) + bban_text)


def generate_iban(real: str, rng: Random, _faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    compact = alnum_only(real).upper()
    country = compact[:2]
    original_bban = compact[4:]
    generated_chars: list[str] = []
    for char in original_bban:
        if char.isdigit():
            generated_chars.append(str(rng.randrange(10)))
        else:
            generated_chars.append(rng.choice(LETTERS))
    bban = "".join(generated_chars)
    check = _iban_check_digits(country, bban)
    return SyntheticValue(country + check + bban)


def nino_is_valid(value: str) -> bool:
    compact = re.sub(r"[\s-]", "", value).upper()
    return bool(
        re.fullmatch(
            r"(?!BG|GB|KN|NK|NT|TN|ZZ)(?![DFIQUV])[A-CEGHJ-PR-TW-Z]{2}\d{6}[A-D]",
            compact,
        )
    )


def generate_nino(_real: str, rng: Random, _faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    while True:
        prefix = rng.choice(NINO_FIRST) + rng.choice(NINO_SECOND)
        if prefix not in {"BG", "GB", "KN", "NK", "NT", "TN", "ZZ"}:
            break
    body = "".join(str(rng.randrange(10)) for _ in range(6))
    suffix = rng.choice("ABCD")
    return SyntheticValue(prefix + body + suffix)


def _parse_phone(value: str, default_region: str = "GB") -> phonenumbers.PhoneNumber | None:
    raw = value.strip()
    digits = digits_only(raw)
    if raw.startswith("00"):
        raw = "+" + digits[2:]
    elif raw.startswith("+"):
        raw = "+" + digits
    elif digits.startswith("44") and not raw.startswith("0"):
        raw = "+" + digits
    try:
        parsed = phonenumbers.parse(raw, default_region)
    except phonenumbers.NumberParseException:
        return None
    return parsed if parsed.country_code and parsed.national_number else None


def phone_country(value: str) -> str:
    parsed = _parse_phone(value)
    if parsed is None:
        return "GB"
    return phonenumbers.region_code_for_number(parsed) or "GB"


def phone_is_valid(value: str) -> bool:
    parsed = _parse_phone(value)
    return bool(parsed and phonenumbers.is_possible_number(parsed))


def _example_phone(region: str, number_type: PhoneNumberType) -> phonenumbers.PhoneNumber | None:
    example = phonenumbers.example_number_for_type(region, number_type)
    if example is None:
        example = phonenumbers.example_number(region)
    return example


def generate_phone(real: str, rng: Random, _faker: Faker, metadata: dict[str, Any]) -> SyntheticValue:
    parsed_real = _parse_phone(real, metadata.get("country_code", "GB"))
    region = metadata.get("country_code") or (
        phonenumbers.region_code_for_number(parsed_real) if parsed_real is not None else "GB"
    )
    region = region or "GB"
    number_type = (
        phonenumbers.number_type(parsed_real)
        if parsed_real is not None
        else PhoneNumberType.MOBILE
    )
    if number_type == PhoneNumberType.UNKNOWN and parsed_real is not None:
        national_text = str(parsed_real.national_number)
        if region == "GB" and national_text.startswith("7"):
            number_type = PhoneNumberType.MOBILE
    example = _example_phone(region, number_type)
    if example is None:
        # Unknown/unsupported region: retain the country calling code and length.
        if parsed_real is not None:
            calling_code = str(parsed_real.country_code)
            national_len = len(str(parsed_real.national_number))
        else:
            calling_code = "44"
            national_len = 10
        national = "".join(str(rng.randrange(10)) for _ in range(national_len))
        return SyntheticValue("+" + calling_code + national, payload={"region": region})

    base_national = str(example.national_number)
    # Vary a few trailing digits deterministically, retaining a possible number.
    for _ in range(100):
        mutable = list(base_national)
        for index in range(max(0, len(mutable) - 4), len(mutable)):
            mutable[index] = str(rng.randrange(10))
        candidate = phonenumbers.PhoneNumber(
            country_code=example.country_code,
            national_number=int("".join(mutable)),
        )
        if phonenumbers.is_possible_number(candidate):
            e164 = phonenumbers.format_number(candidate, PhoneNumberFormat.E164)
            return SyntheticValue(e164, payload={"region": region, "number": candidate})
    e164 = phonenumbers.format_number(example, PhoneNumberFormat.E164)
    return SyntheticValue(e164, payload={"region": region, "number": example})


def render_phone(value: SyntheticValue, original: str) -> str:
    parsed = None
    if isinstance(value.payload, dict):
        parsed = value.payload.get("number")
    if parsed is None:
        parsed = _parse_phone(value.base)
    if parsed is None:
        return render_digits(value, original)

    e164_digits = digits_only(phonenumbers.format_number(parsed, PhoneNumberFormat.E164))
    country_digits = str(parsed.country_code)
    national_digits = str(parsed.national_number)
    stripped = original.lstrip()
    original_digits = digits_only(original)

    if stripped.startswith("+"):
        digit_stream = e164_digits
    elif original_digits.startswith("00"):
        digit_stream = "00" + e164_digits
    elif (
        not stripped.startswith("0")
        and original_digits.startswith(country_digits)
        and len(original_digits) >= len(country_digits) + 6
    ):
        digit_stream = e164_digits
    else:
        # No international prefix: preserve national/local presentation. GB is
        # the default region when the source did not specify a country code.
        national_formatted = phonenumbers.format_number(parsed, PhoneNumberFormat.NATIONAL)
        digit_stream = digits_only(national_formatted)
    return _fill_digits(original, digit_stream)


def postcode_shape(value: str) -> str:
    return "".join("A" if ch.isalpha() else "9" for ch in value if ch.isalnum())


def postcode_is_valid(value: str) -> bool:
    compact = " ".join(value.upper().split())
    return bool(
        re.fullmatch(
            r"(?:GIR 0AA|(?:[A-PR-UWYZ][0-9][0-9A-HJKPSTUW]?|[A-PR-UWYZ][A-HK-Y][0-9][0-9ABEHMNPRV-Y]?) [0-9][ABD-HJLNP-UW-Z]{2})",
            compact,
        )
    )


def generate_postcode(real: str, rng: Random, faker: Faker, metadata: dict[str, Any]) -> SyntheticValue:
    target_shape = postcode_shape(real)
    for _ in range(100):
        try:
            candidate = faker.postcode().upper()
        except (AttributeError, NotImplementedError):
            candidate = ""
        if postcode_shape(candidate) == target_shape:
            return SyntheticValue(alnum_only(candidate).upper(), payload={"formatted": candidate})
    generated: list[str] = []
    for marker in target_shape:
        generated.append(rng.choice(LETTERS) if marker == "A" else str(rng.randrange(10)))
    return SyntheticValue(
        "".join(generated),
        payload={"country_code": metadata.get("country_code"), "country": country_name(metadata.get("country_code"))},
    )


def render_postcode(value: SyntheticValue, original: str) -> str:
    formatted = value.payload.get("formatted") if isinstance(value.payload, dict) else None
    if formatted and len(alnum_only(formatted)) != len(alnum_only(original)):
        return str(formatted)
    return render_alnum(value, original)


def generate_street_address(_real: str, _rng: Random, faker: Faker, metadata: dict[str, Any]) -> SyntheticValue:
    try:
        generated = faker.street_address().replace("\n", ", ")
    except (AttributeError, NotImplementedError):
        generated = faker.address().replace("\n", ", ")
    return SyntheticValue(generated, payload={"country_code": metadata.get("country_code")})


def generate_city(_real: str, _rng: Random, faker: Faker, metadata: dict[str, Any]) -> SyntheticValue:
    try:
        generated = faker.city().replace("\n", " ")
    except (AttributeError, NotImplementedError):
        generated = "Example City"
    return SyntheticValue(generated, payload={"country_code": metadata.get("country_code")})


def generate_region(_real: str, _rng: Random, faker: Faker, metadata: dict[str, Any]) -> SyntheticValue:
    for provider in ("administrative_unit", "state", "province"):
        function = getattr(faker, provider, None)
        if function is None:
            continue
        try:
            return SyntheticValue(
                str(function()).replace("\n", " "),
                payload={"country_code": metadata.get("country_code")},
            )
        except (AttributeError, NotImplementedError):
            continue
    return SyntheticValue("Example Region", payload={"country_code": metadata.get("country_code")})


def generate_full_address(_real: str, _rng: Random, faker: Faker, metadata: dict[str, Any]) -> SyntheticValue:
    try:
        generated = faker.address().replace("\n", ", ")
    except (AttributeError, NotImplementedError):
        generated = f"1 Example Street, Example City"
    return SyntheticValue(generated, payload={"country_code": metadata.get("country_code")})


def _parse_dob(value: str) -> tuple[date, str] | None:
    raw = value.strip()
    numeric_patterns = [
        (r"(\d{2})/(\d{2})/(\d{4})", "%d/%m/%Y"),
        (r"(\d{2})-(\d{2})-(\d{4})", "%d-%m-%Y"),
        (r"(\d{2})\.(\d{2})\.(\d{4})", "%d.%m.%Y"),
        (r"(\d{4})-(\d{2})-(\d{2})", "%Y-%m-%d"),
        (r"(\d{4})/(\d{2})/(\d{2})", "%Y/%m/%d"),
        (r"(\d{1,2})/(\d{1,2})/(\d{2})", "%d/%m/%y"),
        (r"(\d{1,2})-(\d{1,2})-(\d{2})", "%d-%m-%y"),
    ]
    from datetime import datetime

    for pattern, fmt in numeric_patterns:
        if re.fullmatch(pattern, raw):
            try:
                return datetime.strptime(raw, fmt).date(), fmt
            except ValueError:
                return None
    for fmt in ("%d %B %Y", "%d %b %Y"):
        try:
            return datetime.strptime(raw, fmt).date(), fmt
        except ValueError:
            pass
    return None


def dob_is_valid(value: str) -> bool:
    return _parse_dob(value) is not None


def canonical_dob(value: str) -> str:
    parsed = _parse_dob(value)
    return parsed[0].isoformat() if parsed else canonical_exact(value)


def generate_dob(_real: str, _rng: Random, faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    generated = faker.date_of_birth(minimum_age=18, maximum_age=90)
    return SyntheticValue(generated.isoformat(), payload=generated)


def render_dob(value: SyntheticValue, original: str) -> str:
    generated: date = value.payload or date.fromisoformat(value.base)
    parsed = _parse_dob(original)
    if not parsed:
        return value.base
    _real_date, fmt = parsed
    rendered = generated.strftime(fmt)
    # Preserve unpadded day/month when the source used them.
    if re.fullmatch(r"\d{1,2}/\d{1,2}/\d{2}", original.strip()) and not re.fullmatch(
        r"\d{2}/\d{2}/\d{2}", original.strip()
    ):
        rendered = f"{generated.day}/{generated.month}/{generated.strftime('%y')}"
    elif re.fullmatch(r"\d{1,2}-\d{1,2}-\d{2}", original.strip()) and not re.fullmatch(
        r"\d{2}-\d{2}-\d{2}", original.strip()
    ):
        rendered = f"{generated.day}-{generated.month}-{generated.strftime('%y')}"
    return rendered


def generate_mask(real: str, rng: Random, _faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    compact: list[str] = []
    for ch in real:
        if ch.isdigit():
            compact.append(str(rng.randrange(10)))
        elif ch.isalpha():
            replacement = rng.choice(LETTERS)
            compact.append(replacement.lower() if ch.islower() else replacement)
    return SyntheticValue("".join(compact))


def dob_day_is_valid(value: str) -> bool:
    digits = digits_only(value)
    return bool(digits and 1 <= int(digits) <= 31)


def dob_month_is_valid(value: str) -> bool:
    digits = digits_only(value)
    return bool(digits and 1 <= int(digits) <= 12)


def dob_year_is_valid(value: str) -> bool:
    digits = digits_only(value)
    return len(digits) in {2, 4} and int(digits) > 0


def _component_date(faker: Faker) -> date:
    return faker.date_of_birth(minimum_age=18, maximum_age=90)


def generate_dob_day(real: str, _rng: Random, faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    generated = _component_date(faker)
    width = max(1, len(digits_only(real)))
    return SyntheticValue(str(generated.day).zfill(width), payload=generated)


def generate_dob_month(real: str, _rng: Random, faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    generated = _component_date(faker)
    width = max(1, len(digits_only(real)))
    return SyntheticValue(str(generated.month).zfill(width), payload=generated)


def generate_dob_year(real: str, _rng: Random, faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    generated = _component_date(faker)
    width = max(2, len(digits_only(real)))
    rendered = str(generated.year) if width >= 4 else f"{generated.year % 100:02d}"
    return SyntheticValue(rendered, payload=generated)


def render_dob_component(value: SyntheticValue, original: str) -> str:
    digits = digits_only(value.base)
    original_digits = digits_only(original)
    if not original_digits:
        return value.base
    if len(digits) < len(original_digits):
        digits = digits.zfill(len(original_digits))
    elif len(digits) > len(original_digits):
        digits = digits[-len(original_digits):]
    return _fill_digits(original, digits)


def ip_address_is_valid(value: str) -> bool:
    try:
        ipaddress.ip_address(value.strip())
        return True
    except ValueError:
        return False


def generate_ip_address(real: str, rng: Random, _faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    parsed = ipaddress.ip_address(real.strip())
    if isinstance(parsed, ipaddress.IPv4Address):
        if parsed.is_loopback:
            generated = ipaddress.IPv4Address(f"127.0.0.{rng.randint(1, 254)}")
        elif parsed.is_private:
            generated = ipaddress.IPv4Address(f"10.{rng.randint(0,255)}.{rng.randint(0,255)}.{rng.randint(1,254)}")
        elif parsed.is_link_local:
            generated = ipaddress.IPv4Address(f"169.254.{rng.randint(0,255)}.{rng.randint(1,254)}")
        else:
            generated = ipaddress.IPv4Address(f"192.0.2.{rng.randint(1,254)}")
    else:
        if parsed.is_loopback:
            generated = ipaddress.IPv6Address("::1")
        elif parsed.is_private:
            generated = ipaddress.IPv6Address((0xFD00 << 112) | rng.getrandbits(112))
        elif parsed.is_link_local:
            generated = ipaddress.IPv6Address((0xFE80 << 112) | rng.getrandbits(64))
        else:
            generated = ipaddress.IPv6Address((0x20010DB8 << 96) | rng.getrandbits(96))
    return SyntheticValue(str(generated))


def mac_address_is_valid(value: str) -> bool:
    compact = re.sub(r"[^0-9A-Fa-f]", "", value)
    return len(compact) == 12 and bool(re.fullmatch(r"[0-9A-Fa-f]{12}", compact))


def generate_mac_address(_real: str, rng: Random, _faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    octets = [rng.randrange(256) for _ in range(6)]
    # Locally administered, unicast address: not an assigned hardware vendor OUI.
    octets[0] = (octets[0] | 0x02) & 0xFE
    return SyntheticValue("".join(f"{octet:02X}" for octet in octets))
