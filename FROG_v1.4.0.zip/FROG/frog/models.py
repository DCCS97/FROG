from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Pattern


@dataclass(frozen=True)
class SyntheticValue:
    """A generated value plus any structured payload needed for rendering."""

    base: str
    payload: Any = None


Validator = Callable[[str], bool]
Canonicalizer = Callable[[str], str]
ReplacementFn = Callable[[str, Any, Any, dict[str, Any]], SyntheticValue]
Renderer = Callable[[SyntheticValue, str], str]


@dataclass(frozen=True)
class PatternRule:
    """One extendable PII detection/replacement rule."""

    name: str
    kind: str
    regex: Pattern[str]
    replacement_fn: ReplacementFn
    renderer: Renderer
    canonicalizer: Canonicalizer
    validator: Validator = lambda _value: True
    value_group: str | int = "value"
    priority: int = 50
    is_name_rule: bool = False


@dataclass(frozen=True)
class Detection:
    kind: str
    real: str
    canonical: str
    start: int
    end: int
    rule: PatternRule
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class MappingEntry:
    kind: str
    fake: str
    real: str
    canonical_real: str
    occurrences: int = 0
    rendered_fakes: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ScrubResult:
    text: str
    mapping: list[MappingEntry]
    effective_seed: str
    stats: dict[str, int]
    format_name: str = "plain"
    syntax_spans: list[tuple[str, int, int]] = field(default_factory=list)

    def mapping_text(self) -> str:
        lines = [
            "FROG LOCAL-ONLY REFERENCE MAPPING",
            "NEVER PASTE OR SHARE THIS FILE — IT CONTAINS THE ORIGINAL PII.",
            "=" * 72,
            f"Effective seed: {self.effective_seed}",
            "",
        ]
        for index, entry in enumerate(self.mapping, start=1):
            lines.append(f"{index}. [{entry.kind}]")
            lines.append(f"   FAKE: {entry.fake}")
            if len(entry.rendered_fakes) > 1:
                lines.append("   RENDERED VARIANTS: " + " | ".join(entry.rendered_fakes))
            lines.append(f"   REAL: {entry.real}")
            lines.append(f"   OCCURRENCES: {entry.occurrences}")
            if entry.metadata.get("gender"):
                lines.append(f"   INFERRED GENDER CUE: {entry.metadata['gender']}")
            if entry.metadata.get("linked_uk_routing_fields"):
                lines.append("   RELATIONSHIP: embeds the matching fake sort code/account number")
            if entry.metadata.get("country_code"):
                country_name = entry.metadata.get("country_name")
                suffix = f" — {country_name}" if country_name else ""
                lines.append(f"   ORIGIN PRESERVED: {entry.metadata['country_code']}{suffix}")
            lines.append("")
        return "\n".join(lines)
