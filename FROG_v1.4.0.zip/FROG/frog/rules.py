from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Callable

from .generators import (
    canonical_alnum,
    canonical_digits,
    canonical_dob,
    canonical_email,
    canonical_exact,
    canonical_name,
    canonical_phone,
    dob_day_is_valid,
    dob_is_valid,
    dob_month_is_valid,
    dob_year_is_valid,
    generate_card,
    generate_city,
    generate_digits,
    generate_dob,
    generate_dob_day,
    generate_dob_month,
    generate_dob_year,
    generate_email,
    generate_first_name,
    generate_full_address,
    generate_iban,
    generate_ip_address,
    generate_mac_address,
    generate_mask,
    generate_name,
    generate_surname,
    generate_nino,
    generate_phone,
    generate_postcode,
    generate_region,
    generate_sort_code,
    generate_street_address,
    iban_is_valid,
    ip_address_is_valid,
    luhn_is_valid,
    mac_address_is_valid,
    nino_is_valid,
    phone_is_valid,
    postcode_is_valid,
    render_alnum,
    render_digits,
    render_dob,
    render_dob_component,
    render_phone,
    render_preserve_case,
    render_plain,
    render_postcode,
)
from .models import PatternRule


NAME_TOKEN = r"[A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ'’\-]+"
FULL_NAME = rf"{NAME_TOKEN}(?:[ \t]+{NAME_TOKEN}){{1,3}}"
SINGLE_NAME = rf"{NAME_TOKEN}"
NAME_COMPONENT = rf"{NAME_TOKEN}(?:[ \t]+{NAME_TOKEN}){{0,3}}"

EMAIL_VALUE = r"[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,63}"
IBAN_VALUE = r"[A-Z]{2}\d{2}(?:[ \-]?[A-Z0-9]){11,30}"
NINO_VALUE = (
    r"(?!BG|GB|KN|NK|NT|TN|ZZ)(?![DFIQUV])"
    r"[A-CEGHJ-PR-TW-Z]{2}[ \-]?\d{2}[ \-]?\d{2}[ \-]?\d{2}[ \-]?[A-D]"
)
POSTCODE_VALUE = (
    r"GIR\s?0AA|"
    r"(?:[A-PR-UWYZ][0-9][0-9A-HJKPSTUW]?|"
    r"[A-PR-UWYZ][A-HK-Y][0-9][0-9ABEHMNPRV-Y]?)"
    r"\s?[0-9][ABD-HJLNP-UW-Z]{2}"
)
SORT_CODE_VALUE = r"\d{2}(?:[ \-]?\d{2}){2}"
PHONE_VALUE = (
    r"(?:(?:\+|00)\d{1,3}[\s().\-]*|44[\s().\-]*|0)"
    r"(?:[\s().\-]*\d){6,14}"
)
ACCOUNT_VALUE = r"\d{6,12}"
CARD_VALUE = r"(?:\d[ \-]?){12,18}\d"
DOB_VALUE = (
    r"(?:\d{1,2}[/\.\-]\d{1,2}[/\.\-]\d{2,4}|"
    r"\d{4}[/\-]\d{2}[/\-]\d{2}|"
    r"\d{1,2}\s+(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|"
    r"Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|"
    r"Nov(?:ember)?|Dec(?:ember)?)\s+\d{4})"
)
DOB_DAY_VALUE = r"(?:0?[1-9]|[12]\d|3[01])"
DOB_MONTH_VALUE = r"(?:0?[1-9]|1[0-2])"
DOB_YEAR_VALUE = r"(?:\d{2}|(?:19|20)\d{2})"
IP_ADDRESS_VALUE = (
    r"(?:\d{1,3}\.){3}\d{1,3}|"
    r"(?:[0-9A-F]{1,4}:){2,7}[0-9A-F]{0,4}"
)
MAC_ADDRESS_VALUE = r"(?:[0-9A-F]{2}[:-]){5}[0-9A-F]{2}|[0-9A-F]{12}"
STRUCTURED_POSTCODE_VALUE = r"[A-Z0-9][A-Z0-9 \-]{1,14}[A-Z0-9]"
ADDRESS_TEXT_VALUE = r"[A-Z0-9À-ÖØ-öø-ÿ][^\"'\r\n<>]{1,220}?"


Validator = Callable[[str], bool]


def _structured_field_rules(
    *,
    name: str,
    kind: str,
    assignment_label: str,
    xml_label: str,
    value_pattern: str,
    replacement_fn: Any,
    renderer: Any,
    canonicalizer: Any,
    priority: int,
    validator: Validator = lambda _value: True,
    value_prefix: str = "",
    is_name_rule: bool = False,
) -> list[PatternRule]:
    """Create detectors for the common structured-log encodings of one field.

    Supported encodings include JSON/Splunk key-value data, pipe-delimited fields,
    XML elements (including namespaces and CDATA), and XML attributes. Only the
    captured value is replaced, so surrounding markup remains untouched.
    """

    assignment = re.compile(
        rf"(?<![\w.\-])(?:[\"']?(?:{assignment_label})[\"']?)"
        rf"\s*(?:[:=]|\s+-\s+|\|)\s*[\"']?{value_prefix}"
        rf"(?P<value>{value_pattern})"
        rf"(?=[\"']?(?:\s|[,.);:|&}}\]]|$))",
        re.I | re.MULTILINE,
    )

    # Capture the complete qualified tag so the closing-tag backreference also
    # handles namespaced fields such as <bank:sortCode>...</bank:sortCode>.
    xml_element = re.compile(
        rf"<(?P<tag>(?:[A-Za-z_][\w.\-]*:)?(?:{xml_label}))\b[^>]*>"
        rf"[ \t\r\n]*{value_prefix}(?P<value>{value_pattern})[ \t\r\n]*"
        rf"</(?P=tag)[ \t\r\n]*>",
        re.I,
    )
    xml_cdata = re.compile(
        rf"<(?P<tag>(?:[A-Za-z_][\w.\-]*:)?(?:{xml_label}))\b[^>]*>"
        rf"[ \t\r\n]*<!\[CDATA\[[ \t\r\n]*{value_prefix}"
        rf"(?P<value>{value_pattern})[ \t\r\n]*\]\]>[ \t\r\n]*"
        rf"</(?P=tag)[ \t\r\n]*>",
        re.I,
    )
    xml_attribute = re.compile(
        rf"(?<![\w:.\-])(?:[A-Za-z_][\w.\-]*:)?(?:{xml_label})"
        rf"\s*=\s*[\"'][ \t]*{value_prefix}(?P<value>{value_pattern})[ \t]*[\"']",
        re.I,
    )

    formats = (
        ("assignment", assignment),
        ("xml_element", xml_element),
        ("xml_cdata", xml_cdata),
        ("xml_attribute", xml_attribute),
    )
    return [
        PatternRule(
            name=f"{name}_{format_name}",
            kind=kind,
            regex=compiled,
            replacement_fn=replacement_fn,
            renderer=renderer,
            canonicalizer=canonicalizer,
            validator=validator,
            priority=priority,
            is_name_rule=is_name_rule,
        )
        for format_name, compiled in formats
    ]


def _structured_text_field_rules(
    *,
    name: str,
    kind: str,
    assignment_label: str,
    xml_label: str,
    replacement_fn: Any,
    priority: int,
) -> list[PatternRule]:
    """Structured free-text fields such as street/city/full address.

    Separate quote-aware rules avoid truncating values containing apostrophes,
    for example ``12 O'Connell Street`` inside a normal JSON double-quoted string.
    """

    base_assignment = rf"(?<![\w.\-])(?:[\"']?(?:{assignment_label})[\"']?)\s*(?:[:=]|\s+-\s+|\|)\s*"
    patterns: list[tuple[str, re.Pattern[str], str]] = [
        (
            "assignment_double",
            re.compile(base_assignment + r'"(?P<value>[^"\r\n<>]{2,220})"', re.I | re.MULTILINE),
            "value",
        ),
        (
            "assignment_single",
            re.compile(base_assignment + r"'(?P<value>[^'\r\n<>]{2,220})'", re.I | re.MULTILINE),
            "value",
        ),
        (
            "assignment_bare",
            re.compile(
                base_assignment + r"(?P<value>[A-Z0-9À-ÖØ-öø-ÿ][^,;|\r\n<>]{1,220}?)(?=\s*(?:[,;|]|$))",
                re.I | re.MULTILINE,
            ),
            "value",
        ),
        (
            "xml_element",
            re.compile(
                rf"<(?P<tag>(?:[A-Za-z_][\w.\-]*:)?(?:{xml_label}))\b[^>]*>\s*"
                rf"(?P<value>[^<\r\n]{{2,220}}?)\s*</(?P=tag)\s*>",
                re.I,
            ),
            "value",
        ),
        (
            "xml_cdata",
            re.compile(
                rf"<(?P<tag>(?:[A-Za-z_][\w.\-]*:)?(?:{xml_label}))\b[^>]*>\s*<!\[CDATA\[\s*"
                rf"(?P<value>[\s\S]{{2,220}}?)\s*\]\]>\s*</(?P=tag)\s*>",
                re.I,
            ),
            "value",
        ),
        (
            "attribute_double",
            re.compile(
                rf"(?<![\w:.\-])(?:[A-Za-z_][\w.\-]*:)?(?:{xml_label})\s*=\s*\"(?P<value>[^\"\r\n<>]{{2,220}})\"",
                re.I,
            ),
            "value",
        ),
        (
            "attribute_single",
            re.compile(
                rf"(?<![\w:.\-])(?:[A-Za-z_][\w.\-]*:)?(?:{xml_label})\s*=\s*'(?P<value>[^'\r\n<>]{{2,220}})'",
                re.I,
            ),
            "value",
        ),
    ]
    return [
        PatternRule(
            name=f"{name}_{format_name}",
            kind=kind,
            regex=compiled,
            replacement_fn=replacement_fn,
            renderer=render_plain,
            canonicalizer=canonical_exact,
            priority=priority,
            value_group=value_group,
        )
        for format_name, compiled, value_group in patterns
    ]


# Label patterns deliberately accept snake_case, kebab-case, ordinary spaces and
# camelCase (the separator is optional and matching is case-insensitive).
STRUCTURED_FIELD_RULES: list[PatternRule] = [
    *_structured_field_rules(
        name="email_labelled",
        kind="EMAIL",
        assignment_label=r"(?:e[ _-]*mail(?:[ _-]*address)?|email[ _-]*address)",
        xml_label=r"(?:e[_-]*mail(?:[_-]*address)?|email[_-]*address)",
        value_pattern=EMAIL_VALUE,
        replacement_fn=generate_email,
        renderer=render_plain,
        canonicalizer=canonical_email,
        priority=112,
    ),
    # Explicitly labelled IBANs are scrubbed even when MOD-97 is invalid. A bad
    # or test IBAN is still sensitive and may itself be relevant to the incident.
    *_structured_field_rules(
        name="iban_labelled",
        kind="IBAN",
        assignment_label=(
            r"(?:iban|international[ _-]*bank[ _-]*account[ _-]*(?:number|no\.?))"
        ),
        xml_label=(
            r"(?:iban|international[_-]*bank[_-]*account[_-]*(?:number|no))"
        ),
        value_pattern=IBAN_VALUE,
        replacement_fn=generate_iban,
        renderer=render_alnum,
        canonicalizer=canonical_alnum,
        priority=125,
    ),
    *_structured_field_rules(
        name="nino_labelled",
        kind="NINO",
        assignment_label=(
            r"(?:nino|ni[ _-]*(?:number|no\.?)|national[ _-]*insurance[ _-]*(?:number|no\.?))"
        ),
        xml_label=(
            r"(?:nino|ni[_-]*(?:number|no)|national[_-]*insurance[_-]*(?:number|no))"
        ),
        value_pattern=NINO_VALUE,
        replacement_fn=generate_nino,
        renderer=render_alnum,
        canonicalizer=canonical_alnum,
        priority=105,
        validator=nino_is_valid,
    ),
    *_structured_field_rules(
        name="postcode_labelled",
        kind="POSTCODE",
        assignment_label=r"(?:post[ _-]*code|postal[ _-]*code|zip[ _-]*code|eir[ _-]*code)",
        xml_label=r"(?:post[_-]*code|postal[_-]*code|zip[_-]*code|eir[_-]*code)",
        value_pattern=STRUCTURED_POSTCODE_VALUE,
        replacement_fn=generate_postcode,
        renderer=render_postcode,
        canonicalizer=canonical_alnum,
        priority=100,
    ),
    *_structured_field_rules(
        name="sort_code_labelled",
        kind="SORT_CODE",
        assignment_label=r"(?:sort[ _-]*code|bank[ _-]*sort[ _-]*code)",
        xml_label=r"(?:sort[_-]*code|bank[_-]*sort[_-]*code)",
        value_pattern=SORT_CODE_VALUE,
        replacement_fn=generate_sort_code,
        renderer=render_digits,
        canonicalizer=canonical_digits,
        priority=110,
    ),
    *_structured_field_rules(
        name="phone_labelled",
        kind="PHONE",
        assignment_label=(
            r"(?:phone(?:[ _-]*(?:number|no\.?))?|telephone(?:[ _-]*(?:number|no\.?))?|"
            r"mobile(?:[ _-]*(?:number|no\.?))?|contact[ _-]*(?:number|no\.?))"
        ),
        xml_label=(
            r"(?:phone(?:[_-]*(?:number|no))?|telephone(?:[_-]*(?:number|no))?|"
            r"mobile(?:[_-]*(?:number|no))?|contact[_-]*(?:number|no))"
        ),
        value_pattern=PHONE_VALUE,
        replacement_fn=generate_phone,
        renderer=render_phone,
        canonicalizer=canonical_phone,
        priority=105,
        validator=phone_is_valid,
    ),
    *_structured_field_rules(
        name="account_number_labelled",
        kind="ACCOUNT_NUMBER",
        assignment_label=(
            r"(?:account[ _-]*(?:number|no\.?|#)|acct[ _-]*(?:number|no\.?))"
        ),
        xml_label=r"(?:account[_-]*(?:number|no)|acct[_-]*(?:number|no))",
        value_pattern=ACCOUNT_VALUE,
        replacement_fn=generate_digits,
        renderer=render_digits,
        canonicalizer=canonical_digits,
        priority=105,
    ),
    # Labelled PAN/card fields are scrubbed even if Luhn fails, for the same reason
    # as labelled IBANs: malformed/test values are still sensitive log content.
    *_structured_field_rules(
        name="card_number_labelled",
        kind="CARD_NUMBER",
        assignment_label=(
            r"(?:card[ _-]*(?:number|no\.?|#)|pan|primary[ _-]*account[ _-]*number)"
        ),
        xml_label=(
            r"(?:card[_-]*(?:number|no)|pan|primary[_-]*account[_-]*number)"
        ),
        value_pattern=CARD_VALUE,
        replacement_fn=generate_card,
        renderer=render_digits,
        canonicalizer=canonical_digits,
        priority=122,
    ),
    *_structured_field_rules(
        name="date_of_birth_labelled",
        kind="DATE_OF_BIRTH",
        assignment_label=(
            r"(?:d[ _.-]*o[ _.-]*b|dob|date[ _-]*of[ _-]*birth|birth[ _-]*date|"
            r"birthdate|born[ _-]*(?:on|date))"
        ),
        xml_label=(
            r"(?:d[_-]*o[_-]*b|dob|date[_-]*of[_-]*birth|birth[_-]*date|"
            r"birthdate|born[_-]*(?:on|date))"
        ),
        value_pattern=DOB_VALUE,
        replacement_fn=generate_dob,
        renderer=render_dob,
        canonicalizer=canonical_dob,
        priority=108,
        validator=dob_is_valid,
    ),
    *_structured_field_rules(
        name="name_labelled",
        kind="NAME",
        assignment_label=(
            r"(?:customer[ _-]*name|client[ _-]*name|full[ _-]*name|"
            r"account[ _-]*holder(?:[ _-]*name)?|cardholder(?:[ _-]*name)?|"
            r"applicant[ _-]*name|beneficiary[ _-]*name|contact[ _-]*name)"
        ),
        xml_label=(
            r"(?:customer[_-]*name|client[_-]*name|full[_-]*name|"
            r"account[_-]*holder(?:[_-]*name)?|cardholder(?:[_-]*name)?|"
            r"applicant[_-]*name|beneficiary[_-]*name|contact[_-]*name)"
        ),
        value_pattern=FULL_NAME,
        value_prefix=r"(?:(?:Mr|Mrs|Ms|Miss|Dr)\.?\s+)?",
        replacement_fn=generate_name,
        renderer=render_plain,
        canonicalizer=canonical_name,
        priority=102,
        is_name_rule=True,
    ),
    *_structured_field_rules(
        name="surname_labelled",
        kind="SURNAME",
        assignment_label=(
            r"(?:sur[ _-]*name|last[ _-]*name|family[ _-]*name|familyname)"
        ),
        xml_label=(
            r"(?:sur[_-]*name|last[_-]*name|family[_-]*name|familyname)"
        ),
        value_pattern=NAME_COMPONENT,
        replacement_fn=generate_surname,
        renderer=render_preserve_case,
        canonicalizer=canonical_name,
        priority=113,
    ),
    *_structured_field_rules(
        name="first_name_labelled",
        kind="FIRST_NAME",
        assignment_label=(
            r"(?:first[ _-]*name|forename|given[ _-]*name|givenname)"
        ),
        xml_label=(
            r"(?:first[_-]*name|forename|given[_-]*name|givenname)"
        ),
        value_pattern=SINGLE_NAME,
        replacement_fn=generate_first_name,
        renderer=render_preserve_case,
        canonicalizer=canonical_name,
        priority=113,
    ),
    *_structured_field_rules(
        name="middle_name_labelled",
        kind="MIDDLE_NAME",
        assignment_label=r"(?:middle[ _-]*name|middlename)",
        xml_label=r"(?:middle[_-]*name|middlename)",
        value_pattern=SINGLE_NAME,
        replacement_fn=generate_first_name,
        renderer=render_preserve_case,
        canonicalizer=canonical_name,
        priority=111,
    ),
    *_structured_field_rules(
        name="dob_day_component_labelled",
        kind="DATE_OF_BIRTH_DAY",
        assignment_label=(
            r"(?:(?:d[ _.-]*o[ _.-]*b|dob|date[ _-]*of[ _-]*birth|birth[ _-]*date)"
            r"[ _-]*(?:dd|day))"
        ),
        xml_label=(
            r"(?:(?:d[_-]*o[_-]*b|dob|date[_-]*of[_-]*birth|birth[_-]*date)"
            r"[_-]*(?:dd|day))"
        ),
        value_pattern=DOB_DAY_VALUE,
        replacement_fn=generate_dob_day,
        renderer=render_dob_component,
        canonicalizer=canonical_digits,
        validator=dob_day_is_valid,
        priority=116,
    ),
    *_structured_field_rules(
        name="dob_month_component_labelled",
        kind="DATE_OF_BIRTH_MONTH",
        assignment_label=(
            r"(?:(?:d[ _.-]*o[ _.-]*b|dob|date[ _-]*of[ _-]*birth|birth[ _-]*date)"
            r"[ _-]*(?:mm|month))"
        ),
        xml_label=(
            r"(?:(?:d[_-]*o[_-]*b|dob|date[_-]*of[_-]*birth|birth[_-]*date)"
            r"[_-]*(?:mm|month))"
        ),
        value_pattern=DOB_MONTH_VALUE,
        replacement_fn=generate_dob_month,
        renderer=render_dob_component,
        canonicalizer=canonical_digits,
        validator=dob_month_is_valid,
        priority=116,
    ),
    *_structured_field_rules(
        name="dob_year_component_labelled",
        kind="DATE_OF_BIRTH_YEAR",
        assignment_label=(
            r"(?:(?:d[ _.-]*o[ _.-]*b|dob|date[ _-]*of[ _-]*birth|birth[ _-]*date)"
            r"[ _-]*(?:yyyy|yy|year))"
        ),
        xml_label=(
            r"(?:(?:d[_-]*o[_-]*b|dob|date[_-]*of[_-]*birth|birth[_-]*date)"
            r"[_-]*(?:yyyy|yy|year))"
        ),
        value_pattern=DOB_YEAR_VALUE,
        replacement_fn=generate_dob_year,
        renderer=render_dob_component,
        canonicalizer=canonical_digits,
        validator=dob_year_is_valid,
        priority=116,
    ),
    *_structured_field_rules(
        name="client_ip_labelled",
        kind="IP_ADDRESS",
        assignment_label=(
            r"(?:client[ _-]*ip|client[ _-]*ip[ _-]*address|ip[ _-]*address[ _-]*orig[ _-]*client|"
            r"originating[ _-]*ip|source[ _-]*ip|remote[ _-]*ip|customer[ _-]*ip)"
        ),
        xml_label=(
            r"(?:client[_-]*ip|client[_-]*ip[_-]*address|ip[_-]*address[_-]*orig[_-]*client|"
            r"originating[_-]*ip|source[_-]*ip|remote[_-]*ip|customer[_-]*ip)"
        ),
        value_pattern=IP_ADDRESS_VALUE,
        replacement_fn=generate_ip_address,
        renderer=render_plain,
        canonicalizer=canonical_exact,
        validator=ip_address_is_valid,
        priority=114,
    ),
    *_structured_field_rules(
        name="client_mac_labelled",
        kind="MAC_ADDRESS",
        assignment_label=(
            r"(?:client[ _-]*mac(?:[ _-]*address)?|device[ _-]*mac(?:[ _-]*address)?|mac[ _-]*address)"
        ),
        xml_label=(
            r"(?:client[_-]*mac(?:[_-]*address)?|device[_-]*mac(?:[_-]*address)?|mac[_-]*address)"
        ),
        value_pattern=MAC_ADDRESS_VALUE,
        replacement_fn=generate_mac_address,
        renderer=render_alnum,
        canonicalizer=canonical_alnum,
        validator=mac_address_is_valid,
        priority=114,
    ),
    *_structured_text_field_rules(
        name="full_address_labelled",
        kind="ADDRESS",
        assignment_label=(
            r"(?:(?:billing|shipping|residential|home|mailing|postal|customer|contact)"
            r"[ _-]*)?address"
        ),
        xml_label=(
            r"(?:(?:billing|shipping|residential|home|mailing|postal|customer|contact)"
            r"[_-]*)?address"
        ),
        replacement_fn=generate_full_address,
        priority=94,
    ),
    *_structured_text_field_rules(
        name="street_address_labelled",
        kind="STREET_ADDRESS",
        assignment_label=(
            r"(?:street(?:[ _-]*address)?|address[ _-]*line[ _-]*1|address1|"
            r"billing[ _-]*address[ _-]*line[ _-]*1|shipping[ _-]*address[ _-]*line[ _-]*1)"
        ),
        xml_label=(
            r"(?:street(?:[_-]*address)?|address[_-]*line[_-]*1|address1|"
            r"billing[_-]*address[_-]*line[_-]*1|shipping[_-]*address[_-]*line[_-]*1)"
        ),
        replacement_fn=generate_street_address,
        priority=96,
    ),
    *_structured_text_field_rules(
        name="city_labelled",
        kind="CITY",
        assignment_label=r"(?:city|town|locality|municipality|address[ _-]*city)",
        xml_label=r"(?:city|town|locality|municipality|address[_-]*city)",
        replacement_fn=generate_city,
        priority=90,
    ),
    *_structured_text_field_rules(
        name="region_labelled",
        kind="REGION",
        assignment_label=(
            r"(?:county|province|address[ _-]*(?:state|region|county|province)|"
            r"billing[ _-]*(?:state|region|county|province)|"
            r"shipping[ _-]*(?:state|region|county|province))"
        ),
        xml_label=(
            r"(?:county|province|address[_-]*(?:state|region|county|province)|"
            r"billing[_-]*(?:state|region|county|province)|"
            r"shipping[_-]*(?:state|region|county|province))"
        ),
        replacement_fn=generate_region,
        priority=88,
    ),
]


# This is the main extension point. Add another PatternRule here for a new
# organisation-specific format, or use custom_rules.json without changing code.
RULE_REGISTRY: list[PatternRule] = [
    *STRUCTURED_FIELD_RULES,
    PatternRule(
        name="email",
        kind="EMAIL",
        regex=re.compile(rf"(?<![\w.+-])(?P<value>{EMAIL_VALUE})(?![\w.-])", re.I),
        replacement_fn=generate_email,
        renderer=render_plain,
        canonicalizer=canonical_email,
        priority=90,
    ),
    # Unlabelled IBAN-shaped strings retain checksum validation to avoid turning arbitrary
    # long alphanumeric tokens into PII detections.
    PatternRule(
        name="iban",
        kind="IBAN",
        regex=re.compile(rf"(?<![A-Z0-9])(?P<value>{IBAN_VALUE})(?![A-Z0-9])", re.I),
        replacement_fn=generate_iban,
        renderer=render_alnum,
        canonicalizer=canonical_alnum,
        validator=iban_is_valid,
        priority=110,
    ),
    PatternRule(
        name="uk_nino",
        kind="NINO",
        regex=re.compile(rf"(?<![A-Z0-9])(?P<value>{NINO_VALUE})(?![A-Z0-9])", re.I),
        replacement_fn=generate_nino,
        renderer=render_alnum,
        canonicalizer=canonical_alnum,
        validator=nino_is_valid,
        priority=85,
    ),
    PatternRule(
        name="uk_postcode",
        kind="POSTCODE",
        regex=re.compile(rf"(?<![A-Z0-9])(?P<value>{POSTCODE_VALUE})(?![A-Z0-9])", re.I),
        replacement_fn=generate_postcode,
        renderer=render_postcode,
        canonicalizer=canonical_alnum,
        validator=postcode_is_valid,
        priority=60,
    ),
    PatternRule(
        name="uk_sort_code",
        kind="SORT_CODE",
        regex=re.compile(r"(?<!\d)(?P<value>\d{2}[ \-]\d{2}[ \-]\d{2})(?!\d)"),
        replacement_fn=generate_sort_code,
        renderer=render_digits,
        canonicalizer=canonical_digits,
        priority=65,
    ),
    PatternRule(
        name="international_or_uk_phone",
        kind="PHONE",
        regex=re.compile(
            r"(?<!\d)(?P<value>(?:(?:\+|00)\d{1,3}[\s().\-]*|0)(?:[\s().\-]*\d){6,14})(?!\d)"
        ),
        replacement_fn=generate_phone,
        renderer=render_phone,
        canonicalizer=canonical_phone,
        validator=phone_is_valid,
        priority=70,
    ),
    PatternRule(
        name="card_number_luhn",
        kind="CARD_NUMBER",
        regex=re.compile(rf"(?<!\d)(?P<value>{CARD_VALUE})(?!\d)"),
        replacement_fn=generate_card,
        renderer=render_digits,
        canonicalizer=canonical_digits,
        validator=luhn_is_valid,
        priority=100,
    ),
    PatternRule(
        name="mac_address",
        kind="MAC_ADDRESS",
        regex=re.compile(rf"(?<![0-9A-F])(?P<value>{MAC_ADDRESS_VALUE})(?![0-9A-F])", re.I),
        replacement_fn=generate_mac_address,
        renderer=render_alnum,
        canonicalizer=canonical_alnum,
        validator=mac_address_is_valid,
        priority=76,
    ),
    PatternRule(
        name="name_line_labelled",
        kind="NAME",
        regex=re.compile(
            rf"(?m)^[ \t]*(?i:Name)\s*(?:[:=]|\s+-\s+)\s*[\"']?"
            rf"(?:(?:Mr|Mrs|Ms|Miss|Dr)\.?\s+)?(?P<value>{FULL_NAME})"
        ),
        replacement_fn=generate_name,
        renderer=render_plain,
        canonicalizer=canonical_name,
        priority=54,
        is_name_rule=True,
    ),
    PatternRule(
        name="name_titled",
        kind="NAME",
        regex=re.compile(rf"\b(?:(?:Mr|Mrs|Ms|Miss|Dr)\.?\s+)(?P<value>{FULL_NAME})\b"),
        replacement_fn=generate_name,
        renderer=render_plain,
        canonicalizer=canonical_name,
        priority=56,
        is_name_rule=True,
    ),
]


_CUSTOM_GENERATORS: dict[str, tuple[Any, Any, Any]] = {
    "mask": (generate_mask, render_alnum, canonical_exact),
    "digits": (generate_digits, render_digits, canonical_digits),
}


def load_custom_rules(path: Path | None) -> list[PatternRule]:
    """Load optional local rules from JSON. Invalid files fail loudly and safely."""

    if path is None or not path.exists():
        return []
    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise ValueError("custom_rules.json must contain a JSON array")
    rules: list[PatternRule] = []
    for index, item in enumerate(raw, start=1):
        if not isinstance(item, dict):
            raise ValueError(f"Custom rule {index} must be an object")
        kind = str(item["kind"]).strip().upper()
        regex_text = str(item["regex"])
        generator_name = str(item.get("generator", "mask")).strip().lower()
        if generator_name not in _CUSTOM_GENERATORS:
            raise ValueError(f"Custom rule {index}: unsupported generator {generator_name!r}")
        replacement_fn, renderer, canonicalizer = _CUSTOM_GENERATORS[generator_name]
        flags = re.MULTILINE
        if item.get("ignore_case", True):
            flags |= re.IGNORECASE
        compiled = re.compile(regex_text, flags)
        if "value" not in compiled.groupindex:
            raise ValueError(f"Custom rule {index} must include a named capture group (?P<value>...)")
        rules.append(
            PatternRule(
                name=str(item.get("name", f"custom_{index}")),
                kind=kind,
                regex=compiled,
                replacement_fn=replacement_fn,
                renderer=renderer,
                canonicalizer=canonicalizer,
                priority=int(item.get("priority", 72)),
            )
        )
    return rules
