from __future__ import annotations

import json
import re
from dataclasses import dataclass
from xml.dom import minidom
from xml.parsers.expat import ExpatError


@dataclass(frozen=True)
class FormatResult:
    text: str
    format_name: str


def _indent_block(block: str, prefix: str) -> str:
    lines = block.splitlines()
    if not lines:
        return block
    return lines[0] + "".join("\n" + prefix + line for line in lines[1:])


def _pretty_json_value(value: object) -> str:
    return json.dumps(value, indent=2, ensure_ascii=False)


def _try_whole_json(text: str) -> str | None:
    stripped = text.strip()
    if not stripped or stripped[0] not in "[{":
        return None
    try:
        value = json.loads(stripped)
    except (json.JSONDecodeError, ValueError):
        return None
    leading = text[: len(text) - len(text.lstrip())]
    trailing = text[len(text.rstrip()) :]
    return leading + _pretty_json_value(value) + trailing


def _pretty_embedded_json(text: str) -> tuple[str, bool]:
    decoder = json.JSONDecoder()
    out: list[str] = []
    cursor = 0
    index = 0
    changed = False
    while index < len(text):
        if text[index] not in "[{":
            index += 1
            continue
        try:
            value, consumed = decoder.raw_decode(text[index:])
        except json.JSONDecodeError:
            index += 1
            continue
        if not isinstance(value, (dict, list)) or consumed < 2:
            index += 1
            continue
        end = index + consumed
        original = text[index:end]
        # Do not turn tiny technical arrays such as [1/3] into multi-line blocks.
        if len(original) < 24 and "{" not in original:
            index = end
            continue
        line_start = text.rfind("\n", 0, index) + 1
        prefix = re.match(r"[ \t]*", text[line_start:index]).group(0)  # type: ignore[union-attr]
        pretty = _indent_block(_pretty_json_value(value), prefix)
        out.append(text[cursor:index])
        out.append(pretty)
        cursor = end
        index = end
        changed = changed or pretty != original
    out.append(text[cursor:])
    return "".join(out), changed


def _pretty_xml_fragment(fragment: str) -> str | None:
    try:
        dom = minidom.parseString(fragment)
    except (ExpatError, ValueError):
        return None
    rendered = dom.toprettyxml(indent="  ")
    lines = [line for line in rendered.splitlines() if line.strip()]
    if not fragment.lstrip().startswith("<?xml") and lines and lines[0].startswith("<?xml"):
        lines.pop(0)
    return "\n".join(lines)


def _try_whole_xml(text: str) -> str | None:
    stripped = text.strip()
    if not stripped.startswith("<") or not stripped.endswith(">"):
        return None
    pretty = _pretty_xml_fragment(stripped)
    if pretty is None:
        return None
    leading = text[: len(text) - len(text.lstrip())]
    trailing = text[len(text.rstrip()) :]
    return leading + pretty + trailing


def _pretty_embedded_xml(text: str) -> tuple[str, bool]:
    # First try the broadest plausible XML span. This handles a timestamp/log
    # prefix followed by a complete XML payload without attempting to parse the
    # non-XML prefix itself.
    first = text.find("<")
    last = text.rfind(">")
    if first == -1 or last <= first:
        return text, False
    fragment = text[first : last + 1]
    pretty = _pretty_xml_fragment(fragment)
    if pretty is None:
        return text, False
    line_start = text.rfind("\n", 0, first) + 1
    prefix = re.match(r"[ \t]*", text[line_start:first]).group(0)  # type: ignore[union-attr]
    pretty = _indent_block(pretty, prefix)
    return text[:first] + pretty + text[last + 1 :], pretty != fragment


def pretty_print_log(text: str) -> FormatResult:
    whole_json = _try_whole_json(text)
    if whole_json is not None:
        return FormatResult(whole_json, "json")

    whole_xml = _try_whole_xml(text)
    if whole_xml is not None:
        return FormatResult(whole_xml, "xml")

    with_json, json_changed = _pretty_embedded_json(text)
    with_xml, xml_changed = _pretty_embedded_xml(with_json)
    if json_changed and xml_changed:
        return FormatResult(with_xml, "mixed")
    if json_changed:
        return FormatResult(with_json, "json")
    if xml_changed:
        return FormatResult(with_xml, "xml")
    return FormatResult(text, "plain")


_JSON_STRING = re.compile(r'"(?:\\.|[^"\\])*"')
_JSON_NUMBER = re.compile(r"(?<![\w.])-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?(?![\w.])")
_JSON_LITERAL = re.compile(r"\b(?:true|false|null)\b")
_XML_COMMENT = re.compile(r"<!--[\s\S]*?-->")
_XML_CDATA = re.compile(r"<!\[CDATA\[[\s\S]*?\]\]>")
_XML_TAG = re.compile(r"</?[A-Za-z_][\w:.-]*(?:\s+[^<>]*?)?/?>")
_XML_ATTR = re.compile(r"\b[A-Za-z_:][\w:.-]*(?=\s*=)")
_TIMESTAMP = re.compile(
    r"\b\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:[.,]\d+)?(?:Z|\s+UTC|[+-]\d{2}:?\d{2})?\b"
)
_LOG_LEVEL = re.compile(r"\b(?:TRACE|DEBUG|INFO|WARN(?:ING)?|ERROR|CRITICAL|FATAL)\b")


def syntax_spans(text: str, format_name: str, max_spans: int = 30000) -> list[tuple[str, int, int]]:
    spans: list[tuple[str, int, int]] = []

    def add(kind: str, start: int, end: int) -> None:
        if len(spans) < max_spans:
            spans.append((kind, start, end))

    if format_name in {"json", "mixed"}:
        for match in _JSON_STRING.finditer(text):
            rest = text[match.end() : match.end() + 32]
            kind = "json_key" if re.match(r"\s*:", rest) else "string"
            add(kind, match.start(), match.end())
        for match in _JSON_NUMBER.finditer(text):
            add("number", match.start(), match.end())
        for match in _JSON_LITERAL.finditer(text):
            add("literal", match.start(), match.end())

    if format_name in {"xml", "mixed"}:
        protected: list[tuple[int, int]] = []
        for regex, kind in ((_XML_COMMENT, "comment"), (_XML_CDATA, "string")):
            for match in regex.finditer(text):
                protected.append(match.span())
                add(kind, match.start(), match.end())
        for match in _XML_TAG.finditer(text):
            if any(start <= match.start() < end for start, end in protected):
                continue
            add("xml_tag", match.start(), match.end())
            for attribute in _XML_ATTR.finditer(match.group(0)):
                add("xml_attr", match.start() + attribute.start(), match.start() + attribute.end())

    # These are useful for JSON/XML embedded in ordinary application logs too.
    for match in _TIMESTAMP.finditer(text):
        add("timestamp", match.start(), match.end())
    for match in _LOG_LEVEL.finditer(text):
        add("log_level", match.start(), match.end())

    return spans
