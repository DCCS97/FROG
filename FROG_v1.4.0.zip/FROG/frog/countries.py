from __future__ import annotations

import re
from dataclasses import dataclass

import pycountry
from faker.config import AVAILABLE_LOCALES


# Prefer a locale whose provider data belongs to the original country. The map
# deliberately covers the countries most commonly encountered in payment and
# financial-services logs. Unknown countries fall back to a language-neutral
# generator while the original country field/code is still preserved.
COUNTRY_LOCALES: dict[str, str] = {
    "AD": "ca_ES",
    "AE": "ar_AA",
    "AR": "es_AR",
    "AT": "de_AT",
    "AU": "en_AU",
    "BE": "nl_BE",
    "BG": "bg_BG",
    "BR": "pt_BR",
    "CA": "en_CA",
    "CH": "de_CH",
    "CL": "es_CL",
    "CN": "zh_CN",
    "CO": "es_CO",
    "CZ": "cs_CZ",
    "DE": "de_DE",
    "DK": "da_DK",
    "EE": "et_EE",
    "ES": "es_ES",
    "FI": "fi_FI",
    "FR": "fr_FR",
    "GB": "en_GB",
    "GR": "el_GR",
    "HK": "zh_HK",
    "HR": "hr_HR",
    "HU": "hu_HU",
    "ID": "id_ID",
    "IE": "en_IE",
    "IL": "he_IL",
    "IN": "en_IN",
    "IS": "is_IS",
    "IT": "it_IT",
    "JP": "ja_JP",
    "KR": "ko_KR",
    "LT": "lt_LT",
    "LU": "fr_LU",
    "LV": "lv_LV",
    "MX": "es_MX",
    "MY": "ms_MY",
    "NL": "nl_NL",
    "NO": "no_NO",
    "NZ": "en_NZ",
    "PE": "es_PE",
    "PH": "en_PH",
    "PK": "en_PK",
    "PL": "pl_PL",
    "PT": "pt_PT",
    "RO": "ro_RO",
    "RS": "sr_RS",
    "RU": "ru_RU",
    "SA": "ar_SA",
    "SE": "sv_SE",
    "SG": "en_SG",
    "SI": "sl_SI",
    "SK": "sk_SK",
    "TH": "th_TH",
    "TR": "tr_TR",
    "TW": "zh_TW",
    "UA": "uk_UA",
    "US": "en_US",
    "VN": "vi_VN",
    "ZA": "en_ZA",
}

# Common operational aliases that pycountry does not always resolve directly.
_COUNTRY_ALIASES: dict[str, str] = {
    "uk": "GB",
    "u.k.": "GB",
    "great britain": "GB",
    "britain": "GB",
    "united kingdom": "GB",
    "england": "GB",
    "scotland": "GB",
    "wales": "GB",
    "northern ireland": "GB",
    "republic of ireland": "IE",
    "eire": "IE",
    "éire": "IE",
    "ireland": "IE",
    "usa": "US",
    "u.s.a.": "US",
    "united states": "US",
    "united states of america": "US",
    "south korea": "KR",
    "north korea": "KP",
    "russia": "RU",
    "vietnam": "VN",
    "czech republic": "CZ",
    "czechia": "CZ",
    "uae": "AE",
    "u.a.e.": "AE",
    "hong kong": "HK",
    "taiwan": "TW",
}


@dataclass(frozen=True)
class CountryHint:
    start: int
    end: int
    code: str
    raw: str


def normalise_country(value: str) -> str | None:
    cleaned = " ".join(value.strip().strip('"\'').split())
    if not cleaned:
        return None
    alias = _COUNTRY_ALIASES.get(cleaned.casefold())
    if alias:
        return alias
    compact = re.sub(r"[^A-Za-z]", "", cleaned)
    if len(compact) == 2:
        candidate = compact.upper()
        if pycountry.countries.get(alpha_2=candidate):
            return candidate
    if len(compact) == 3:
        country = pycountry.countries.get(alpha_3=compact.upper())
        if country:
            return country.alpha_2
    try:
        return pycountry.countries.lookup(cleaned).alpha_2
    except LookupError:
        return None


def country_name(code: str | None) -> str | None:
    if not code:
        return None
    country = pycountry.countries.get(alpha_2=code.upper())
    return country.name if country else code.upper()


def faker_locale_for_country(code: str | None) -> str:
    candidate = COUNTRY_LOCALES.get((code or "GB").upper(), "en_GB")
    if candidate in AVAILABLE_LOCALES:
        return candidate
    return "en_GB"


# Structured country fields are context rather than PII: they remain untouched,
# but are used to keep generated addresses in the same country.
_COUNTRY_LABEL = r"(?:country(?:[ _-]*(?:code|name))?|nation)"
_COUNTRY_VALUE = r"[A-Za-zÀ-ÖØ-öø-ÿ][A-Za-zÀ-ÖØ-öø-ÿ .'-]{0,63}|[A-Za-z]{2,3}"
_COUNTRY_PATTERNS = (
    re.compile(
        rf"(?<![\w.\-])[\"']?(?:{_COUNTRY_LABEL})[\"']?\s*(?:[:=]|\|)\s*[\"']?(?P<value>{_COUNTRY_VALUE})(?=[\"']?(?:\s|[,.;)|&}}\]]|$))",
        re.I | re.MULTILINE,
    ),
    re.compile(
        rf"<(?P<tag>(?:[A-Za-z_][\w.\-]*:)?{_COUNTRY_LABEL})\b[^>]*>\s*(?P<value>{_COUNTRY_VALUE})\s*</(?P=tag)\s*>",
        re.I,
    ),
    re.compile(
        rf"(?<![\w:.\-])(?:[A-Za-z_][\w.\-]*:)?{_COUNTRY_LABEL}\s*=\s*[\"']\s*(?P<value>{_COUNTRY_VALUE})\s*[\"']",
        re.I,
    ),
)


def extract_country_hints(text: str) -> list[CountryHint]:
    found: dict[tuple[int, int, str], CountryHint] = {}
    for pattern in _COUNTRY_PATTERNS:
        for match in pattern.finditer(text):
            raw = match.group("value").strip()
            code = normalise_country(raw)
            if not code:
                continue
            start, end = match.span("value")
            found[(start, end, code)] = CountryHint(start, end, code, raw)
    return sorted(found.values(), key=lambda hint: (hint.start, hint.end))


def nearest_country_hint(
    position: int,
    hints: list[CountryHint],
    *,
    max_distance: int = 1600,
) -> str | None:
    if not hints:
        return None
    best: CountryHint | None = None
    best_distance = max_distance + 1
    for hint in hints:
        if position < hint.start:
            distance = hint.start - position
        elif position > hint.end:
            distance = position - hint.end
        else:
            distance = 0
        if distance < best_distance:
            best = hint
            best_distance = distance
    return best.code if best and best_distance <= max_distance else None


def infer_country_from_postal_code(value: str) -> str | None:
    compact = " ".join(value.upper().split())
    if re.fullmatch(
        r"(?:GIR 0AA|(?:[A-PR-UWYZ][0-9][0-9A-HJKPSTUW]?|[A-PR-UWYZ][A-HK-Y][0-9][0-9ABEHMNPRV-Y]?) [0-9][ABD-HJLNP-UW-Z]{2})",
        compact,
    ):
        return "GB"
    # Irish Eircode: routing key plus unique identifier, e.g. D02 X285.
    if re.fullmatch(r"[AC-FHKNPRTV-Y][0-9][0-9W][ ]?[0-9AC-FHKNPRTV-Y]{4}", compact):
        return "IE"
    if re.fullmatch(r"\d{2}-\d{3}", compact):
        return "PL"
    if re.fullmatch(r"\d{5}", compact):
        # Many countries use five digits; context is required to distinguish them.
        return None
    if re.fullmatch(r"[A-Z]\d[A-Z] ?\d[A-Z]\d", compact):
        return "CA"
    if re.fullmatch(r"\d{5}(?:-\d{4})?", compact):
        return "US"
    return None
