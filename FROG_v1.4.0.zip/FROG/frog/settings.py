from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any


DEFAULT_PREFERENCES: dict[str, Any] = {
    "mode": "synthetic",
    "include_preamble": True,
    "auto_scrub": False,
    "pretty_print": False,
    "interface_style": "Retro 90s",
    "appearance": "Light",
}


def settings_path() -> Path:
    appdata = os.environ.get("APPDATA")
    root = Path(appdata) if appdata else Path.home() / ".config"
    return root / "FROG" / "settings.json"


def _validated(raw: object) -> dict[str, Any]:
    prefs = dict(DEFAULT_PREFERENCES)
    if not isinstance(raw, dict):
        return prefs
    if raw.get("mode") in {"synthetic", "redact"}:
        prefs["mode"] = raw["mode"]
    for key in ("include_preamble", "auto_scrub", "pretty_print"):
        if isinstance(raw.get(key), bool):
            prefs[key] = raw[key]
    if raw.get("interface_style") in {"Retro 90s", "Modern sleek"}:
        prefs["interface_style"] = raw["interface_style"]
    if raw.get("appearance") in {"Light", "Dark"}:
        prefs["appearance"] = raw["appearance"]
    return prefs


def load_preferences(path: Path | None = None) -> dict[str, Any]:
    target = path or settings_path()
    try:
        return _validated(json.loads(target.read_text(encoding="utf-8")))
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return dict(DEFAULT_PREFERENCES)


def save_preferences(preferences: dict[str, Any], path: Path | None = None) -> None:
    target = path or settings_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    clean = _validated(preferences)
    temporary = target.with_suffix(".tmp")
    temporary.write_text(json.dumps(clean, indent=2, sort_keys=True), encoding="utf-8")
    temporary.replace(target)
