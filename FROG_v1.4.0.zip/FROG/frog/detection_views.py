from __future__ import annotations

import html
import re
from array import array
from dataclasses import dataclass


_ENTITY_CANDIDATE = re.compile(
    r"&(?# entity start)(?:\s*)(?:#(?:x[0-9A-Fa-f\s]+|[0-9\s]+)|[A-Za-z][A-Za-z0-9\s]{1,30})(?:\s*);"
)
_TAG_NAME_CHAR = re.compile(r"[A-Za-z0-9_:.-]")


@dataclass(frozen=True)
class DetectionView:
    """A transformed detection-only view with offsets mapped to source text.

    The transformed text is never returned to the user.  It exists so FROG can
    recognise PII inside HTML-escaped XML and lightly damaged line-wrapped tags
    while replacements are still applied to the exact original source spans.
    """

    text: str
    starts: array | None = None
    ends: array | None = None
    name: str = "original"

    def source_span(self, start: int, end: int) -> tuple[int, int]:
        if start < 0 or end <= start or end > len(self.text):
            raise ValueError("Invalid transformed-text span")
        if self.starts is None or self.ends is None:
            return start, end
        return int(self.starts[start]), int(self.ends[end - 1])


def _identity(text: str) -> DetectionView:
    return DetectionView(text=text, name="original")


def _append_mapped(
    output: list[str], starts: array, ends: array, value: str, source_start: int, source_end: int
) -> None:
    for character in value:
        output.append(character)
        starts.append(source_start)
        ends.append(source_end)


def _decode_entities(view: DetectionView) -> DetectionView:
    text = view.text
    output: list[str] = []
    starts = array("I")
    ends = array("I")
    cursor = 0
    changed = False

    for match in _ENTITY_CANDIDATE.finditer(text):
        if match.start() < cursor:
            continue
        token = match.group(0)
        compact = re.sub(r"\s+", "", token)
        decoded = html.unescape(compact)
        if decoded == compact or decoded.startswith("&") and decoded.endswith(";"):
            continue

        for index in range(cursor, match.start()):
            source_start, source_end = view.source_span(index, index + 1)
            _append_mapped(output, starts, ends, text[index], source_start, source_end)

        source_start, _ = view.source_span(match.start(), match.start() + 1)
        _, source_end = view.source_span(match.end() - 1, match.end())
        _append_mapped(output, starts, ends, decoded, source_start, source_end)
        cursor = match.end()
        changed = True

    if not changed:
        return view

    for index in range(cursor, len(text)):
        source_start, source_end = view.source_span(index, index + 1)
        _append_mapped(output, starts, ends, text[index], source_start, source_end)

    return DetectionView("".join(output), starts, ends, name="entity-decoded")


def _repair_soft_wrapped_tag_names(view: DetectionView) -> DetectionView:
    """Remove newlines that split an XML tag name, but not attribute spacing.

    Examples repaired only in the detection view:
      <DATEOFBIRTH_\nDD>  -> <DATEOFBIRTH_DD>
      </SUR\nNAME>        -> </SURNAME>

    Whitespace after the tag name or between attributes is preserved.
    """

    text = view.text
    output: list[str] = []
    starts = array("I")
    ends = array("I")
    index = 0
    in_tag = False
    in_tag_name = False
    quote: str | None = None
    changed = False

    def append_index(source_index: int) -> None:
        source_start, source_end = view.source_span(source_index, source_index + 1)
        _append_mapped(output, starts, ends, text[source_index], source_start, source_end)

    while index < len(text):
        char = text[index]

        if not in_tag:
            append_index(index)
            if char == "<":
                in_tag = True
                in_tag_name = True
                quote = None
            index += 1
            continue

        if quote:
            append_index(index)
            if char == quote:
                quote = None
            index += 1
            continue

        if char in {'"', "'"}:
            quote = char
            append_index(index)
            index += 1
            continue

        if char == ">":
            append_index(index)
            in_tag = False
            in_tag_name = False
            index += 1
            continue

        if in_tag_name and char == "/" and len(output) and output[-1] == "<":
            append_index(index)
            index += 1
            continue

        if in_tag_name and char.isspace():
            run_end = index
            has_newline = False
            while run_end < len(text) and text[run_end].isspace():
                has_newline = has_newline or text[run_end] in "\r\n"
                run_end += 1

            previous = output[-1] if output else ""
            following = text[run_end] if run_end < len(text) else ""
            if (
                has_newline
                and previous
                and following
                and _TAG_NAME_CHAR.fullmatch(previous)
                and _TAG_NAME_CHAR.fullmatch(following)
            ):
                index = run_end
                changed = True
                continue

            # Ordinary whitespace marks the end of the element name and the
            # beginning of attributes; it must not be removed.
            for source_index in range(index, run_end):
                append_index(source_index)
            in_tag_name = False
            index = run_end
            continue

        append_index(index)
        if in_tag_name and not _TAG_NAME_CHAR.fullmatch(char):
            # Processing instructions/comments are not field names.
            if char not in {"?", "!"}:
                in_tag_name = False
        index += 1

    if not changed:
        return view
    return DetectionView("".join(output), starts, ends, name="repaired-markup")


def build_detection_views(text: str) -> list[DetectionView]:
    """Return source plus useful normalised views, without changing source text."""

    views = [_identity(text)]
    if "&" not in text and "<" not in text:
        return views

    transformed = views[0]
    # Two rounds handle common double-escaping such as &amp;lt;SURNAME&amp;gt;.
    for _ in range(2):
        decoded = _decode_entities(transformed)
        if decoded.text == transformed.text:
            break
        transformed = decoded

    transformed = _repair_soft_wrapped_tag_names(transformed)
    if transformed.text != text:
        views.append(transformed)
    return views
