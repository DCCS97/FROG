# FROG — Field Redaction & Obfuscation Gadget

FROG is a lightweight, local/offline Windows utility for pseudonymising likely PII in support logs before the log is pasted into an approved LLM chat tool. It preserves repeated-value relationships and creates a separate local-only fake → real mapping.

> **Important:** FROG is a risk-reduction aid, not a certified DLP product. Pattern matching cannot guarantee that every proprietary field or free-form address is detected. Review the output before sharing it and follow your organisation's policies. FROG has no network functionality and does not automatically save logs or mappings.

## New in v1.4.0

### Escaped and damaged structured-log detection

- FROG now scans a detection-only normalised view of HTML/XML-escaped payloads such as `&lt;SURNAME&gt;DAVIS&lt;/SURNAME&gt;`. The source log is not decoded or reformatted; only the detected value is replaced in the original text.
- Common double-escaping such as `&amp;lt;SURNAME&amp;gt;...` is recognised.
- Broken HTML entities split by display wrapping, for example `&g\nt;`, are repaired for detection only.
- Newlines that split XML field names, for example `<DATEOFBIRTH_\nDD>`, are repaired in the detection view while the pasted layout remains unchanged.
- Offset mapping ensures replacements are written back to the correct source span even though the detector is operating on decoded markup.

### Additional PII fields

- Labelled surname/family-name fields: `SURNAME`, `lastName`, `family_name`.
- Labelled first/forename and middle-name fields.
- Split date-of-birth fields such as `DATEOFBIRTH_DD`, `DATEOFBIRTH_MM` and `DATEOFBIRTH_YYYY`. Adjacent components are generated from one internally consistent synthetic date.
- Labelled client/originating IP addresses. Public IPv4 replacements use the documentation-only `192.0.2.0/24` range; private, loopback and link-local classifications are preserved.
- Labelled and distinctively formatted MAC addresses. Replacements use a locally administered unicast address rather than a real vendor OUI.

## New in v1.3.1

### Dual-pane pretty-print

- The remembered **Pretty-print input + output** toggle now formats and syntax-highlights both panes.
- Pasted or loaded JSON/XML is automatically indented in the input pane after a short debounce.
- The scrubbed output uses the same formatting mode, making side-by-side comparison easier.
- When Pretty Print is switched off, FROG restores the original input layout if the formatted input has not been manually edited. If it has been edited, those edits are preserved.
- Syntax colours remain display-only; copied and saved output is ordinary plain text.

## Added in v1.3.0

### International origin preservation

- IBAN replacements retain the source country code, length, letter/digit positions, separators and a valid MOD-97 checksum. An Irish `IE...` IBAN remains Irish; Spanish `ES...` remains Spanish; Polish `PL...` remains Polish, and so on.
- International telephone numbers retain their calling country. `+48` remains `+48`, `+353` remains `+353`, and `+44` remains `+44`. A number with no country prefix is interpreted as UK data.
- Structured address fields are now detected. When a nearby/nested `country` or `countryCode` field is present, street, city and postal-code replacements use a Faker locale for that country. A British address and an Irish IBAN in the same record remain independently British and Irish.
- The local-only mapping records the preserved origin country.

### More field aliases

Date-of-birth labels include `dob`, `d.o.b`, `dateOfBirth`, `date_of_birth`, `birthDate`, `birth-date`, and `bornOn`, including JSON, XML, XML attributes, CDATA, Splunk key/value and pipe-delimited forms.

### Remembered preferences

FROG remembers these non-sensitive UI settings between launches:

- Synthetic / Redact mode
- Include LLM preamble
- Auto-scrub
- Pretty-print
- Retro / Modern interface
- Light / Dark appearance

Preferences are stored in the current user's application-data folder (`%APPDATA%\FROG\settings.json`). The seed, known-names path, logs and mappings are **not** persisted as preferences.

### Automatic pretty-print and syntax colour

The optional **Pretty-print input + output** toggle:

- Auto-detects complete or embedded JSON/XML payloads in both panes
- Indents recognised input before scrubbing and applies the same layout to output
- Adds local display-only syntax colours for keys, strings, numbers, tags, attributes, timestamps and log levels
- Leaves unrecognised plain logs unchanged
- Copies/saves ordinary text only; colours are not embedded in clipboard output

Input pretty-printing is display/layout processing before scrubbing, while output pretty-printing is applied to the scrubbed text. Neither changes the replacement mapping or PII detection semantics.

## Structured formats recognised

Built-in labelled PII rules understand:

- XML elements: `<sortcode>123456</sortcode>`
- HTML-escaped XML: `&lt;sortcode&gt;123456&lt;/sortcode&gt;`
- Double-escaped and lightly line-wrapped XML field names
- Namespaced XML: `<bank:sortCode>123456</bank:sortCode>`
- XML CDATA: `<sortCode><![CDATA[123456]]></sortCode>`
- XML attributes: `<payment sortCode="123456" accountNumber="87654321"/>`
- JSON: `"sort_code": "123456"`
- Splunk/key-value text: `sortCode=123456`
- Pipe-delimited fields: `sort-code|123456`

Labels may use spaces, snake_case, kebab-case or camelCase. Only the captured value is replaced; markup and labels remain intact.

## What it detects

- Email addresses
- International IBAN candidates
- UK National Insurance numbers
- UK postcodes and labelled international postal codes
- UK sort codes, including compact six-digit values when labelled
- International telephone numbers with explicit `+`/`00` calling codes; local numbers default to UK
- Label-anchored account numbers
- Luhn-valid card candidates, plus explicitly labelled card/PAN fields even if malformed
- Label-anchored dates of birth and common aliases such as `dob`
- Split DOB components such as `DATEOFBIRTH_DD`, `_MM`, `_YY` and `_YYYY`
- Labelled/titled full names, labelled first/middle/surname fields, plus an optional one-name-per-line known-names file
- Labelled client/originating IP addresses and MAC addresses
- Labelled full address, street/address-line, city/town/locality, postal-code and selected region fields

Country fields are used as context and intentionally remain unchanged.

## Country-aware address behaviour

Example input:

```json
{
  "irish_address": {
    "street": "12 O'Connell Street",
    "city": "Dublin",
    "postal_code": "D02 X285",
    "country": "Ireland"
  },
  "iban": "IE29AIBK93115212345678",
  "uk_address": {
    "street": "82 Deansgate",
    "city": "Manchester",
    "postal_code": "M3 2ER",
    "country": "United Kingdom"
  }
}
```

FROG uses the smallest enclosing JSON object when assigning country context, so adjacent address records do not contaminate one another. For XML and line-oriented logs, it uses a bounded nearest-country rule. When no country can be inferred for an address/local telephone number, GB is the operational default.

Faker locale coverage varies by country. Common financial-services countries have explicit locale mappings. For unsupported locales, FROG preserves the original country field/code and generates a format-shaped fallback rather than changing the origin to GB.

## Seed behaviour

A supplied seed makes generation deterministic. For example, using the ServiceNow incident number:

```text
INC123456789
```

means the same original value, detected as the same PII kind and country, receives the same synthetic value when processed again with that exact seed and FROG version.

The seed is not encryption and does not reverse the mapping. It is not saved in the preference file. Use one seed per incident and keep the local-only mapping secure.

## Auto-scrub behaviour

When **Auto-scrub after paste/edit** is enabled, FROG waits about 550 ms after an edit, then runs the scrubber on a worker thread. If input changes while a pass is running, the stale result is discarded and one fresh pass is queued.

## No-admin source setup on Windows

1. Extract the FROG folder somewhere writable.
2. Double-click `setup_no_admin.bat`.
3. Double-click `run_frog.bat`.

The scripts support Microsoft Store Python installations that provide `python` but not the older `py` launcher.

## Build the standalone Windows executable

Build on **Windows**. PyInstaller does not cross-compile a genuine Windows executable from Linux/macOS.

Double-click:

```text
build_windows_exe.bat
```

Or run manually:

```bat
python -m venv .venv-build
.venv-build\Scripts\python.exe -m pip install -r requirements-build.txt
.venv-build\Scripts\python.exe -m unittest discover -s tests -v
.venv-build\Scripts\python.exe -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name FROG ^
  --icon assets\frog_icon.ico ^
  --add-data "assets;assets" ^
  --collect-all faker ^
  --collect-all phonenumbers ^
  --collect-all pycountry ^
  main.py
```

Output: `dist\FROG.exe`.

No administrator rights are normally required when Python and the project are in user-writable locations. Corporate endpoint security may still require the unsigned executable to be scanned, signed or allow-listed.

## Offline dependencies

- `Faker`: local synthetic names and country-specific address providers
- `phonenumbers`: offline calling-code parsing, region inference and example-number metadata
- `pycountry`: offline ISO country-name/code lookup
- `tkinter`: Python standard-library GUI

None of these libraries makes network calls during FROG operation.

## Add organisation-specific patterns

Copy `custom_rules.json.example` to `custom_rules.json` beside `FROG.exe` or `main.py`. Each regex must contain `(?P<value>...)`.

```json
[
  {
    "name": "internal_customer_id",
    "kind": "CUSTOMER_ID",
    "regex": "(?i)customerId\\s*[:=]\\s*(?P<value>CUS-[A-Z0-9]{10})",
    "generator": "mask",
    "priority": 78
  }
]
```

## Tests

```bat
python -m unittest discover -s tests -v
python main.py --smoke-test
```

The v1.4.0 suite contains 37 tests covering structured fields, DOB aliases, international IBANs and phones, independent address-country context, settings persistence, pretty-printing, gender-aware name consistency and previous regressions.

## Limitations

- No regex/rule system can literally be universal. FROG now handles literal, escaped, double-escaped and lightly line-wrapped structured fields, but unknown organisation-specific labels and genuinely corrupted payloads may still require custom rules or manual review.
- Free-form addresses with no label are not aggressively detected because doing so would create high false-positive rates.
- Country-aware address components are generated from the right national locale, but separately generated street/city/postcode components are not guaranteed to correspond to one real geographic location.
- There is no globally reserved fictional telephone range. International synthetic telephone values preserve format/country and use offline example-number metadata, but should not be dialled or treated as issued numbers.
- Postal-code syntax is not checked against live postal databases.
- Generated names may coincidentally match a real person; emails always use `example.com`.
- Synthetic mode is pseudonymisation, not irreversible anonymisation. The mapping permits re-identification and must remain local.
