# FROG — Field Redaction & Obfuscation Gadget

FROG is a small local/offline Windows utility for replacing likely PII in support logs before the log is pasted into an approved LLM chat tool. It preserves repeated-value relationships and creates a separate local-only fake → real mapping.

> **Important:** Pattern matching is a risk-reduction aid, not a formal DLP guarantee. Review the scrubbed output before sharing it and follow your employer's policies. FROG makes no network calls and does not auto-save logs or mappings.

## New in v1.1.0

- Switch between the deliberately chunky **Retro 90s** interface and a flatter **Modern sleek** interface.
- Both interface styles support **Light** and **Dark** appearance modes, giving four visual combinations.
- Optional **Auto-scrub after paste/edit** mode. FROG waits briefly for the paste/edit to finish, scrubs on a background thread, and refreshes the output without requiring the Scrub button.
- The supplied FROG mascot artwork is now used for the Windows icon, title/header branding, and About window.
- Background-thread results now return through a main-thread queue, avoiding tkinter thread calls and keeping long-log scrubbing responsive.

The interface and appearance controls are available both in **Scrub settings** and under the **View** menu.

## What it detects

- Email addresses
- IBAN candidates. Labelled IBAN fields are scrubbed even if the source checksum is malformed; unlabelled candidates require a valid MOD-97 checksum.
- UK National Insurance numbers
- UK postcodes
- UK sort codes in `12-34-56` form
- UK phone numbers, including `+44`
- Label-anchored account numbers
- Card-number candidates that pass Luhn
- Label-anchored dates of birth
- Labelled/titled names, plus an optional one-name-per-line known-names file

Name handling is deliberately two-pass: FROG first finds every occurrence of each discovered name and scans all those lines for titles, pronouns, or explicit gender fields. It generates the pseudonym only after that pass.

## Auto-scrub behaviour

When **Auto-scrub after paste/edit** is enabled:

1. Paste, type, or load a log into the input panel.
2. FROG waits about half a second so a large paste can complete.
3. The same local scrub engine runs on a worker thread.
4. The output and local-only mapping update automatically.

If the input changes while a scrub is already running, FROG discards the outdated result and queues one fresh pass. No network request is made, and nothing is automatically written to disk.

The normal **Scrub** button remains available when auto-scrub is off.

## No-admin source setup on Windows

These steps do **not** need administrator rights, assuming Python is already available to your user account:

1. Extract the FROG folder somewhere writable, such as your user profile.
2. Double-click `setup_no_admin.bat`.
3. Double-click `run_frog.bat`.

Manual equivalent:

```bat
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python main.py
```

If Python is not installed and company policy prevents a per-user Python install, use a pre-built `FROG.exe`. Running the finished one-file executable does not require admin rights.

## Build the standalone Windows executable

Build on **Windows**. PyInstaller does not cross-compile a Windows `.exe` from Linux/macOS.

```bat
py -m venv .venv-build
.venv-build\Scripts\activate
python -m pip install -r requirements-build.txt
python -m unittest discover -s tests -v
pyinstaller --noconfirm --clean --onefile --windowed --name FROG --icon assets\frog_icon.ico --add-data "assets;assets" --collect-all faker main.py
```

Or double-click `build_windows_exe.bat`. Output: `dist\FROG.exe`.

No administrator rights are normally required to build or run it when Python and the project live in user-writable folders. Endpoint security may still quarantine unsigned executables; the no-admin alternative is running the source from a virtual environment, or having your organisation sign/allow-list the executable.

## Branding assets

The supplied artwork is included in several pre-sized forms so Pillow is not needed at runtime:

- `assets/frog_icon.ico` — multi-resolution Windows executable/window icon
- `assets/frog_icon.png` — cross-platform window icon
- `assets/frog_header.png` — compact in-app header artwork
- `assets/frog_about.png` — About-window artwork
- `assets/frog_brand.png` — 512 px general-purpose copy
- `assets/frog_brand_original.png` — preserved full-resolution supplied image

## Add organisation-specific patterns without changing core code

Copy `custom_rules.json.example` to `custom_rules.json` beside `FROG.exe` (or beside `main.py` when running from source). FROG loads it at startup.

Each rule must contain a named `(?P<value>...)` capture group:

```json
[
  {
    "name": "internal_customer_id",
    "kind": "CUSTOMER_ID",
    "regex": "(?i)customerId\\s*[:=]\\s*(?P<value>CUS-[A-Z0-9]{10})",
    "generator": "mask",
    "priority": 78
  }
]
```

Supported custom generators:

- `mask`: replaces letters/digits while retaining punctuation
- `digits`: replaces digits while retaining separators

The built-in registry is in `frog/rules.py`; each rule is a `PatternRule(kind, regex, replacement_fn, renderer, canonicalizer, ...)`.

## Tests and demo

```bat
python -m unittest discover -s tests -v
python demo.py
python main.py --smoke-test
```

The GUI smoke test now exercises all four visual profiles and performs an actual clipboard-paste auto-scrub. The engine demo includes a name whose female pronoun cue appears only on a later line.

## Assumptions and limitations

- UK postcode syntax is checked, but FROG does not query the live Royal Mail address database.
- Phone matching is intentionally broad enough for common UK support-log formats and may need organisation-specific tuning.
- Account numbers and dates of birth are label-anchored to reduce false positives.
- Names are inherently difficult to detect reliably with regex alone. The known-names file is strongly recommended for incident-specific names missed by the generic patterns.
- Synthetic card values are Luhn-valid and shape-preserving, but use a conspicuously synthetic prefix; they are not intended for payment testing.
- IBAN replacements preserve country code, length, separator shape, and MOD-97 validity, but do not claim to be issued bank accounts.
- Seeded output is deterministic for the same FROG version, input value, kind, and seed. A blank seed intentionally creates a fresh random mapping; the effective seed is shown in the status bar and local mapping.
- Exact fonts and native widget details vary slightly between Windows releases. FROG uses only tkinter/ttk at runtime, so the modern mode remains lightweight rather than pulling in a browser or Electron runtime.
