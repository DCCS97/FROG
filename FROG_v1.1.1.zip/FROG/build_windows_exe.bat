@echo off
setlocal
cd /d "%~dp0"

echo FROG Windows EXE builder
echo ========================
echo.

rem Find an available Python command. Microsoft Store installs often provide
rem "python" but not the older "py" launcher.
where py >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_CMD=py"
) else (
    where python >nul 2>&1
    if not errorlevel 1 (
        set "PYTHON_CMD=python"
    ) else (
        where python3 >nul 2>&1
        if not errorlevel 1 (
            set "PYTHON_CMD=python3"
        ) else (
            echo ERROR: Python could not be found.
            echo Install Python for your user account, then run this file again.
            goto :error
        )
    )
)

echo Using Python command: %PYTHON_CMD%
%PYTHON_CMD% --version
if errorlevel 1 goto :error

if not exist ".venv-build\Scripts\python.exe" (
    echo.
    echo Creating isolated build environment...
    %PYTHON_CMD% -m venv .venv-build
    if errorlevel 1 goto :error
)

set "VENV_PYTHON=%CD%\.venv-build\Scripts\python.exe"
if not exist "%VENV_PYTHON%" (
    echo ERROR: The build environment was not created correctly.
    goto :error
)

echo.
echo Installing build dependencies...
"%VENV_PYTHON%" -m pip install --upgrade pip
if errorlevel 1 goto :error
"%VENV_PYTHON%" -m pip install -r requirements-build.txt
if errorlevel 1 goto :error

echo.
echo Running automated tests...
"%VENV_PYTHON%" -m unittest discover -s tests -v
if errorlevel 1 goto :error

echo.
echo Building standalone FROG.exe...
"%VENV_PYTHON%" -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name FROG ^
  --icon assets\frog_icon.ico ^
  --add-data "assets;assets" ^
  --collect-all faker ^
  main.py
if errorlevel 1 goto :error

echo.
echo Build complete:
echo %CD%\dist\FROG.exe
echo.
pause
exit /b 0

:error
echo.
echo Build failed.
pause
exit /b 1
