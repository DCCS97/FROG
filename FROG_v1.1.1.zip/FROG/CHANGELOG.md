# Changelog

## 1.1.0 — 2026-07-13

- Added Retro 90s / Modern sleek interface switching.
- Added Light / Dark appearance switching for both interfaces.
- Added optional debounced auto-scrub after paste, edit, or file load.
- Added stale-result protection when input changes during a background scrub.
- Replaced worker-thread tkinter callbacks with a main-thread result queue.
- Integrated the supplied FROG artwork into ICO, PNG, header, and About assets.
- Expanded the GUI smoke test to exercise all themes and clipboard-paste auto-scrubbing.

## 1.0.1 — 2026-07-13

- Scrub labelled IBAN fields even when the source checksum is invalid.
- Keep unlabelled invalid IBAN-shaped strings untouched to limit false positives.
- Preserve the relationship between UK IBANs and separately detected sort-code/account-number values.

## 1.0.0 — 2026-07-13

- Initial local PII scrubber, mapping window, seeded pseudonymisation, redaction mode, custom rules, and retro interface.
