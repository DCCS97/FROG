from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from .generators import (
    canonical_alnum,
    canonical_digits,
    canonical_dob,
    canonical_email,
    canonical_exact,
    canonical_name,
    canonical_phone,
    dob_is_valid,
    generate_card,
    generate_digits,
    generate_dob,
    generate_email,
    generate_iban,
    generate_mask,
    generate_name,
    generate_nino,
    generate_phone,
    generate_postcode,
    generate_sort_code,
    iban_is_valid,
    luhn_is_valid,
    nino_is_valid,
    phone_is_valid,
    postcode_is_valid,
    render_alnum,
    render_digits,
    render_dob,
    render_phone,
    render_plain,
)
from .models import PatternRule


NAME_TOKEN = r"[A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ'’\-]+"
FULL_NAME = rf"{NAME_TOKEN}(?:[ \t]+{NAME_TOKEN}){{1,3}}"


# This is the main extension point. Add another PatternRule here for a new
# organisation-specific format, or use custom_rules.json without changing code.
RULE_REGISTRY: list[PatternRule] = [
    PatternRule(
        name="email",
        kind="EMAIL",
        regex=re.compile(r"(?<![\w.+-])(?P<value>[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,63})(?![\w.-])", re.I),
        replacement_fn=generate_email,
        renderer=render_plain,
        canonicalizer=canonical_email,
        priority=90,
    ),
    # Label-anchored IBANs are scrubbed even when their MOD-97 checksum is invalid.
    # Logs commonly contain test data, truncated values, or the malformed identifier that
    # caused the incident; it is still sensitive and must not be allowed through.
    PatternRule(
        name="iban_labelled",
        kind="IBAN",
        regex=re.compile(
            r"(?i:(?:[\"']?(?:iban|international[ _-]*bank[ _-]*account[ _-]*(?:number|no\.?))[\"']?))"
            r"\s*(?:[:=]|\s+-\s+)\s*[\"']?"
            r"(?P<value>[A-Z]{2}\d{2}(?:[ -]?[A-Z0-9]){11,30})"
            r"(?=[\"']?(?:\s|[,.);:|}\]]|$))",
            re.I,
        ),
        replacement_fn=generate_iban,
        renderer=render_alnum,
        canonicalizer=canonical_alnum,
        priority=120,
    ),
    # Unlabelled IBAN-shaped strings retain checksum validation to avoid turning arbitrary
    # long alphanumeric tokens into PII detections.
    PatternRule(
        name="iban",
        kind="IBAN",
        regex=re.compile(r"(?<![A-Z0-9])(?P<value>[A-Z]{2}\d{2}(?:[ -]?[A-Z0-9]){11,30})(?![A-Z0-9])", re.I),
        replacement_fn=generate_iban,
        renderer=render_alnum,
        canonicalizer=canonical_alnum,
        validator=iban_is_valid,
        priority=110,
    ),
    PatternRule(
        name="uk_nino",
        kind="NINO",
        regex=re.compile(
            r"(?<![A-Z0-9])(?P<value>(?!BG|GB|KN|NK|NT|TN|ZZ)(?![DFIQUV])[A-CEGHJ-PR-TW-Z]{2}[ -]?\d{2}[ -]?\d{2}[ -]?\d{2}[ -]?[A-D])(?![A-Z0-9])",
            re.I,
        ),
        replacement_fn=generate_nino,
        renderer=render_alnum,
        canonicalizer=canonical_alnum,
        validator=nino_is_valid,
        priority=85,
    ),
    PatternRule(
        name="uk_postcode",
        kind="POSTCODE",
        regex=re.compile(
            r"(?<![A-Z0-9])(?P<value>GIR\s?0AA|(?:[A-PR-UWYZ][0-9][0-9A-HJKPSTUW]?|[A-PR-UWYZ][A-HK-Y][0-9][0-9ABEHMNPRV-Y]?)\s?[0-9][ABD-HJLNP-UW-Z]{2})(?![A-Z0-9])",
            re.I,
        ),
        replacement_fn=generate_postcode,
        renderer=render_alnum,
        canonicalizer=canonical_alnum,
        validator=postcode_is_valid,
        priority=60,
    ),
    PatternRule(
        name="uk_sort_code",
        kind="SORT_CODE",
        regex=re.compile(r"(?<!\d)(?P<value>\d{2}-\d{2}-\d{2})(?!\d)"),
        replacement_fn=generate_sort_code,
        renderer=render_digits,
        canonicalizer=canonical_digits,
        priority=65,
    ),
    PatternRule(
        name="uk_phone",
        kind="PHONE",
        regex=re.compile(r"(?<!\d)(?P<value>(?:\+44\s?(?:\(0\)\s?)?|0)(?:[\s().-]*\d){9,11})(?!\d)"),
        replacement_fn=generate_phone,
        renderer=render_phone,
        canonicalizer=canonical_phone,
        validator=phone_is_valid,
        priority=70,
    ),
    PatternRule(
        name="account_number_labelled",
        kind="ACCOUNT_NUMBER",
        regex=re.compile(
            r"(?i:(?:[\"']?(?:account[ _-]*(?:number|no\.?|#)|acct[ _-]*(?:number|no\.?))[\"']?))\s*(?:[:=]|\s+-\s+)\s*[\"']?(?P<value>\d{6,12})(?=[\"']?(?:\s|[,.);:|}\]]|$))"
        ),
        replacement_fn=generate_digits,
        renderer=render_digits,
        canonicalizer=canonical_digits,
        priority=75,
    ),
    PatternRule(
        name="card_number_luhn",
        kind="CARD_NUMBER",
        regex=re.compile(r"(?<!\d)(?P<value>(?:\d[ -]?){12,18}\d)(?!\d)"),
        replacement_fn=generate_card,
        renderer=render_digits,
        canonicalizer=canonical_digits,
        validator=luhn_is_valid,
        priority=100,
    ),
    PatternRule(
        name="date_of_birth_labelled",
        kind="DATE_OF_BIRTH",
        regex=re.compile(
            r"(?i:(?:[\"']?(?:dob|date[ _-]*of[ _-]*birth|birth[ _-]*date)[\"']?))\s*(?:[:=]|\s+-\s+)\s*[\"']?(?P<value>(?:\d{1,2}[/.\-]\d{1,2}[/.\-]\d{2,4}|\d{4}[/-]\d{2}[/-]\d{2}|\d{1,2}\s+(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{4}))",
            re.I,
        ),
        replacement_fn=generate_dob,
        renderer=render_dob,
        canonicalizer=canonical_dob,
        validator=dob_is_valid,
        priority=80,
    ),
    PatternRule(
        name="name_labelled",
        kind="NAME",
        regex=re.compile(
            rf"(?i:(?:[\"']?(?:customer[ _-]*name|client[ _-]*name|full[ _-]*name|account[ _-]*holder(?:[ _-]*name)?|cardholder(?:[ _-]*name)?|applicant[ _-]*name|beneficiary[ _-]*name|contact[ _-]*name)[\"']?))\s*(?:[:=]|\s+-\s+)\s*[\"']?(?:(?:Mr|Mrs|Ms|Miss|Dr)\.?\s+)?(?P<value>{FULL_NAME})",
        ),
        replacement_fn=generate_name,
        renderer=render_plain,
        canonicalizer=canonical_name,
        priority=55,
        is_name_rule=True,
    ),
    PatternRule(
        name="name_line_labelled",
        kind="NAME",
        regex=re.compile(
            rf"(?m)^[ \t]*(?i:Name)\s*(?:[:=]|\s+-\s+)\s*[\"']?(?:(?:Mr|Mrs|Ms|Miss|Dr)\.?\s+)?(?P<value>{FULL_NAME})"
        ),
        replacement_fn=generate_name,
        renderer=render_plain,
        canonicalizer=canonical_name,
        priority=54,
        is_name_rule=True,
    ),
    PatternRule(
        name="name_titled",
        kind="NAME",
        regex=re.compile(rf"\b(?:(?:Mr|Mrs|Ms|Miss|Dr)\.?\s+)(?P<value>{FULL_NAME})\b"),
        replacement_fn=generate_name,
        renderer=render_plain,
        canonicalizer=canonical_name,
        priority=56,
        is_name_rule=True,
    ),
]


_CUSTOM_GENERATORS: dict[str, tuple[Any, Any, Any]] = {
    "mask": (generate_mask, render_alnum, canonical_exact),
    "digits": (generate_digits, render_digits, canonical_digits),
}


def load_custom_rules(path: Path | None) -> list[PatternRule]:
    """Load optional local rules from JSON. Invalid files fail loudly and safely."""

    if path is None or not path.exists():
        return []
    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise ValueError("custom_rules.json must contain a JSON array")
    rules: list[PatternRule] = []
    for index, item in enumerate(raw, start=1):
        if not isinstance(item, dict):
            raise ValueError(f"Custom rule {index} must be an object")
        kind = str(item["kind"]).strip().upper()
        regex_text = str(item["regex"])
        generator_name = str(item.get("generator", "mask")).strip().lower()
        if generator_name not in _CUSTOM_GENERATORS:
            raise ValueError(f"Custom rule {index}: unsupported generator {generator_name!r}")
        replacement_fn, renderer, canonicalizer = _CUSTOM_GENERATORS[generator_name]
        flags = re.MULTILINE
        if item.get("ignore_case", True):
            flags |= re.IGNORECASE
        compiled = re.compile(regex_text, flags)
        if "value" not in compiled.groupindex:
            raise ValueError(f"Custom rule {index} must include a named capture group (?P<value>...)")
        rules.append(
            PatternRule(
                name=str(item.get("name", f"custom_{index}")),
                kind=kind,
                regex=compiled,
                replacement_fn=replacement_fn,
                renderer=renderer,
                canonicalizer=canonicalizer,
                priority=int(item.get("priority", 72)),
            )
        )
    return rules
