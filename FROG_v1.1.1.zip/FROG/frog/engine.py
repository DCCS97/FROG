from __future__ import annotations

import hashlib
import re
import secrets
from collections import defaultdict
from pathlib import Path
from random import Random
from typing import Iterable

from faker import Faker

from .generators import alnum_only, canonical_name, generate_name, rebuild_uk_iban, render_plain
from .models import Detection, MappingEntry, PatternRule, ScrubResult, SyntheticValue
from .rules import RULE_REGISTRY, load_custom_rules


SYNTHETIC_PREAMBLE = (
    "All personally identifiable information in this log has been replaced with consistent "
    "synthetic placeholder values for data-protection reasons. The same real value always maps "
    "to the same fake value throughout, so relationships between entries are preserved. Please "
    "do not treat these values as malformed or as the cause of any issue — focus on the actual "
    "technical behaviour (error codes, timestamps, sequence of events, etc.)."
)

REDACT_PREAMBLE = (
    "All personally identifiable information in this log has been replaced with consistent "
    "redaction placeholders for data-protection reasons. The same real value always maps to the "
    "same placeholder throughout, so relationships between entries are preserved. Please focus "
    "on the actual technical behaviour (error codes, timestamps, sequence of events, etc.)."
)

_NAME_STOPWORDS = {
    "error",
    "exception",
    "payment gateway",
    "request failed",
    "service account",
    "unknown user",
    "null value",
    "not found",
}


class Scrubber:
    def __init__(self, custom_rules_path: Path | None = None) -> None:
        self.rules = [*RULE_REGISTRY, *load_custom_rules(custom_rules_path)]
        self._name_rule = PatternRule(
            name="expanded_name",
            kind="NAME",
            regex=re.compile(r"$^"),
            replacement_fn=generate_name,
            renderer=render_plain,
            canonicalizer=canonical_name,
            priority=57,
            is_name_rule=True,
        )

    @staticmethod
    def _stable_seed(seed: str, kind: str, canonical: str, attempt: int) -> int:
        payload = f"FROG\0{seed}\0{kind}\0{canonical}\0{attempt}".encode("utf-8")
        return int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")

    @staticmethod
    def _read_known_names(path: Path | None) -> list[str]:
        if path is None:
            return []
        lines = path.read_text(encoding="utf-8-sig").splitlines()
        seen: set[str] = set()
        names: list[str] = []
        for line in lines:
            name = " ".join(line.strip().split())
            if not name or name.startswith("#"):
                continue
            canonical = canonical_name(name)
            if canonical not in seen:
                names.append(name)
                seen.add(canonical)
        return names

    @staticmethod
    def _looks_like_name(value: str) -> bool:
        canonical = canonical_name(value)
        if canonical in _NAME_STOPWORDS:
            return False
        tokens = canonical.split()
        return 1 <= len(tokens) <= 4 and all(any(ch.isalpha() for ch in token) for token in tokens)

    def _initial_detections(self, text: str, known_names: Iterable[str]) -> list[Detection]:
        detections: list[Detection] = []
        for rule in self.rules:
            for match in rule.regex.finditer(text):
                try:
                    value = match.group(rule.value_group)
                    start, end = match.span(rule.value_group)
                except (IndexError, KeyError):
                    continue
                value = value.strip()
                if not value or not rule.validator(value):
                    continue
                if rule.is_name_rule and not self._looks_like_name(value):
                    continue
                detections.append(
                    Detection(
                        kind=rule.kind,
                        real=value,
                        canonical=rule.canonicalizer(value),
                        start=start,
                        end=end,
                        rule=rule,
                    )
                )

        for name in known_names:
            if not self._looks_like_name(name):
                continue
            expression = self._name_expression(name)
            for match in expression.finditer(text):
                value = match.group(0)
                detections.append(
                    Detection(
                        kind="NAME",
                        real=value,
                        canonical=canonical_name(value),
                        start=match.start(),
                        end=match.end(),
                        rule=self._name_rule,
                    )
                )
        return detections

    @staticmethod
    def _name_expression(name: str) -> re.Pattern[str]:
        tokens = [re.escape(token) for token in name.split()]
        body = r"\s+".join(tokens)
        return re.compile(rf"(?<![\w'’\-]){body}(?![\w'’\-])", re.I)

    def _expand_names_and_infer_gender(
        self, text: str, detections: list[Detection]
    ) -> tuple[list[Detection], dict[str, str | None]]:
        variants: dict[str, set[str]] = defaultdict(set)
        for detection in detections:
            if detection.kind == "NAME":
                variants[detection.canonical].add(detection.real)

        expanded: list[Detection] = [d for d in detections if d.kind != "NAME"]
        name_occurrences: dict[str, list[Detection]] = defaultdict(list)
        for canonical, raw_variants in variants.items():
            # Include a normalized spacing variant so "Jane  Doe" and "Jane Doe" remain linked.
            representative = min(raw_variants, key=lambda value: (len(value), value.casefold()))
            expression = self._name_expression(" ".join(representative.split()))
            for match in expression.finditer(text):
                occurrence = Detection(
                    kind="NAME",
                    real=match.group(0),
                    canonical=canonical,
                    start=match.start(),
                    end=match.end(),
                    rule=self._name_rule,
                )
                name_occurrences[canonical].append(occurrence)
                expanded.append(occurrence)

        gender_map: dict[str, str | None] = {}
        for canonical, occurrences in name_occurrences.items():
            male_score = 0
            female_score = 0
            for occurrence in occurrences:
                line_start = text.rfind("\n", 0, occurrence.start) + 1
                line_end = text.find("\n", occurrence.end)
                if line_end == -1:
                    line_end = len(text)
                line = text[line_start:line_end]
                relative_start = occurrence.start - line_start
                prefix = line[max(0, relative_start - 20) : relative_start]
                title_match = re.search(r"\b(Mr|Mrs|Ms|Miss|Dr)\.?\s*$", prefix, re.I)
                if title_match:
                    title = title_match.group(1).casefold()
                    if title == "mr":
                        male_score += 5
                    elif title in {"mrs", "ms", "miss"}:
                        female_score += 5

                lowered = line.casefold()
                male_score += len(re.findall(r"\b(?:he|him|his|himself)\b", lowered))
                female_score += len(re.findall(r"\b(?:she|her|hers|herself)\b", lowered))
                if re.search(r"\b(?:gender|sex)\s*[:=]\s*(?:male|m)\b", lowered):
                    male_score += 3
                if re.search(r"\b(?:gender|sex)\s*[:=]\s*(?:female|f)\b", lowered):
                    female_score += 3

            if male_score > female_score:
                gender_map[canonical] = "male"
            elif female_score > male_score:
                gender_map[canonical] = "female"
            else:
                gender_map[canonical] = None
        return expanded, gender_map

    @staticmethod
    def _deduplicate_and_resolve_overlaps(detections: list[Detection]) -> list[Detection]:
        unique: dict[tuple[int, int, str, str], Detection] = {}
        for detection in detections:
            key = (detection.start, detection.end, detection.kind, detection.canonical)
            existing = unique.get(key)
            if existing is None or detection.rule.priority > existing.rule.priority:
                unique[key] = detection

        # Split the interval set into small connected overlap clusters. This avoids
        # comparing every detection with every other detection on large logs.
        by_position = sorted(unique.values(), key=lambda d: (d.start, d.end))
        clusters: list[list[Detection]] = []
        current: list[Detection] = []
        current_end = -1
        for detection in by_position:
            if current and detection.start >= current_end:
                clusters.append(current)
                current = []
                current_end = -1
            current.append(detection)
            current_end = max(current_end, detection.end)
        if current:
            clusters.append(current)

        selected: list[Detection] = []
        for cluster in clusters:
            if len(cluster) == 1:
                selected.append(cluster[0])
                continue
            winners: list[Detection] = []
            for candidate in sorted(
                cluster,
                key=lambda d: (-d.rule.priority, -(d.end - d.start), d.start, d.end),
            ):
                if any(candidate.start < other.end and other.start < candidate.end for other in winners):
                    continue
                winners.append(candidate)
            selected.extend(winners)
        return sorted(selected, key=lambda d: (d.start, d.end))

    def scrub(
        self,
        text: str,
        *,
        mode: str = "synthetic",
        seed: str | None = None,
        include_preamble: bool = True,
        known_names_path: Path | None = None,
        known_names: Iterable[str] | None = None,
    ) -> ScrubResult:
        if mode not in {"synthetic", "redact"}:
            raise ValueError("mode must be 'synthetic' or 'redact'")
        effective_seed = seed.strip() if seed and seed.strip() else secrets.token_hex(8)
        combined_names = [*(known_names or []), *self._read_known_names(known_names_path)]

        detections = self._initial_detections(text, combined_names)
        detections, gender_map = self._expand_names_and_infer_gender(text, detections)
        detections = self._deduplicate_and_resolve_overlaps(detections)

        grouped: dict[tuple[str, str], list[Detection]] = defaultdict(list)
        first_position: dict[tuple[str, str], int] = {}
        for detection in detections:
            key = (detection.kind, detection.canonical)
            grouped[key].append(detection)
            first_position.setdefault(key, detection.start)

        replacements: dict[tuple[str, str], SyntheticValue | str] = {}
        metadata_by_key: dict[tuple[str, str], dict[str, str]] = {}
        used_generated: dict[str, set[str]] = defaultdict(set)

        keys_by_generation = sorted(grouped)
        placeholder_order = sorted(grouped, key=lambda key: first_position[key])
        placeholder_number = {key: index for index, key in enumerate(placeholder_order, start=1)}

        for key in keys_by_generation:
            kind, canonical = key
            representative = grouped[key][0]
            metadata: dict[str, str] = {}
            if kind == "NAME" and gender_map.get(canonical):
                metadata["gender"] = str(gender_map[canonical])
            metadata_by_key[key] = metadata

            if mode == "redact":
                replacements[key] = f"[{kind}_{placeholder_number[key]}]"
                continue

            for attempt in range(100):
                value_seed = self._stable_seed(effective_seed, kind, canonical, attempt)
                rng = Random(value_seed)
                faker = Faker("en_GB")
                faker.seed_instance(value_seed)
                generated = representative.rule.replacement_fn(representative.real, rng, faker, metadata)
                rendered_candidate = representative.rule.renderer(generated, representative.real)
                generated_key = representative.rule.canonicalizer(rendered_candidate)
                if generated_key == canonical:
                    continue
                if generated_key in used_generated[kind]:
                    continue
                replacements[key] = generated
                used_generated[kind].add(generated_key)
                break
            else:
                raise RuntimeError(f"Unable to generate a unique replacement for {kind}")

        # Preserve the direct-debit relationship in a UK IBAN when the same source
        # sort code and/or account number also appeared as separately detected fields.
        # Without this, an LLM could incorrectly report that the synthetic fields disagree.
        if mode == "synthetic":
            for key, occurrences in grouped.items():
                kind, _canonical = key
                if kind != "IBAN":
                    continue
                real_compact = alnum_only(occurrences[0].real).upper()
                if len(real_compact) != 22 or not real_compact.startswith("GB"):
                    continue

                source_sort = real_compact[8:14]
                source_account = real_compact[14:22]
                sort_replacement = replacements.get(("SORT_CODE", source_sort))
                account_replacement = replacements.get(("ACCOUNT_NUMBER", source_account))
                current = replacements.get(key)
                if not isinstance(current, SyntheticValue):
                    continue

                fake_sort = sort_replacement.base if isinstance(sort_replacement, SyntheticValue) else None
                fake_account = (
                    account_replacement.base if isinstance(account_replacement, SyntheticValue) else None
                )
                if fake_sort is None and fake_account is None:
                    continue
                replacements[key] = rebuild_uk_iban(
                    current,
                    sort_code=fake_sort,
                    account_number=fake_account,
                )
                metadata_by_key[key]["linked_uk_routing_fields"] = "yes"

        chunks: list[str] = []
        cursor = 0
        rendered_by_key: dict[tuple[str, str], list[str]] = defaultdict(list)
        for detection in detections:
            chunks.append(text[cursor : detection.start])
            key = (detection.kind, detection.canonical)
            replacement = replacements[key]
            if isinstance(replacement, str):
                rendered = replacement
            else:
                rendered = detection.rule.renderer(replacement, detection.real)
            chunks.append(rendered)
            if rendered not in rendered_by_key[key]:
                rendered_by_key[key].append(rendered)
            cursor = detection.end
        chunks.append(text[cursor:])
        scrubbed = "".join(chunks)

        if include_preamble:
            preamble = SYNTHETIC_PREAMBLE if mode == "synthetic" else REDACT_PREAMBLE
            scrubbed = preamble + "\n\n--- SCRUBBED LOG ---\n" + scrubbed

        mapping_entries: list[MappingEntry] = []
        for key in placeholder_order:
            kind, canonical = key
            occurrences = grouped[key]
            replacement = replacements[key]
            if isinstance(replacement, str):
                fake_display = replacement
            else:
                fake_display = occurrences[0].rule.renderer(replacement, occurrences[0].real)
            mapping_entries.append(
                MappingEntry(
                    kind=kind,
                    fake=fake_display,
                    real=occurrences[0].real,
                    canonical_real=canonical,
                    occurrences=len(occurrences),
                    rendered_fakes=rendered_by_key[key],
                    metadata=metadata_by_key[key],
                )
            )

        stats: dict[str, int] = defaultdict(int)
        for detection in detections:
            stats[detection.kind] += 1
        stats["TOTAL"] = len(detections)
        stats["UNIQUE"] = len(grouped)
        return ScrubResult(
            text=scrubbed,
            mapping=mapping_entries,
            effective_seed=effective_seed,
            stats=dict(stats),
        )
