from __future__ import annotations

import queue
import sys
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from .engine import Scrubber
from .models import ScrubResult


APP_NAME = "FROG — Field Redaction & Obfuscation Gadget"
APP_VERSION = "1.1.0"
AUTO_SCRUB_DELAY_MS = 550

STYLE_RETRO = "Retro 90s"
STYLE_MODERN = "Modern sleek"
APPEARANCE_LIGHT = "Light"
APPEARANCE_DARK = "Dark"


def app_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[1]


def asset_path(name: str) -> Path:
    if hasattr(sys, "_MEIPASS"):
        return Path(getattr(sys, "_MEIPASS")) / "assets" / name
    return app_base_dir() / "assets" / name


PALETTES: dict[tuple[str, str], dict[str, str]] = {
    (STYLE_RETRO, APPEARANCE_LIGHT): {
        "bg": "#c0c0c0",
        "surface": "#d4d0c8",
        "surface_alt": "#e7e4de",
        "text": "#000000",
        "muted": "#333333",
        "input_bg": "#ffffff",
        "input_fg": "#000000",
        "accent": "#008000",
        "accent_text": "#ffffff",
        "accent_hover": "#006b00",
        "border": "#808080",
        "border_light": "#ffffff",
        "selection": "#000080",
        "selection_text": "#ffffff",
        "warning": "#8b0000",
        "warning_bg": "#ffffcc",
        "status_bg": "#d4d0c8",
    },
    (STYLE_RETRO, APPEARANCE_DARK): {
        "bg": "#242424",
        "surface": "#353535",
        "surface_alt": "#444444",
        "text": "#f2f2f2",
        "muted": "#c7c7c7",
        "input_bg": "#151515",
        "input_fg": "#f2f2f2",
        "accent": "#65b741",
        "accent_text": "#081006",
        "accent_hover": "#86d761",
        "border": "#777777",
        "border_light": "#a9a9a9",
        "selection": "#1d4f91",
        "selection_text": "#ffffff",
        "warning": "#ffb4a8",
        "warning_bg": "#4c1f1f",
        "status_bg": "#303030",
    },
    (STYLE_MODERN, APPEARANCE_LIGHT): {
        "bg": "#f3f6f8",
        "surface": "#ffffff",
        "surface_alt": "#eef3f5",
        "text": "#18212b",
        "muted": "#65717d",
        "input_bg": "#ffffff",
        "input_fg": "#18212b",
        "accent": "#42a846",
        "accent_text": "#ffffff",
        "accent_hover": "#348b38",
        "border": "#d5dde3",
        "border_light": "#ffffff",
        "selection": "#bce8c0",
        "selection_text": "#102113",
        "warning": "#a62323",
        "warning_bg": "#fff1f0",
        "status_bg": "#ffffff",
    },
    (STYLE_MODERN, APPEARANCE_DARK): {
        "bg": "#10151c",
        "surface": "#19212b",
        "surface_alt": "#222d39",
        "text": "#f2f6f8",
        "muted": "#9eabb8",
        "input_bg": "#0c1117",
        "input_fg": "#edf3f6",
        "accent": "#75cf67",
        "accent_text": "#0c190d",
        "accent_hover": "#8ade7e",
        "border": "#33404d",
        "border_light": "#475767",
        "selection": "#245a35",
        "selection_text": "#ffffff",
        "warning": "#ffb2aa",
        "warning_bg": "#452222",
        "status_bg": "#19212b",
    },
}


class MappingWindow(tk.Toplevel):
    def __init__(self, parent: "FrogApp", result: ScrubResult) -> None:
        super().__init__(parent)
        self.parent_app = parent
        self.result = result
        self.title("FROG Mapping — LOCAL ONLY / NEVER SHARE")
        self.geometry("860x590")
        self.minsize(640, 420)
        self.transient(parent)

        warning = ttk.Label(
            self,
            text="⚠ LOCAL-ONLY REFERENCE — CONTAINS ORIGINAL PII — NEVER PASTE OR SHARE",
            style="Warning.TLabel",
            anchor="center",
        )
        warning.pack(fill="x", padx=12, pady=(12, 7), ipady=5)

        frame = ttk.Frame(self, padding=(12, 5, 12, 10))
        frame.pack(fill="both", expand=True)
        self.text = tk.Text(frame, wrap="none", undo=False, font=parent.code_font)
        yscroll = ttk.Scrollbar(frame, orient="vertical", command=self.text.yview)
        xscroll = ttk.Scrollbar(frame, orient="horizontal", command=self.text.xview)
        self.text.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.text.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.text.insert("1.0", result.mapping_text())
        self.text.configure(state="disabled")

        controls = ttk.Frame(self, padding=(12, 0, 12, 12))
        controls.pack(fill="x")
        ttk.Button(controls, text="Save Mapping Locally…", command=self.save_mapping).pack(side="left")
        ttk.Button(controls, text="Close", command=self.destroy).pack(side="right")

        self.apply_colours()

    def apply_colours(self) -> None:
        palette = self.parent_app.palette
        self.configure(bg=palette["bg"])
        self.text.configure(
            font=self.parent_app.code_font,
            background=palette["input_bg"],
            foreground=palette["input_fg"],
            insertbackground=palette["input_fg"],
            selectbackground=palette["selection"],
            selectforeground=palette["selection_text"],
            relief="sunken" if self.parent_app.interface_style.get() == STYLE_RETRO else "flat",
            borderwidth=2 if self.parent_app.interface_style.get() == STYLE_RETRO else 1,
            highlightthickness=1,
            highlightbackground=palette["border"],
            highlightcolor=palette["accent"],
        )

    def save_mapping(self) -> None:
        path = filedialog.asksaveasfilename(
            parent=self,
            title="Save LOCAL-ONLY mapping",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            initialfile="FROG_mapping_LOCAL_ONLY.txt",
        )
        if not path:
            return
        Path(path).write_text(self.result.mapping_text(), encoding="utf-8")
        messagebox.showinfo("FROG", "Local-only mapping saved. Keep it secure and do not share it.", parent=self)


class AboutWindow(tk.Toplevel):
    def __init__(self, parent: "FrogApp") -> None:
        super().__init__(parent)
        self.parent_app = parent
        self.title("About FROG")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        shell = ttk.Frame(self, padding=18, style="About.TFrame")
        shell.pack(fill="both", expand=True)

        image_path = asset_path("frog_about.png")
        if image_path.exists():
            try:
                self.logo = tk.PhotoImage(master=self, file=str(image_path))
                ttk.Label(shell, image=self.logo, style="About.TLabel").grid(
                    row=0, column=0, rowspan=4, sticky="n", padx=(0, 18)
                )
            except tk.TclError:
                self.logo = None
        else:
            self.logo = None

        ttk.Label(shell, text=f"FROG v{APP_VERSION}", style="AboutTitle.TLabel").grid(
            row=0, column=1, sticky="w"
        )
        ttk.Label(
            shell,
            text="Field Redaction & Obfuscation Gadget",
            style="AboutSubtitle.TLabel",
        ).grid(row=1, column=1, sticky="w", pady=(2, 12))
        ttk.Label(
            shell,
            text=(
                "Now leaping PII out of your logs since 2026.\n\n"
                "A proudly over-acronymed, locally operated utility in the finest tradition "
                "of chunky Windows shareware — now also available in suspiciously tasteful "
                "modern clothing. No modem noises, no cloud, no nonsense.\n\n"
                "Scrubbed output may be shared only under your organisation's policies. "
                "The mapping is local-only and must never be pasted into an LLM."
            ),
            style="AboutBody.TLabel",
            wraplength=430,
            justify="left",
        ).grid(row=2, column=1, sticky="nw")
        ttk.Button(shell, text="Excellent. Carry on.", command=self.destroy).grid(
            row=3, column=1, sticky="e", pady=(18, 0)
        )

        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self.update_idletasks()
        x = parent.winfo_rootx() + max(0, (parent.winfo_width() - self.winfo_width()) // 2)
        y = parent.winfo_rooty() + max(0, (parent.winfo_height() - self.winfo_height()) // 2)
        self.geometry(f"+{x}+{y}")


class FrogApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1240x800")
        self.minsize(920, 620)

        self.result: ScrubResult | None = None
        self.known_names_path = tk.StringVar()
        self.mode = tk.StringVar(value="synthetic")
        self.seed = tk.StringVar()
        self.include_preamble = tk.BooleanVar(value=True)
        self.auto_scrub = tk.BooleanVar(value=False)
        self.interface_style = tk.StringVar(value=STYLE_RETRO)
        self.appearance = tk.StringVar(value=APPEARANCE_LIGHT)
        self.status = tk.StringVar(value="Ready. No data leaves this computer.")

        self._style = ttk.Style(self)
        self._text_widgets: list[tk.Text] = []
        self._menus: list[tk.Menu] = []
        self._mapping_windows: list[MappingWindow] = []
        self._auto_scrub_job: str | None = None
        self._poll_job: str | None = None
        self._scrub_in_progress = False
        self._pending_auto_scrub = False
        self._revision = 0
        self._suppress_input_modified = False
        self._brand_header_image: tk.PhotoImage | None = None
        self._worker_results: queue.Queue[tuple[str, object, int]] = queue.Queue()

        self._set_icon()
        self._configure_style()
        self._build_menu()
        self._build_ui()
        self._bind_events()
        self.scrubber = self._create_scrubber()
        self._apply_theme()
        self._poll_job = self.after(40, self._poll_worker_results)

    @property
    def palette(self) -> dict[str, str]:
        return PALETTES[(self.interface_style.get(), self.appearance.get())]

    @property
    def code_font(self) -> tuple[str, int]:
        if self.interface_style.get() == STYLE_RETRO:
            return ("Courier New", 9)
        return ("Cascadia Mono", 10)

    @property
    def ui_font(self) -> tuple[str, int]:
        if self.interface_style.get() == STYLE_RETRO:
            return ("MS Sans Serif", 9)
        return ("Segoe UI", 10)

    def _create_scrubber(self) -> Scrubber:
        custom_path = app_base_dir() / "custom_rules.json"
        try:
            scrubber = Scrubber(custom_path if custom_path.exists() else None)
            if custom_path.exists():
                self.status.set(f"Ready. Loaded custom rules from {custom_path.name}.")
            return scrubber
        except Exception as exc:
            messagebox.showerror("FROG custom rules error", str(exc), parent=self)
            self.status.set("Custom rules failed to load; using built-in rules only.")
            return Scrubber()

    def _configure_style(self) -> None:
        if "clam" in self._style.theme_names():
            self._style.theme_use("clam")

    def _set_icon(self) -> None:
        try:
            ico = asset_path("frog_icon.ico")
            if sys.platform.startswith("win") and ico.exists():
                self.iconbitmap(default=str(ico))
            png = asset_path("frog_icon.png")
            if png.exists():
                self._icon_image = tk.PhotoImage(file=str(png))
                self.iconphoto(True, self._icon_image)
        except tk.TclError:
            pass

    def _build_menu(self) -> None:
        menu = tk.Menu(self)
        self._menus.append(menu)

        file_menu = tk.Menu(menu, tearoff=False)
        self._menus.append(file_menu)
        file_menu.add_command(label="Load Log…", command=self.load_log)
        file_menu.add_command(label="Save Scrubbed Output…", command=self.save_output)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.destroy)
        menu.add_cascade(label="File", menu=file_menu)

        view_menu = tk.Menu(menu, tearoff=False)
        self._menus.append(view_menu)
        view_menu.add_radiobutton(
            label="Retro 90s interface",
            variable=self.interface_style,
            value=STYLE_RETRO,
            command=self._apply_theme,
        )
        view_menu.add_radiobutton(
            label="Modern sleek interface",
            variable=self.interface_style,
            value=STYLE_MODERN,
            command=self._apply_theme,
        )
        view_menu.add_separator()
        view_menu.add_radiobutton(
            label="Light mode",
            variable=self.appearance,
            value=APPEARANCE_LIGHT,
            command=self._apply_theme,
        )
        view_menu.add_radiobutton(
            label="Dark mode",
            variable=self.appearance,
            value=APPEARANCE_DARK,
            command=self._apply_theme,
        )
        view_menu.add_separator()
        view_menu.add_checkbutton(
            label="Auto-scrub after paste/edit",
            variable=self.auto_scrub,
            command=self._on_auto_scrub_toggled,
        )
        menu.add_cascade(label="View", menu=view_menu)

        help_menu = tk.Menu(menu, tearoff=False)
        self._menus.append(help_menu)
        help_menu.add_command(label="About FROG", command=self.show_about)
        menu.add_cascade(label="Help", menu=help_menu)
        self.configure(menu=menu)

    def _build_ui(self) -> None:
        self.header = ttk.Frame(self, padding=(14, 11, 14, 7), style="Header.TFrame")
        self.header.pack(fill="x")

        header_logo_path = asset_path("frog_header.png")
        if header_logo_path.exists():
            try:
                self._brand_header_image = tk.PhotoImage(file=str(header_logo_path))
                ttk.Label(self.header, image=self._brand_header_image, style="HeaderLogo.TLabel").pack(
                    side="left", padx=(0, 10)
                )
            except tk.TclError:
                self._brand_header_image = None

        title_block = ttk.Frame(self.header, style="Header.TFrame")
        title_block.pack(side="left", fill="y")
        ttk.Label(title_block, text="FROG", style="Header.TLabel").pack(anchor="w")
        ttk.Label(
            title_block,
            text="Field Redaction & Obfuscation Gadget — local/offline log scrubbing",
            style="Subheader.TLabel",
        ).pack(anchor="w")

        self.profile_badge = ttk.Label(self.header, style="Profile.TLabel", anchor="center")
        self.profile_badge.pack(side="right", padx=(12, 0), pady=8)

        controls = ttk.LabelFrame(self, text="Scrub settings", padding=11, style="Panel.TLabelframe")
        controls.pack(fill="x", padx=14, pady=(4, 7))
        self.controls_frame = controls

        ttk.Label(controls, text="Mode:").grid(row=0, column=0, sticky="w")
        ttk.Radiobutton(controls, text="Synthetic", variable=self.mode, value="synthetic").grid(
            row=0, column=1, sticky="w", padx=(7, 10)
        )
        ttk.Radiobutton(controls, text="Redact", variable=self.mode, value="redact").grid(
            row=0, column=2, sticky="w"
        )
        ttk.Label(controls, text="Seed (optional):").grid(row=0, column=3, sticky="e", padx=(20, 5))
        ttk.Entry(controls, textvariable=self.seed, width=25).grid(row=0, column=4, sticky="ew")
        ttk.Checkbutton(controls, text="Include LLM preamble", variable=self.include_preamble).grid(
            row=0, column=5, sticky="w", padx=(16, 0)
        )

        ttk.Label(controls, text="Interface:").grid(row=1, column=0, sticky="w", pady=(9, 0))
        self.style_combo = ttk.Combobox(
            controls,
            textvariable=self.interface_style,
            values=(STYLE_RETRO, STYLE_MODERN),
            state="readonly",
            width=18,
        )
        self.style_combo.grid(row=1, column=1, columnspan=2, sticky="w", padx=(7, 0), pady=(9, 0))
        ttk.Label(controls, text="Appearance:").grid(row=1, column=3, sticky="e", padx=(20, 5), pady=(9, 0))
        self.appearance_combo = ttk.Combobox(
            controls,
            textvariable=self.appearance,
            values=(APPEARANCE_LIGHT, APPEARANCE_DARK),
            state="readonly",
            width=12,
        )
        self.appearance_combo.grid(row=1, column=4, sticky="w", pady=(9, 0))
        ttk.Checkbutton(
            controls,
            text="Auto-scrub after paste/edit",
            variable=self.auto_scrub,
            command=self._on_auto_scrub_toggled,
        ).grid(row=1, column=5, sticky="w", padx=(16, 0), pady=(9, 0))

        ttk.Label(controls, text="Known names file:").grid(row=2, column=0, sticky="w", pady=(9, 0))
        ttk.Entry(controls, textvariable=self.known_names_path).grid(
            row=2, column=1, columnspan=4, sticky="ew", padx=(7, 7), pady=(9, 0)
        )
        ttk.Button(controls, text="Browse…", command=self.choose_known_names).grid(
            row=2, column=5, sticky="w", pady=(9, 0)
        )
        controls.columnconfigure(4, weight=1)

        actions = ttk.Frame(self, padding=(14, 2, 14, 8), style="Toolbar.TFrame")
        actions.pack(fill="x")
        self.actions_frame = actions
        ttk.Button(actions, text="Load .log / .txt…", command=self.load_log).pack(side="left")
        self.scrub_button = ttk.Button(actions, text="Scrub", style="Scrub.TButton", command=self.start_scrub)
        self.scrub_button.pack(side="left", padx=8)
        ttk.Button(actions, text="Copy Output", command=self.copy_output).pack(side="left")
        ttk.Button(actions, text="Save Output As…", command=self.save_output).pack(side="left", padx=(8, 0))
        self.mapping_button = ttk.Button(actions, text="View Mapping (Local Only)", command=self.view_mapping)
        self.mapping_button.pack(side="right")
        self.mapping_button.state(["disabled"])

        self.pane = ttk.Panedwindow(self, orient="horizontal", style="TPanedwindow")
        self.pane.pack(fill="both", expand=True, padx=14, pady=(0, 9))
        input_frame = ttk.LabelFrame(
            self.pane, text="Input log", padding=6, style="Panel.TLabelframe"
        )
        output_frame = ttk.LabelFrame(
            self.pane,
            text="Scrubbed output — safe-to-paste candidate",
            padding=6,
            style="Panel.TLabelframe",
        )
        self.pane.add(input_frame, weight=1)
        self.pane.add(output_frame, weight=1)

        self.input_text = self._make_text_area(input_frame)
        self.output_text = self._make_text_area(output_frame)

        self.status_label = ttk.Label(
            self, textvariable=self.status, style="Status.TLabel", anchor="w"
        )
        self.status_label.pack(fill="x", side="bottom")

    def _make_text_area(self, parent: ttk.Frame) -> tk.Text:
        text = tk.Text(parent, wrap="none", undo=True, font=self.code_font)
        yscroll = ttk.Scrollbar(parent, orient="vertical", command=text.yview)
        xscroll = ttk.Scrollbar(parent, orient="horizontal", command=text.xview)
        text.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        text.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        parent.rowconfigure(0, weight=1)
        parent.columnconfigure(0, weight=1)
        self._text_widgets.append(text)
        return text

    def _bind_events(self) -> None:
        self.input_text.edit_modified(False)
        self.input_text.bind("<<Modified>>", self._on_input_modified, add="+")
        for variable in (self.mode, self.seed, self.include_preamble, self.known_names_path):
            variable.trace_add("write", self._on_scrub_setting_changed)
        self.interface_style.trace_add("write", self._on_visual_setting_changed)
        self.appearance.trace_add("write", self._on_visual_setting_changed)

    def _on_visual_setting_changed(self, *_args: object) -> None:
        self._apply_theme()

    def _apply_theme(self) -> None:
        palette = self.palette
        retro = self.interface_style.get() == STYLE_RETRO
        ui_font = self.ui_font

        self.configure(bg=palette["bg"])
        self._style.configure(".", font=ui_font, background=palette["bg"], foreground=palette["text"])
        self._style.configure("TFrame", background=palette["bg"])
        self._style.configure("Header.TFrame", background=palette["surface"])
        self._style.configure("Toolbar.TFrame", background=palette["bg"])
        self._style.configure("About.TFrame", background=palette["surface"])
        self._style.configure("TLabel", background=palette["bg"], foreground=palette["text"])
        self._style.configure("HeaderLogo.TLabel", background=palette["surface"])
        self._style.configure("Header.TLabel", background=palette["surface"], foreground=palette["text"])
        self._style.configure("Subheader.TLabel", background=palette["surface"], foreground=palette["muted"])
        self._style.configure("Profile.TLabel", background=palette["surface_alt"], foreground=palette["text"])
        self._style.configure("About.TLabel", background=palette["surface"])
        self._style.configure("AboutTitle.TLabel", background=palette["surface"], foreground=palette["text"])
        self._style.configure("AboutSubtitle.TLabel", background=palette["surface"], foreground=palette["muted"])
        self._style.configure("AboutBody.TLabel", background=palette["surface"], foreground=palette["text"])

        self._style.configure(
            "TButton",
            background=palette["surface_alt"],
            foreground=palette["text"],
            bordercolor=palette["border"],
            lightcolor=palette["border_light"],
            darkcolor=palette["border"],
            relief="raised" if retro else "flat",
            borderwidth=2 if retro else 1,
            padding=(8, 5) if retro else (12, 7),
            font=ui_font,
        )
        self._style.map(
            "TButton",
            background=[("active", palette["surface_alt"]), ("pressed", palette["surface"])],
            foreground=[("disabled", palette["muted"])],
            relief=[("pressed", "sunken" if retro else "flat")],
        )
        self._style.configure(
            "Scrub.TButton",
            background=palette["accent"],
            foreground=palette["accent_text"],
            bordercolor=palette["border"] if retro else palette["accent"],
            lightcolor=palette["border_light"] if retro else palette["accent"],
            darkcolor=palette["border"] if retro else palette["accent"],
            relief="raised" if retro else "flat",
            borderwidth=3 if retro else 0,
            padding=(15, 8) if retro else (18, 9),
            font=(ui_font[0], ui_font[1], "bold"),
        )
        self._style.map(
            "Scrub.TButton",
            background=[("active", palette["accent_hover"]), ("pressed", palette["accent_hover"])],
            foreground=[("disabled", palette["muted"])],
            relief=[("pressed", "sunken" if retro else "flat")],
        )

        self._style.configure(
            "TCheckbutton", background=palette["bg"], foreground=palette["text"], font=ui_font
        )
        self._style.map(
            "TCheckbutton",
            background=[("active", palette["bg"])],
            foreground=[("disabled", palette["muted"])],
            indicatorcolor=[("selected", palette["accent"]), ("!selected", palette["surface"])],
        )
        self._style.configure(
            "TRadiobutton", background=palette["bg"], foreground=palette["text"], font=ui_font
        )
        self._style.map(
            "TRadiobutton",
            background=[("active", palette["bg"])],
            foreground=[("disabled", palette["muted"])],
            indicatorcolor=[("selected", palette["accent"]), ("!selected", palette["surface"])],
        )
        self._style.configure(
            "TEntry",
            fieldbackground=palette["input_bg"],
            foreground=palette["input_fg"],
            insertcolor=palette["input_fg"],
            bordercolor=palette["border"],
            lightcolor=palette["border_light"],
            darkcolor=palette["border"],
            relief="sunken" if retro else "flat",
            borderwidth=2 if retro else 1,
            padding=4 if retro else 7,
        )
        self._style.map(
            "TEntry",
            fieldbackground=[("disabled", palette["surface_alt"])],
            foreground=[("disabled", palette["muted"])],
            bordercolor=[("focus", palette["accent"])],
        )
        self._style.configure(
            "TCombobox",
            fieldbackground=palette["input_bg"],
            background=palette["surface_alt"],
            foreground=palette["input_fg"],
            arrowcolor=palette["text"],
            bordercolor=palette["border"],
            lightcolor=palette["border_light"],
            darkcolor=palette["border"],
            relief="sunken" if retro else "flat",
            borderwidth=2 if retro else 1,
            padding=3 if retro else 6,
        )
        self._style.map(
            "TCombobox",
            fieldbackground=[("readonly", palette["input_bg"])],
            foreground=[("readonly", palette["input_fg"])],
            selectbackground=[("readonly", palette["input_bg"])],
            selectforeground=[("readonly", palette["input_fg"])],
            bordercolor=[("focus", palette["accent"])],
        )
        self.option_add("*TCombobox*Listbox.background", palette["input_bg"])
        self.option_add("*TCombobox*Listbox.foreground", palette["input_fg"])
        self.option_add("*TCombobox*Listbox.selectBackground", palette["selection"])
        self.option_add("*TCombobox*Listbox.selectForeground", palette["selection_text"])

        self._style.configure(
            "Panel.TLabelframe",
            background=palette["bg"],
            bordercolor=palette["border"],
            lightcolor=palette["border_light"],
            darkcolor=palette["border"],
            relief="groove" if retro else "flat",
            borderwidth=2 if retro else 1,
        )
        self._style.configure(
            "Panel.TLabelframe.Label",
            background=palette["bg"],
            foreground=palette["text"],
            font=(ui_font[0], ui_font[1], "bold"),
        )
        self._style.configure(
            "TPanedwindow", background=palette["bg"], sashrelief="raised" if retro else "flat"
        )
        self._style.configure(
            "Vertical.TScrollbar",
            background=palette["surface_alt"],
            troughcolor=palette["bg"],
            bordercolor=palette["border"],
            arrowcolor=palette["text"],
            relief="raised" if retro else "flat",
        )
        self._style.configure(
            "Horizontal.TScrollbar",
            background=palette["surface_alt"],
            troughcolor=palette["bg"],
            bordercolor=palette["border"],
            arrowcolor=palette["text"],
            relief="raised" if retro else "flat",
        )

        self._style.configure(
            "Header.TLabel",
            font=("MS Sans Serif", 18, "bold") if retro else ("Segoe UI", 22, "bold"),
        )
        self._style.configure(
            "Subheader.TLabel",
            font=("MS Sans Serif", 8) if retro else ("Segoe UI", 9),
        )
        self._style.configure(
            "Profile.TLabel",
            font=(ui_font[0], 8, "bold"),
            padding=(8, 5),
            relief="sunken" if retro else "flat",
            borderwidth=2 if retro else 0,
        )
        self._style.configure(
            "Warning.TLabel",
            font=(ui_font[0], 10, "bold"),
            foreground=palette["warning"],
            background=palette["warning_bg"],
            relief="ridge" if retro else "flat",
            borderwidth=2 if retro else 0,
            padding=(8, 5),
        )
        self._style.configure(
            "Status.TLabel",
            background=palette["status_bg"],
            foreground=palette["text"],
            relief="sunken" if retro else "flat",
            borderwidth=2 if retro else 0,
            padding=(7, 4) if retro else (12, 7),
            font=(ui_font[0], 8) if retro else (ui_font[0], 9),
        )
        self._style.configure(
            "AboutTitle.TLabel",
            font=("MS Sans Serif", 17, "bold") if retro else ("Segoe UI", 21, "bold"),
        )
        self._style.configure(
            "AboutSubtitle.TLabel",
            font=(ui_font[0], 9, "bold") if retro else (ui_font[0], 10),
        )
        self._style.configure("AboutBody.TLabel", font=ui_font)

        for text in self._text_widgets:
            text.configure(
                font=self.code_font,
                background=palette["input_bg"],
                foreground=palette["input_fg"],
                insertbackground=palette["input_fg"],
                selectbackground=palette["selection"],
                selectforeground=palette["selection_text"],
                relief="sunken" if retro else "flat",
                borderwidth=2 if retro else 1,
                highlightthickness=1,
                highlightbackground=palette["border"],
                highlightcolor=palette["accent"],
            )

        for menu in self._menus:
            try:
                menu.configure(
                    background=palette["surface"],
                    foreground=palette["text"],
                    activebackground=palette["selection"],
                    activeforeground=palette["selection_text"],
                    selectcolor=palette["accent"],
                    relief="raised" if retro else "flat",
                    borderwidth=2 if retro else 1,
                )
            except tk.TclError:
                pass

        self.profile_badge.configure(text=f"{self.interface_style.get()} · {self.appearance.get()}")

        for child in list(self.winfo_children()):
            if isinstance(child, MappingWindow) and child.winfo_exists():
                child.apply_colours()

    def _on_input_modified(self, _event: tk.Event[tk.Misc] | None = None) -> None:
        if not self.input_text.edit_modified():
            return
        self.input_text.edit_modified(False)
        if self._suppress_input_modified:
            return
        self._mark_scrub_request_changed("Input changed.")

    def _on_scrub_setting_changed(self, *_args: object) -> None:
        if not hasattr(self, "input_text"):
            return
        self._mark_scrub_request_changed("Scrub settings changed.")

    def _mark_scrub_request_changed(self, message: str) -> None:
        self._revision += 1
        self.result = None
        if hasattr(self, "mapping_button"):
            self.mapping_button.state(["disabled"])
        if self.auto_scrub.get():
            self._schedule_auto_scrub()
            if not self._scrub_in_progress:
                self.status.set(f"{message} Auto-scrub queued…")
        elif not self._scrub_in_progress:
            self.status.set(f"{message} Press Scrub when ready.")

    def _on_auto_scrub_toggled(self) -> None:
        if self.auto_scrub.get():
            self.status.set("Auto-scrub enabled. Changes will be processed locally after a short pause.")
            self._schedule_auto_scrub(delay_ms=100)
        else:
            self._cancel_auto_scrub_job()
            self._pending_auto_scrub = False
            self.status.set("Auto-scrub disabled. Use the Scrub button when ready.")

    def _schedule_auto_scrub(self, delay_ms: int = AUTO_SCRUB_DELAY_MS) -> None:
        self._cancel_auto_scrub_job()
        self._auto_scrub_job = self.after(delay_ms, self._run_auto_scrub)

    def _cancel_auto_scrub_job(self) -> None:
        if self._auto_scrub_job is not None:
            try:
                self.after_cancel(self._auto_scrub_job)
            except tk.TclError:
                pass
            self._auto_scrub_job = None

    def _run_auto_scrub(self) -> None:
        self._auto_scrub_job = None
        if self.auto_scrub.get():
            self.start_scrub(auto=True)

    def choose_known_names(self) -> None:
        path = filedialog.askopenfilename(
            parent=self,
            title="Choose known names file",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
        )
        if path:
            self.known_names_path.set(path)

    def load_log(self) -> None:
        path = filedialog.askopenfilename(
            parent=self,
            title="Load log",
            filetypes=[("Log and text files", "*.log *.txt"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            content = Path(path).read_text(encoding="utf-8-sig", errors="replace")
        except OSError as exc:
            messagebox.showerror("FROG", f"Could not read file:\n{exc}", parent=self)
            return
        self.input_text.delete("1.0", "end")
        self.input_text.insert("1.0", content)
        self.input_text.edit_modified(True)
        self._on_input_modified()
        self.status.set(
            f"Loaded {Path(path).name} ({len(content):,} characters)."
            + (" Auto-scrub queued…" if self.auto_scrub.get() else "")
        )

    def start_scrub(self, auto: bool = False) -> None:
        if self._scrub_in_progress:
            if auto:
                self._pending_auto_scrub = True
                self.status.set("Input changed while scrubbing; one fresh pass is queued…")
            return

        text = self.input_text.get("1.0", "end-1c")
        if not text:
            if auto:
                self.output_text.delete("1.0", "end")
                self.result = None
                self.mapping_button.state(["disabled"])
                self.status.set("Ready. Paste or load a log.")
            else:
                messagebox.showinfo("FROG", "Paste or load a log first.", parent=self)
            return

        known_path_text = self.known_names_path.get().strip()
        known_path = Path(known_path_text) if known_path_text else None
        if known_path and not known_path.exists():
            if auto:
                self.status.set("Auto-scrub paused: the selected known-names file does not exist.")
            else:
                messagebox.showerror("FROG", "The selected known-names file does not exist.", parent=self)
            return

        self._cancel_auto_scrub_job()
        self._scrub_in_progress = True
        self._pending_auto_scrub = False
        request_revision = self._revision
        self.scrub_button.state(["disabled"])
        self.mapping_button.state(["disabled"])
        self.status.set("Scrubbing locally…" if not auto else "Auto-scrubbing locally…")
        mode = self.mode.get()
        seed = self.seed.get()
        include_preamble = self.include_preamble.get()

        def worker() -> None:
            try:
                result = self.scrubber.scrub(
                    text,
                    mode=mode,
                    seed=seed,
                    include_preamble=include_preamble,
                    known_names_path=known_path,
                )
            except Exception as exc:
                self._worker_results.put(("error", exc, request_revision))
                return
            self._worker_results.put(("success", result, request_revision))

        threading.Thread(target=worker, daemon=True, name="frog-scrubber").start()

    def _poll_worker_results(self) -> None:
        try:
            while True:
                outcome, payload, request_revision = self._worker_results.get_nowait()
                if outcome == "success":
                    self._scrub_finished(payload, request_revision)  # type: ignore[arg-type]
                else:
                    self._scrub_failed(payload, request_revision)  # type: ignore[arg-type]
        except queue.Empty:
            pass
        if self.winfo_exists():
            self._poll_job = self.after(40, self._poll_worker_results)

    def _scrub_finished(self, result: ScrubResult, request_revision: int) -> None:
        self._scrub_in_progress = False
        self.scrub_button.state(["!disabled"])

        if request_revision != self._revision:
            self.result = None
            self.mapping_button.state(["disabled"])
            if self.auto_scrub.get():
                self.status.set("Discarded an outdated result; refreshing with the latest input…")
                self._schedule_auto_scrub(delay_ms=40)
            else:
                self.status.set("Input changed during scrubbing. Press Scrub again for a current result.")
            return

        self.result = result
        self.output_text.delete("1.0", "end")
        self.output_text.insert("1.0", result.text)
        self.output_text.see("1.0")
        self.mapping_button.state(["!disabled"])
        summary = ", ".join(
            f"{kind}: {count}" for kind, count in sorted(result.stats.items()) if kind not in {"TOTAL", "UNIQUE"}
        )
        self.status.set(
            f"Done — {result.stats.get('TOTAL', 0)} replacements / {result.stats.get('UNIQUE', 0)} unique. "
            f"Seed: {result.effective_seed}. {summary}"
        )

        if self._pending_auto_scrub and self.auto_scrub.get():
            self._pending_auto_scrub = False
            self._schedule_auto_scrub(delay_ms=40)

    def _scrub_failed(self, exc: Exception, request_revision: int) -> None:
        self._scrub_in_progress = False
        self.scrub_button.state(["!disabled"])
        if request_revision != self._revision and self.auto_scrub.get():
            self._schedule_auto_scrub(delay_ms=50)
            return
        self.status.set("Scrub failed.")
        messagebox.showerror("FROG", f"Scrubbing failed:\n{exc}", parent=self)

    def copy_output(self) -> None:
        output = self.output_text.get("1.0", "end-1c")
        if not output:
            messagebox.showinfo("FROG", "There is no scrubbed output to copy.", parent=self)
            return
        self.clipboard_clear()
        self.clipboard_append(output)
        self.update_idletasks()
        self.status.set("Scrubbed output copied to clipboard. Mapping was not copied.")

    def save_output(self) -> None:
        output = self.output_text.get("1.0", "end-1c")
        if not output:
            messagebox.showinfo("FROG", "There is no scrubbed output to save.", parent=self)
            return
        path = filedialog.asksaveasfilename(
            parent=self,
            title="Save scrubbed output",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("Log files", "*.log"), ("All files", "*.*")],
            initialfile="scrubbed_log.txt",
        )
        if path:
            Path(path).write_text(output, encoding="utf-8")
            self.status.set(f"Saved scrubbed output to {Path(path).name}.")

    def view_mapping(self) -> None:
        if self.result is None:
            return
        window = MappingWindow(self, self.result)
        self._mapping_windows.append(window)

    def show_about(self) -> None:
        AboutWindow(self)

    def destroy(self) -> None:
        self._cancel_auto_scrub_job()
        if self._poll_job is not None:
            try:
                self.after_cancel(self._poll_job)
            except tk.TclError:
                pass
            self._poll_job = None
        super().destroy()

    def run_smoke_test(self) -> None:
        """Exercise startup, all four visual profiles, and auto-scrub without user input."""
        for style in (STYLE_RETRO, STYLE_MODERN):
            for appearance in (APPEARANCE_LIGHT, APPEARANCE_DARK):
                self.interface_style.set(style)
                self.appearance.set(appearance)
                self._apply_theme()
                self.update_idletasks()

        self.seed.set("gui-smoke")
        self.include_preamble.set(False)
        self.auto_scrub.set(True)
        self.clipboard_clear()
        self.clipboard_append("Email: smoke.test@example.org\nSort code: 12-34-56\n")
        self.input_text.focus_set()
        self.input_text.event_generate("<<Paste>>")
        self.update_idletasks()
        self.update()
        self._schedule_auto_scrub(delay_ms=1)

        deadline = time.monotonic() + 8.0
        while time.monotonic() < deadline:
            self.update_idletasks()
            self.update()
            if self.result is not None and "smoke.test@example.org" not in self.output_text.get("1.0", "end-1c"):
                return
            time.sleep(0.01)
        raise RuntimeError("GUI auto-scrub smoke test timed out")


def main(smoke_test: bool = False) -> int:
    app = FrogApp()
    if smoke_test:
        try:
            app.run_smoke_test()
            print("GUI_SMOKE_OK")
        finally:
            app.destroy()
        return 0
    app.mainloop()
    return 0
