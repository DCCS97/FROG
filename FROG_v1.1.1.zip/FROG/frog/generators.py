from __future__ import annotations

import re
import string
import unicodedata
from datetime import date
from random import Random
from typing import Any

from faker import Faker

from .models import SyntheticValue


LETTERS = string.ascii_uppercase
NINO_FIRST = "ABCEGHJKLMNPRSTWXYZ"
NINO_SECOND = "ABCEGHJKLMNPRSTWXYZ"


def digits_only(value: str) -> str:
    return "".join(ch for ch in value if ch.isdigit())


def alnum_only(value: str) -> str:
    return "".join(ch for ch in value if ch.isalnum())


def canonical_exact(value: str) -> str:
    return " ".join(value.strip().split()).casefold()


def canonical_name(value: str) -> str:
    return " ".join(value.strip().split()).casefold()


def canonical_email(value: str) -> str:
    return value.strip().casefold()


def canonical_digits(value: str) -> str:
    return digits_only(value)


def canonical_alnum(value: str) -> str:
    return alnum_only(value).upper()


def canonical_phone(value: str) -> str:
    digits = digits_only(value)
    if value.lstrip().startswith("+44"):
        remainder = digits[2:]
        if remainder.startswith("0"):
            remainder = remainder[1:]
        return "0" + remainder
    return digits


def _ascii_slug(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value)
    ascii_value = normalized.encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^a-z0-9]+", ".", ascii_value.casefold()).strip(".")
    return slug or "user"


def _fill_digits(template: str, digits: str) -> str:
    out: list[str] = []
    index = 0
    for ch in template:
        if ch.isdigit():
            if index >= len(digits):
                out.append(ch)
            else:
                out.append(digits[index])
                index += 1
        else:
            out.append(ch)
    if index < len(digits):
        out.append(digits[index:])
    return "".join(out)


def _fill_alnum(template: str, compact: str) -> str:
    out: list[str] = []
    index = 0
    for ch in template:
        if ch.isalnum():
            if index >= len(compact):
                out.append(ch)
            else:
                replacement = compact[index]
                if ch.islower():
                    replacement = replacement.lower()
                out.append(replacement)
                index += 1
        else:
            out.append(ch)
    if index < len(compact):
        out.append(compact[index:])
    return "".join(out)


def render_plain(value: SyntheticValue, _original: str) -> str:
    return value.base


def render_digits(value: SyntheticValue, original: str) -> str:
    return _fill_digits(original, value.base)


def render_alnum(value: SyntheticValue, original: str) -> str:
    return _fill_alnum(original, value.base)


def generate_email(_real: str, rng: Random, faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    first = _ascii_slug(faker.first_name())
    last = _ascii_slug(faker.last_name())
    suffix = rng.randint(10, 9999)
    return SyntheticValue(f"{first}.{last}{suffix}@example.com")


def generate_name(_real: str, _rng: Random, faker: Faker, metadata: dict[str, Any]) -> SyntheticValue:
    gender = metadata.get("gender")
    if gender == "male":
        return SyntheticValue(faker.name_male())
    if gender == "female":
        return SyntheticValue(faker.name_female())
    return SyntheticValue(faker.name())


def generate_digits(real: str, rng: Random, _faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    length = len(digits_only(real))
    generated = "".join(str(rng.randrange(10)) for _ in range(length))
    if length and not digits_only(real).startswith("0") and generated.startswith("0"):
        generated = str(rng.randrange(1, 10)) + generated[1:]
    return SyntheticValue(generated)


def generate_sort_code(_real: str, rng: Random, _faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    return SyntheticValue("".join(str(rng.randrange(10)) for _ in range(6)))


def luhn_is_valid(value: str) -> bool:
    digits = digits_only(value)
    if not 13 <= len(digits) <= 19:
        return False
    total = 0
    parity = len(digits) % 2
    for index, char in enumerate(digits):
        digit = int(char)
        if index % 2 == parity:
            digit *= 2
            if digit > 9:
                digit -= 9
        total += digit
    return total % 10 == 0


def _luhn_check_digit(partial: str) -> str:
    for candidate in range(10):
        full = partial + str(candidate)
        if luhn_is_valid(full):
            return str(candidate)
    raise RuntimeError("Unable to create Luhn check digit")


def generate_card(real: str, rng: Random, _faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    length = len(digits_only(real))
    # A conspicuously synthetic prefix reduces the chance of creating a live-looking PAN,
    # while the final digit still passes Luhn for software-path testing.
    prefix = ("999999" if length >= 7 else "9" * max(1, length - 1))[: max(0, length - 1)]
    body_len = max(0, length - 1 - len(prefix))
    partial = prefix + "".join(str(rng.randrange(10)) for _ in range(body_len))
    return SyntheticValue(partial + _luhn_check_digit(partial))


def iban_is_valid(value: str) -> bool:
    compact = alnum_only(value).upper()
    if not 15 <= len(compact) <= 34 or not re.fullmatch(r"[A-Z]{2}\d{2}[A-Z0-9]+", compact):
        return False
    rearranged = compact[4:] + compact[:4]
    expanded = "".join(str(ord(ch) - 55) if ch.isalpha() else ch for ch in rearranged)
    remainder = 0
    for chunk_start in range(0, len(expanded), 9):
        remainder = int(str(remainder) + expanded[chunk_start : chunk_start + 9]) % 97
    return remainder == 1


def _iban_check_digits(country: str, bban: str) -> str:
    rearranged = bban + country + "00"
    expanded = "".join(str(ord(ch) - 55) if ch.isalpha() else ch for ch in rearranged)
    remainder = 0
    for chunk_start in range(0, len(expanded), 9):
        remainder = int(str(remainder) + expanded[chunk_start : chunk_start + 9]) % 97
    return f"{98 - remainder:02d}"


def rebuild_uk_iban(
    generated: SyntheticValue,
    *,
    sort_code: str | None = None,
    account_number: str | None = None,
) -> SyntheticValue:
    """Embed linked fake UK sort/account values and recalculate MOD-97 digits."""

    compact = alnum_only(generated.base).upper()
    if len(compact) != 22 or not compact.startswith("GB"):
        return generated

    bban = list(compact[4:])  # 4-char bank code + 6-char sort code + 8-char account
    if sort_code is not None:
        sort_digits = digits_only(sort_code)
        if len(sort_digits) == 6:
            bban[4:10] = sort_digits
    if account_number is not None:
        account_digits = digits_only(account_number)
        if len(account_digits) == 8:
            bban[10:18] = account_digits

    bban_text = "".join(bban)
    return SyntheticValue("GB" + _iban_check_digits("GB", bban_text) + bban_text)


def generate_iban(real: str, rng: Random, _faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    compact = alnum_only(real).upper()
    country = compact[:2]
    original_bban = compact[4:]
    generated_chars: list[str] = []
    for char in original_bban:
        if char.isdigit():
            generated_chars.append(str(rng.randrange(10)))
        else:
            generated_chars.append(rng.choice(LETTERS))
    bban = "".join(generated_chars)
    check = _iban_check_digits(country, bban)
    return SyntheticValue(country + check + bban)


def nino_is_valid(value: str) -> bool:
    compact = re.sub(r"[\s-]", "", value).upper()
    return bool(
        re.fullmatch(
            r"(?!BG|GB|KN|NK|NT|TN|ZZ)(?![DFIQUV])[A-CEGHJ-PR-TW-Z]{2}\d{6}[A-D]",
            compact,
        )
    )


def generate_nino(_real: str, rng: Random, _faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    while True:
        prefix = rng.choice(NINO_FIRST) + rng.choice(NINO_SECOND)
        if prefix not in {"BG", "GB", "KN", "NK", "NT", "TN", "ZZ"}:
            break
    body = "".join(str(rng.randrange(10)) for _ in range(6))
    suffix = rng.choice("ABCD")
    return SyntheticValue(prefix + body + suffix)


def phone_is_valid(value: str) -> bool:
    stripped = value.strip()
    digits = digits_only(stripped)
    if stripped.startswith("+44"):
        remainder = digits[2:]
        if remainder.startswith("0"):
            remainder = remainder[1:]
        return len(remainder) == 10 and remainder[0] in "1237"
    return len(digits) == 11 and digits.startswith("0") and digits[1] in "1237"


def generate_phone(real: str, rng: Random, _faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    national = canonical_phone(real)
    suffix = f"{rng.randrange(1000):03d}"
    if national.startswith("07"):
        # Stable test-shaped mobile range.
        fake_national = "07700900" + suffix
    else:
        # Stable test-shaped geographic range.
        fake_national = "01632960" + suffix
    return SyntheticValue(fake_national)


def render_phone(value: SyntheticValue, original: str) -> str:
    national = value.base
    stripped = original.lstrip()
    if stripped.startswith("+44"):
        has_trunk_zero = bool(re.search(r"\+44\s*(?:\(0\)|0)", original))
        digit_stream = "44" + ("0" if has_trunk_zero else "") + national[1:]
    else:
        digit_stream = national
    return _fill_digits(original, digit_stream)


def postcode_shape(value: str) -> str:
    return "".join("A" if ch.isalpha() else "9" for ch in value if ch.isalnum())


def postcode_is_valid(value: str) -> bool:
    compact = " ".join(value.upper().split())
    return bool(
        re.fullmatch(
            r"(?:GIR 0AA|(?:[A-PR-UWYZ][0-9][0-9A-HJKPSTUW]?|[A-PR-UWYZ][A-HK-Y][0-9][0-9ABEHMNPRV-Y]?) [0-9][ABD-HJLNP-UW-Z]{2})",
            compact,
        )
    )


def generate_postcode(real: str, rng: Random, faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    target_shape = postcode_shape(real)
    for _ in range(100):
        candidate = faker.postcode().upper()
        if postcode_shape(candidate) == target_shape:
            return SyntheticValue(alnum_only(candidate).upper())
    generated: list[str] = []
    for marker in target_shape:
        generated.append(rng.choice(LETTERS) if marker == "A" else str(rng.randrange(10)))
    return SyntheticValue("".join(generated))


def _parse_dob(value: str) -> tuple[date, str] | None:
    raw = value.strip()
    numeric_patterns = [
        (r"(\d{2})/(\d{2})/(\d{4})", "%d/%m/%Y"),
        (r"(\d{2})-(\d{2})-(\d{4})", "%d-%m-%Y"),
        (r"(\d{2})\.(\d{2})\.(\d{4})", "%d.%m.%Y"),
        (r"(\d{4})-(\d{2})-(\d{2})", "%Y-%m-%d"),
        (r"(\d{4})/(\d{2})/(\d{2})", "%Y/%m/%d"),
        (r"(\d{1,2})/(\d{1,2})/(\d{2})", "%d/%m/%y"),
        (r"(\d{1,2})-(\d{1,2})-(\d{2})", "%d-%m-%y"),
    ]
    from datetime import datetime

    for pattern, fmt in numeric_patterns:
        if re.fullmatch(pattern, raw):
            try:
                return datetime.strptime(raw, fmt).date(), fmt
            except ValueError:
                return None
    for fmt in ("%d %B %Y", "%d %b %Y"):
        try:
            return datetime.strptime(raw, fmt).date(), fmt
        except ValueError:
            pass
    return None


def dob_is_valid(value: str) -> bool:
    return _parse_dob(value) is not None


def canonical_dob(value: str) -> str:
    parsed = _parse_dob(value)
    return parsed[0].isoformat() if parsed else canonical_exact(value)


def generate_dob(_real: str, _rng: Random, faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    generated = faker.date_of_birth(minimum_age=18, maximum_age=90)
    return SyntheticValue(generated.isoformat(), payload=generated)


def render_dob(value: SyntheticValue, original: str) -> str:
    generated: date = value.payload or date.fromisoformat(value.base)
    parsed = _parse_dob(original)
    if not parsed:
        return value.base
    _real_date, fmt = parsed
    rendered = generated.strftime(fmt)
    # Preserve unpadded day/month when the source used them.
    if re.fullmatch(r"\d{1,2}/\d{1,2}/\d{2}", original.strip()) and not re.fullmatch(
        r"\d{2}/\d{2}/\d{2}", original.strip()
    ):
        rendered = f"{generated.day}/{generated.month}/{generated.strftime('%y')}"
    elif re.fullmatch(r"\d{1,2}-\d{1,2}-\d{2}", original.strip()) and not re.fullmatch(
        r"\d{2}-\d{2}-\d{2}", original.strip()
    ):
        rendered = f"{generated.day}-{generated.month}-{generated.strftime('%y')}"
    return rendered


def generate_mask(real: str, rng: Random, _faker: Faker, _metadata: dict[str, Any]) -> SyntheticValue:
    compact: list[str] = []
    for ch in real:
        if ch.isdigit():
            compact.append(str(rng.randrange(10)))
        elif ch.isalpha():
            replacement = rng.choice(LETTERS)
            compact.append(replacement.lower() if ch.islower() else replacement)
    return SyntheticValue("".join(compact))
