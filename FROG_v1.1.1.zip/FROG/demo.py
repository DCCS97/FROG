from __future__ import annotations

from frog.engine import Scrubber


SAMPLE = """2026-07-13 09:00:01 INFO Customer Name: Alex Morgan
2026-07-13 09:00:02 INFO Email alex.morgan@contoso.test loaded for Account Number: 12345678
2026-07-13 09:00:03 INFO Sort code 12-34-56; card 4111 1111 1111 1111
2026-07-13 09:00:04 INFO DOB: 04/11/1985; NINO: AB 12 34 56 C
2026-07-13 09:00:05 INFO Address postcode SW1A 1AA; phone +44 7700 900123
2026-07-13 09:00:06 INFO IBAN GB82 WEST 1234 5698 7654 32
2026-07-13 09:00:07 WARN profile lookup for Alex Morgan returned E_PAY_409
2026-07-13 09:00:08 INFO Alex Morgan called back; she said her payment failed twice.
2026-07-13 09:00:09 DEBUG correlationId=12345678 remains intentionally untouched
"""


if __name__ == "__main__":
    result = Scrubber().scrub(SAMPLE, seed="frog-demo-2026", include_preamble=False)
    print("=== BEFORE ===")
    print(SAMPLE)
    print("=== AFTER ===")
    print(result.text)
    print("=== LOCAL-ONLY MAPPING ===")
    print(result.mapping_text())
