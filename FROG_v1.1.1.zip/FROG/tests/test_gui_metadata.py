from __future__ import annotations

import unittest

from frog.gui import (
    APPEARANCE_DARK,
    APPEARANCE_LIGHT,
    AUTO_SCRUB_DELAY_MS,
    PALETTES,
    STYLE_MODERN,
    STYLE_RETRO,
    asset_path,
)


class GuiMetadataTests(unittest.TestCase):
    def test_all_four_visual_profiles_are_defined(self) -> None:
        expected = {
            (STYLE_RETRO, APPEARANCE_LIGHT),
            (STYLE_RETRO, APPEARANCE_DARK),
            (STYLE_MODERN, APPEARANCE_LIGHT),
            (STYLE_MODERN, APPEARANCE_DARK),
        }
        self.assertEqual(set(PALETTES), expected)
        for palette in PALETTES.values():
            for required_key in ("bg", "surface", "text", "input_bg", "input_fg", "accent", "border"):
                self.assertIn(required_key, palette)

    def test_brand_assets_required_by_gui_exist(self) -> None:
        for filename in ("frog_icon.ico", "frog_icon.png", "frog_header.png", "frog_about.png"):
            with self.subTest(filename=filename):
                self.assertTrue(asset_path(filename).is_file())

    def test_auto_scrub_uses_a_short_debounce(self) -> None:
        self.assertGreaterEqual(AUTO_SCRUB_DELAY_MS, 250)
        self.assertLessEqual(AUTO_SCRUB_DELAY_MS, 1000)


if __name__ == "__main__":
    unittest.main()
