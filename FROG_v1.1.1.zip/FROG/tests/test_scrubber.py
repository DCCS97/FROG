from __future__ import annotations

import re
import tempfile
import unittest
from pathlib import Path

from frog.engine import REDACT_PREAMBLE, SYNTHETIC_PREAMBLE, Scrubber
from frog.generators import digits_only, iban_is_valid, luhn_is_valid


class ScrubberTests(unittest.TestCase):
    def setUp(self) -> None:
        self.scrubber = Scrubber()

    def test_consistency_and_gender_cue_on_later_occurrence(self) -> None:
        source = (
            "2026-07-13 09:00 Customer Name: Alex Morgan\n"
            "2026-07-13 09:02 profile lookup completed for Alex Morgan\n"
            "2026-07-13 09:04 Alex Morgan called back; she confirmed the failed payment was hers.\n"
        )
        result = self.scrubber.scrub(source, seed="case-42", include_preamble=False)
        name_entries = [entry for entry in result.mapping if entry.kind == "NAME"]
        self.assertEqual(len(name_entries), 1)
        entry = name_entries[0]
        self.assertEqual(entry.occurrences, 3)
        self.assertEqual(entry.metadata.get("gender"), "female")
        self.assertNotIn("Alex Morgan", result.text)
        self.assertEqual(result.text.count(entry.fake), 3)

    def test_seed_is_reproducible(self) -> None:
        source = "Email: user@example.org\nSort code: 12-34-56\n"
        first = self.scrubber.scrub(source, seed="same-case", include_preamble=False)
        second = self.scrubber.scrub(source, seed="same-case", include_preamble=False)
        other = self.scrubber.scrub(source, seed="different-case", include_preamble=False)
        self.assertEqual(first.text, second.text)
        self.assertNotEqual(first.text, other.text)

    def test_card_is_luhn_valid_and_preserves_digit_count(self) -> None:
        source = "card=4111 1111 1111 1111"
        result = self.scrubber.scrub(source, seed="cards", include_preamble=False)
        card = next(entry for entry in result.mapping if entry.kind == "CARD_NUMBER")
        self.assertTrue(luhn_is_valid(card.fake))
        self.assertEqual(len(digits_only(card.fake)), 16)
        self.assertRegex(card.fake, r"^\d{4} \d{4} \d{4} \d{4}$")

    def test_account_number_requires_label(self) -> None:
        source = "trace=12345678 Account Number: 87654321"
        result = self.scrubber.scrub(source, mode="redact", include_preamble=False)
        self.assertIn("trace=12345678", result.text)
        self.assertNotIn("87654321", result.text)
        self.assertEqual(sum(entry.kind == "ACCOUNT_NUMBER" for entry in result.mapping), 1)

    def test_iban_replacement_is_valid_and_same_shape(self) -> None:
        source = "IBAN: GB82 WEST 1234 5698 7654 32"
        result = self.scrubber.scrub(source, seed="iban", include_preamble=False)
        entry = next(item for item in result.mapping if item.kind == "IBAN")
        self.assertTrue(iban_is_valid(entry.fake))
        self.assertEqual(len(entry.fake), len("GB82 WEST 1234 5698 7654 32"))

    def test_labelled_invalid_checksum_iban_is_still_scrubbed(self) -> None:
        source = '"iban": "GB29BARC20451288102938",'
        self.assertFalse(iban_is_valid("GB29BARC20451288102938"))

        result = self.scrubber.scrub(source, seed="json-iban", include_preamble=False)

        entries = [item for item in result.mapping if item.kind == "IBAN"]
        self.assertEqual(len(entries), 1)
        self.assertNotIn("GB29BARC20451288102938", result.text)
        self.assertTrue(iban_is_valid(entries[0].fake))
        self.assertEqual(len(entries[0].fake), len("GB29BARC20451288102938"))

    def test_unlabelled_invalid_checksum_iban_shape_is_not_scrubbed(self) -> None:
        source = "downstream token GB29BARC20451288102938 was rejected"
        result = self.scrubber.scrub(source, seed="json-iban", include_preamble=False)
        self.assertEqual(result.text, source)
        self.assertFalse(any(item.kind == "IBAN" for item in result.mapping))

    def test_json_routing_data_scrubs_iban_sort_code_and_account_number(self) -> None:
        source = (
            '"routing_data": {\n'
            '  "sort_code": "20-45-12",\n'
            '  "account_number": "88102938",\n'
            '  "iban": "GB29BARC20451288102938"\n'
            '}'
        )
        result = self.scrubber.scrub(source, seed="reported-case", include_preamble=False)

        self.assertNotIn("20-45-12", result.text)
        self.assertNotIn("88102938", result.text)
        self.assertNotIn("GB29BARC20451288102938", result.text)
        self.assertEqual(result.stats.get("SORT_CODE"), 1)
        self.assertEqual(result.stats.get("ACCOUNT_NUMBER"), 1)
        self.assertEqual(result.stats.get("IBAN"), 1)

        fake_sort = next(item.fake for item in result.mapping if item.kind == "SORT_CODE")
        fake_account = next(item.fake for item in result.mapping if item.kind == "ACCOUNT_NUMBER")
        fake_iban = next(item.fake for item in result.mapping if item.kind == "IBAN")
        compact_iban = re.sub(r"[^A-Z0-9]", "", fake_iban.upper())
        self.assertEqual(compact_iban[8:14], digits_only(fake_sort))
        self.assertEqual(compact_iban[14:22], digits_only(fake_account))
        self.assertTrue(iban_is_valid(fake_iban))
        self.assertIn("RELATIONSHIP: embeds the matching fake sort code/account number", result.mapping_text())

    def test_known_names_file_catches_unlabelled_name(self) -> None:
        source = "Escalated by Sam O'Neil after timeout."
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "names.txt"
            path.write_text("Sam O'Neil\n", encoding="utf-8")
            result = self.scrubber.scrub(source, seed="known", include_preamble=False, known_names_path=path)
        self.assertNotIn("Sam O'Neil", result.text)
        self.assertEqual(result.mapping[0].kind, "NAME")

    def test_preamble_is_mode_aware(self) -> None:
        source = "Email: user@example.org"
        synthetic = self.scrubber.scrub(source, seed="x", mode="synthetic", include_preamble=True)
        redacted = self.scrubber.scrub(source, seed="x", mode="redact", include_preamble=True)
        self.assertTrue(synthetic.text.startswith(SYNTHETIC_PREAMBLE))
        self.assertTrue(redacted.text.startswith(REDACT_PREAMBLE))

    def test_redaction_placeholder_is_consistent(self) -> None:
        source = "Customer Name: John Smith\nMr John Smith called.\n"
        result = self.scrubber.scrub(source, mode="redact", include_preamble=False)
        placeholders = re.findall(r"\[NAME_\d+\]", result.text)
        self.assertEqual(len(placeholders), 2)
        self.assertEqual(len(set(placeholders)), 1)

    def test_same_phone_in_local_and_international_format_stays_linked(self) -> None:
        source = "mobile=07700 900123 alternate=+44 7700 900123"
        result = self.scrubber.scrub(source, seed="phones", include_preamble=False)
        entries = [entry for entry in result.mapping if entry.kind == "PHONE"]
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0].occurrences, 2)
        self.assertEqual(len(entries[0].rendered_fakes), 2)
        self.assertRegex(result.text, r"0\d{4} \d{6}")
        self.assertRegex(result.text, r"\+44 \d{4} \d{6}")

    def test_custom_rule_file_is_loaded_without_core_changes(self) -> None:
        custom_json = r"""[
          {"name":"case_id","kind":"CASE_ID","regex":"caseId\\s*[:=]\\s*(?P<value>CASE-[A-Z0-9]{6})","generator":"mask"}
        ]"""
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "custom_rules.json"
            path.write_text(custom_json, encoding="utf-8")
            result = Scrubber(path).scrub("caseId=CASE-AB12CD", seed="custom", include_preamble=False)
        self.assertNotIn("CASE-AB12CD", result.text)
        self.assertEqual(result.mapping[0].kind, "CASE_ID")

    def test_labelled_account_can_end_with_full_stop(self) -> None:
        result = self.scrubber.scrub("Account Number: 87654321.", mode="redact", include_preamble=False)
        self.assertIn("[ACCOUNT_NUMBER_1].", result.text)


if __name__ == "__main__":
    unittest.main()
