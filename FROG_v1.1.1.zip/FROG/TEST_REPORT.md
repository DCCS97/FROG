# FROG v1.1.0 test report

## Result

- Automated tests: **17 passed**
- Headless tkinter startup: **passed**
- All four visual profiles: **constructed successfully**
- Clipboard-paste auto-scrub: **passed**
- Reported JSON IBAN regression: **passed**
- UK IBAN/sort-code/account-number relationship check: **passed**
- Large-log stress check: **passed**
- Supplied mascot PNG/ICO assets: **opened successfully**

## Automated tests

```text
test_all_four_visual_profiles_are_defined ... ok
test_auto_scrub_uses_a_short_debounce ... ok
test_brand_assets_required_by_gui_exist ... ok
test_account_number_requires_label ... ok
test_card_is_luhn_valid_and_preserves_digit_count ... ok
test_consistency_and_gender_cue_on_later_occurrence ... ok
test_custom_rule_file_is_loaded_without_core_changes ... ok
test_iban_replacement_is_valid_and_same_shape ... ok
test_json_routing_data_scrubs_iban_sort_code_and_account_number ... ok
test_known_names_file_catches_unlabelled_name ... ok
test_labelled_account_can_end_with_full_stop ... ok
test_labelled_invalid_checksum_iban_is_still_scrubbed ... ok
test_preamble_is_mode_aware ... ok
test_redaction_placeholder_is_consistent ... ok
test_same_phone_in_local_and_international_format_stays_linked ... ok
test_seed_is_reproducible ... ok
test_unlabelled_invalid_checksum_iban_shape_is_not_scrubbed ... ok

----------------------------------------------------------------------
Ran 17 tests in 0.069s

OK
```

## GUI and auto-scrub smoke test

Executed under a virtual X display:

```text
xvfb-run -a python main.py --smoke-test
GUI_SMOKE_OK
```

The smoke test:

1. Constructs Retro 90s Light.
2. Switches to Retro 90s Dark.
3. Switches to Modern sleek Light.
4. Switches to Modern sleek Dark.
5. Places a sample log on the local clipboard.
6. Generates a real tkinter `<<Paste>>` event into the input panel.
7. Waits for the debounced background auto-scrub.
8. Confirms the source email no longer appears in the output.

The background worker no longer calls tkinter directly. Results are placed on a thread-safe queue and applied by a polling callback on tkinter's main thread.

## Visual previews

Two rendered previews are included in `docs/`:

- `docs/retro_light_preview.png`
- `docs/modern_dark_preview.png`

The exact native rendering will vary slightly on Windows because tkinter uses the installed system fonts and Windows display scaling.

## Branding asset verification

The supplied 1254 × 1254 transparent PNG was preserved and converted into runtime assets:

```text
assets/frog_icon.ico      ICO 256 × 256, multi-resolution payload
assets/frog_icon.png      PNG 256 × 256 RGBA
assets/frog_header.png    PNG 64 × 64 RGBA
assets/frog_about.png     PNG 256 × 256 RGBA
assets/frog_brand.png     PNG 512 × 512 RGBA
assets/frog_brand_original.png  original-resolution RGBA
```

The ICO and all PNGs opened successfully through Pillow during verification. Pillow is not required to run FROG because all derivatives are already included.

## Large-log stress check

```text
Input characters: 2,000,060
Detected replacements: 60,001
Unique mappings: 3
Elapsed in this environment: 1.319 seconds
Later-line inferred gender: female
```

The stress input contained 20,000 repeated three-line records plus a final later occurrence containing `she` and `hers`. The name replacement remained consistent across 20,001 occurrences.

## Reported JSON IBAN regression

The source value `GB29BARC20451288102938` has an invalid MOD-97 checksum. FROG handles it contextually:

- Labelled `iban` field: scrub it because it is clearly an identifier even when malformed.
- Unlabelled invalid IBAN-shaped token: leave it untouched to reduce broad false positives.

With seed `reported-case`:

```text
BEFORE
"routing_data": {
  "sort_code": "20-45-12",
  "account_number": "88102938",
  "iban": "GB29BARC20451288102938"
}

AFTER
"routing_data": {
  "sort_code": "49-21-22",
  "account_number": "55302096",
  "iban": "GB45XHFX49212255302096"
}
```

The generated IBAN passes MOD-97 and embeds the matching synthetic sort code and account number.

## Remaining platform-specific uncertainty

A genuine Windows `.exe` cannot be produced or executed in this Linux environment. The included PyInstaller command is unchanged except that it now bundles the updated image assets through `--add-data "assets;assets"`. The build must still be performed on Windows. Unsigned executables may require internal allow-listing or signing depending on endpoint-security policy.
