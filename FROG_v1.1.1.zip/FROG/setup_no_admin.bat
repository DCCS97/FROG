@echo off
setlocal
cd /d "%~dp0"
py -m venv .venv
if errorlevel 1 goto :error
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 goto :error
echo.
echo FROG is installed locally in this folder. No administrator rights were used.
echo Run it with run_frog.bat
pause
exit /b 0
:error
echo.
echo Setup failed. If Python is not installed, use a pre-built FROG.exe instead.
pause
exit /b 1
