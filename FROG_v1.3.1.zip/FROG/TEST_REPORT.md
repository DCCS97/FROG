# FROG v1.3.1 Test Report

Test date: 2026-07-13  
Environment: Linux/Python test environment. The Windows PyInstaller executable must still be built and executed on Windows.

## Automated suite

Command:

```text
python -m unittest discover -s tests -v
```

Result:

```text
Ran 32 tests in 0.206s
OK
```

Coverage includes:

- Seed reproducibility and repeated-value consistency
- Later-occurrence gender cues for names
- Label-anchored account-number behaviour
- Luhn-valid card generation
- Labelled-invalid versus unlabelled-invalid IBAN handling
- UK IBAN/sort-code/account-number relationship preservation
- Compact sort codes in XML, JSON and Splunk key/value data
- XML namespaces, attributes and CDATA
- `dob`, `dateOfBirth` and `birth-date` aliases
- Irish and Spanish IBAN country/length/checksum preservation
- Polish and Irish international phone-country preservation
- Independent Irish and UK address contexts in adjacent JSON objects
- Persistent non-sensitive preferences with seed exclusion
- JSON/XML pretty-printing and plain-log layout preservation
- Explicit GUI labelling that Pretty Print applies to input and output
- Custom rules and known-names file support

## GUI smoke test

Command:

```text
xvfb-run -a python main.py --smoke-test
```

Result:

```text
GUI_SMOKE_OK
```

The smoke test:

1. Constructed the tkinter application.
2. Exercised all four Retro/Modern and Light/Dark visual profiles.
3. Enabled Auto Scrub and Pretty Print.
4. Pasted a compact JSON payload containing an invented email and sort code.
5. Confirmed the input pane was indented and syntax-highlighted while retaining the original PII.
6. Confirmed the output pane was indented and the original email was replaced.
7. Disabled Pretty Print and confirmed the unedited input returned to its original compact layout.
8. Closed the GUI without an exception.

## Dual-pane pretty-print behaviour

With **Pretty-print input + output** enabled:

- Complete or embedded JSON/XML is detected automatically.
- The input pane is formatted after a short debounce following paste/edit.
- The scrubbed output is formatted using the same recognised structure.
- Syntax colours are applied independently to both tkinter text widgets.
- Copying or saving output still produces ordinary plain text; colour tags are not embedded.
- Unrecognised plain logs are not restructured, although timestamps and log levels may receive display highlighting.

When Pretty Print is disabled, FROG restores the original input layout if the formatted input has not been manually edited. If the user has edited the formatted text, those edits are retained rather than overwritten.

## Existing origin-preservation demonstration

Seed:

```text
INC123456789
```

Selected before → after values from the retained regression demonstration:

```text
DOB                 04/11/1985                  → 24/07/1970
Irish phone         +353 85 123 4567            → +353 85 012 2620
Irish street        12 O'Connell Street         → 47 Piggott Street
Irish city          Dublin                      → Glenn Ville
Irish Eircode       D02 X285                    → V15 P089
Irish IBAN          IE29AIBK93115212345678      → IE87LYSS43414563360452
UK street           82 Deansgate                → 6 Clark Drives
UK city             Manchester                  → Sallytown
UK postcode         M3 2ER                      → E6 1EJ
Polish phone        +48 512 345 678             → +48 512 349 713
Spanish IBAN        ES9121000418450200051332     → ES2720085618148708817411
```

The automated tests continue to verify country-code preservation and valid generated IBAN checksums.

## Packaging status

The Python source, unit tests and headless GUI launch were verified here. A genuine Windows `.exe` cannot be built or executed in this Linux environment. Run `build_windows_exe.bat` on Windows to create `dist\FROG.exe`.

## Known limitations

- Pattern/rule matching cannot guarantee detection of every proprietary schema.
- Pretty-printing only restructures confidently parsed JSON/XML; arbitrary Splunk lines and stack traces are left in their original layout.
- Input layout restoration is available only while the formatted text still exactly matches FROG's rendering. Manual edits are deliberately preserved.
- The application remains a risk-reduction/pseudonymisation aid rather than a certified DLP control.
