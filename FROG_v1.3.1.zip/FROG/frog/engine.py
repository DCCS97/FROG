from __future__ import annotations

import hashlib
import re
import secrets
from bisect import bisect_right
from collections import defaultdict
from dataclasses import replace
from pathlib import Path
from random import Random
from typing import Any, Iterable

from faker import Faker

from .countries import (
    country_name,
    extract_country_hints,
    faker_locale_for_country,
    infer_country_from_postal_code,
)
from .formatting import pretty_print_log, syntax_spans
from .generators import (
    alnum_only,
    canonical_name,
    generate_name,
    phone_country,
    rebuild_uk_iban,
    render_plain,
)
from .models import Detection, MappingEntry, PatternRule, ScrubResult, SyntheticValue
from .rules import RULE_REGISTRY, load_custom_rules


SYNTHETIC_PREAMBLE = (
    "All personally identifiable information in this log has been replaced with consistent "
    "synthetic placeholder values for data-protection reasons. The same real value always maps "
    "to the same fake value throughout, so relationships between entries are preserved. Please "
    "do not treat these values as malformed or as the cause of any issue — focus on the actual "
    "technical behaviour (error codes, timestamps, sequence of events, etc.)."
)

REDACT_PREAMBLE = (
    "All personally identifiable information in this log has been replaced with consistent "
    "redaction placeholders for data-protection reasons. The same real value always maps to the "
    "same placeholder throughout, so relationships between entries are preserved. Please focus "
    "on the actual technical behaviour (error codes, timestamps, sequence of events, etc.)."
)

_NAME_STOPWORDS = {
    "error",
    "exception",
    "payment gateway",
    "request failed",
    "service account",
    "unknown user",
    "null value",
    "not found",
}

_COUNTRY_AWARE_KINDS = {"IBAN", "PHONE", "POSTCODE", "ADDRESS", "STREET_ADDRESS", "CITY", "REGION"}
_ADDRESS_KINDS = {"POSTCODE", "ADDRESS", "STREET_ADDRESS", "CITY", "REGION"}
GroupKey = tuple[str, str, str]


class Scrubber:
    def __init__(self, custom_rules_path: Path | None = None) -> None:
        self.rules = [*RULE_REGISTRY, *load_custom_rules(custom_rules_path)]
        self._name_rule = PatternRule(
            name="expanded_name",
            kind="NAME",
            regex=re.compile(r"$^"),
            replacement_fn=generate_name,
            renderer=render_plain,
            canonicalizer=canonical_name,
            priority=57,
            is_name_rule=True,
        )

    @staticmethod
    def _stable_seed(seed: str, kind: str, canonical: str, attempt: int) -> int:
        payload = f"FROG\0{seed}\0{kind}\0{canonical}\0{attempt}".encode("utf-8")
        return int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")

    @staticmethod
    def _read_known_names(path: Path | None) -> list[str]:
        if path is None:
            return []
        lines = path.read_text(encoding="utf-8-sig").splitlines()
        seen: set[str] = set()
        names: list[str] = []
        for line in lines:
            name = " ".join(line.strip().split())
            if not name or name.startswith("#"):
                continue
            canonical = canonical_name(name)
            if canonical not in seen:
                names.append(name)
                seen.add(canonical)
        return names

    @staticmethod
    def _looks_like_name(value: str) -> bool:
        canonical = canonical_name(value)
        if canonical in _NAME_STOPWORDS:
            return False
        tokens = canonical.split()
        return 1 <= len(tokens) <= 4 and all(any(ch.isalpha() for ch in token) for token in tokens)

    def _initial_detections(self, text: str, known_names: Iterable[str]) -> list[Detection]:
        detections: list[Detection] = []
        for rule in self.rules:
            for match in rule.regex.finditer(text):
                try:
                    value = match.group(rule.value_group)
                    start, end = match.span(rule.value_group)
                except (IndexError, KeyError):
                    continue
                value = value.strip()
                if not value or not rule.validator(value):
                    continue
                if rule.is_name_rule and not self._looks_like_name(value):
                    continue
                detections.append(
                    Detection(
                        kind=rule.kind,
                        real=value,
                        canonical=rule.canonicalizer(value),
                        start=start,
                        end=end,
                        rule=rule,
                        metadata={},
                    )
                )

        for name in known_names:
            if not self._looks_like_name(name):
                continue
            expression = self._name_expression(name)
            for match in expression.finditer(text):
                value = match.group(0)
                detections.append(
                    Detection(
                        kind="NAME",
                        real=value,
                        canonical=canonical_name(value),
                        start=match.start(),
                        end=match.end(),
                        rule=self._name_rule,
                        metadata={},
                    )
                )
        return detections

    @staticmethod
    def _json_containers(text: str) -> list[dict[str, Any]]:
        containers: list[dict[str, Any]] = []
        stack: list[int] = []
        in_string = False
        escaped = False
        for index, char in enumerate(text):
            if in_string:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    in_string = False
                continue
            if char == '"':
                in_string = True
            elif char == "{":
                parent = stack[-1] if stack else None
                containers.append(
                    {"start": index, "end": len(text), "parent": parent, "country": None}
                )
                stack.append(len(containers) - 1)
            elif char == "}" and stack:
                container_index = stack.pop()
                containers[container_index]["end"] = index + 1
        return containers

    @staticmethod
    def _container_at(
        position: int,
        containers: list[dict[str, Any]],
        starts: list[int],
    ) -> int | None:
        index = bisect_right(starts, position) - 1
        while index >= 0:
            container = containers[index]
            if container["start"] <= position < container["end"]:
                return index
            parent = container["parent"]
            if parent is None:
                return None
            index = parent
        return None

    @classmethod
    def _context_country(
        cls,
        position: int,
        hints: list[Any],
        hint_starts: list[int],
        containers: list[dict[str, Any]],
        container_starts: list[int],
    ) -> str | None:
        # Prefer the smallest enclosing JSON object. Walk to its parent only if
        # the nested object does not carry its own country field.
        container_index = cls._container_at(position, containers, container_starts)
        while container_index is not None:
            container = containers[container_index]
            if container["country"]:
                return str(container["country"])
            container_index = container["parent"]

        # XML and line-oriented Splunk records use the nearest hint. Bisect keeps
        # this O(log n) instead of scanning every country field for every PII hit.
        if not hints:
            return None
        insertion = bisect_right(hint_starts, position)
        candidates = []
        if insertion:
            candidates.append(hints[insertion - 1])
        if insertion < len(hints):
            candidates.append(hints[insertion])
        best = min(
            candidates,
            key=lambda hint: min(abs(position - hint.start), abs(position - hint.end)),
            default=None,
        )
        if best is None:
            return None
        distance = min(abs(position - best.start), abs(position - best.end))
        return best.code if distance <= 1600 else None

    @classmethod
    def _annotate_geography(cls, text: str, detections: list[Detection]) -> list[Detection]:
        """Attach origin metadata without replacing the non-PII country field itself."""

        hints = extract_country_hints(text)
        hint_starts = [hint.start for hint in hints]
        containers = cls._json_containers(text)
        container_starts = [container["start"] for container in containers]
        for hint in hints:
            container_index = cls._container_at(hint.start, containers, container_starts)
            if container_index is not None:
                containers[container_index]["country"] = hint.code
        annotated: list[Detection] = []
        for detection in detections:
            if detection.kind not in _COUNTRY_AWARE_KINDS:
                annotated.append(detection)
                continue

            code: str | None = None
            if detection.kind == "IBAN":
                compact = alnum_only(detection.real).upper()
                if len(compact) >= 2 and compact[:2].isalpha():
                    code = compact[:2]
            elif detection.kind == "PHONE":
                code = phone_country(detection.real)
            elif detection.kind == "POSTCODE":
                code = infer_country_from_postal_code(detection.real)

            if code is None and detection.kind in _ADDRESS_KINDS:
                code = cls._context_country(
                    detection.start,
                    hints,
                    hint_starts,
                    containers,
                    container_starts,
                )

            # A local number or an address without any explicit country is
            # interpreted as UK data, matching the tool's operational default.
            if code is None and detection.kind in _ADDRESS_KINDS:
                code = "GB"

            metadata = dict(detection.metadata)
            if code:
                metadata["country_code"] = code
                metadata["country_name"] = country_name(code) or code
            annotated.append(replace(detection, metadata=metadata))
        return annotated

    @staticmethod
    def _name_expression(name: str) -> re.Pattern[str]:
        tokens = [re.escape(token) for token in name.split()]
        body = r"\s+".join(tokens)
        return re.compile(rf"(?<![\w'’\-]){body}(?![\w'’\-])", re.I)

    def _expand_names_and_infer_gender(
        self, text: str, detections: list[Detection]
    ) -> tuple[list[Detection], dict[str, str | None]]:
        variants: dict[str, set[str]] = defaultdict(set)
        for detection in detections:
            if detection.kind == "NAME":
                variants[detection.canonical].add(detection.real)

        expanded: list[Detection] = [d for d in detections if d.kind != "NAME"]
        name_occurrences: dict[str, list[Detection]] = defaultdict(list)
        for canonical, raw_variants in variants.items():
            # Include a normalized spacing variant so "Jane  Doe" and "Jane Doe" remain linked.
            representative = min(raw_variants, key=lambda value: (len(value), value.casefold()))
            expression = self._name_expression(" ".join(representative.split()))
            for match in expression.finditer(text):
                occurrence = Detection(
                    kind="NAME",
                    real=match.group(0),
                    canonical=canonical,
                    start=match.start(),
                    end=match.end(),
                    rule=self._name_rule,
                    metadata={},
                )
                name_occurrences[canonical].append(occurrence)
                expanded.append(occurrence)

        gender_map: dict[str, str | None] = {}
        for canonical, occurrences in name_occurrences.items():
            male_score = 0
            female_score = 0
            for occurrence in occurrences:
                line_start = text.rfind("\n", 0, occurrence.start) + 1
                line_end = text.find("\n", occurrence.end)
                if line_end == -1:
                    line_end = len(text)
                line = text[line_start:line_end]
                relative_start = occurrence.start - line_start
                prefix = line[max(0, relative_start - 20) : relative_start]
                title_match = re.search(r"\b(Mr|Mrs|Ms|Miss|Dr)\.?\s*$", prefix, re.I)
                if title_match:
                    title = title_match.group(1).casefold()
                    if title == "mr":
                        male_score += 5
                    elif title in {"mrs", "ms", "miss"}:
                        female_score += 5

                lowered = line.casefold()
                male_score += len(re.findall(r"\b(?:he|him|his|himself)\b", lowered))
                female_score += len(re.findall(r"\b(?:she|her|hers|herself)\b", lowered))
                if re.search(r"\b(?:gender|sex)\s*[:=]\s*(?:male|m)\b", lowered):
                    male_score += 3
                if re.search(r"\b(?:gender|sex)\s*[:=]\s*(?:female|f)\b", lowered):
                    female_score += 3

            if male_score > female_score:
                gender_map[canonical] = "male"
            elif female_score > male_score:
                gender_map[canonical] = "female"
            else:
                gender_map[canonical] = None
        return expanded, gender_map

    @staticmethod
    def _deduplicate_and_resolve_overlaps(detections: list[Detection]) -> list[Detection]:
        unique: dict[tuple[int, int, str, str], Detection] = {}
        for detection in detections:
            key = (detection.start, detection.end, detection.kind, detection.canonical)
            existing = unique.get(key)
            if existing is None or detection.rule.priority > existing.rule.priority:
                unique[key] = detection

        # Split the interval set into small connected overlap clusters. This avoids
        # comparing every detection with every other detection on large logs.
        by_position = sorted(unique.values(), key=lambda d: (d.start, d.end))
        clusters: list[list[Detection]] = []
        current: list[Detection] = []
        current_end = -1
        for detection in by_position:
            if current and detection.start >= current_end:
                clusters.append(current)
                current = []
                current_end = -1
            current.append(detection)
            current_end = max(current_end, detection.end)
        if current:
            clusters.append(current)

        selected: list[Detection] = []
        for cluster in clusters:
            if len(cluster) == 1:
                selected.append(cluster[0])
                continue
            winners: list[Detection] = []
            for candidate in sorted(
                cluster,
                key=lambda d: (-d.rule.priority, -(d.end - d.start), d.start, d.end),
            ):
                if any(candidate.start < other.end and other.start < candidate.end for other in winners):
                    continue
                winners.append(candidate)
            selected.extend(winners)
        return sorted(selected, key=lambda d: (d.start, d.end))

    def scrub(
        self,
        text: str,
        *,
        mode: str = "synthetic",
        seed: str | None = None,
        include_preamble: bool = True,
        pretty_print: bool = False,
        known_names_path: Path | None = None,
        known_names: Iterable[str] | None = None,
    ) -> ScrubResult:
        if mode not in {"synthetic", "redact"}:
            raise ValueError("mode must be 'synthetic' or 'redact'")
        effective_seed = seed.strip() if seed and seed.strip() else secrets.token_hex(8)
        combined_names = [*(known_names or []), *self._read_known_names(known_names_path)]

        detections = self._initial_detections(text, combined_names)
        detections, gender_map = self._expand_names_and_infer_gender(text, detections)
        detections = self._annotate_geography(text, detections)
        detections = self._deduplicate_and_resolve_overlaps(detections)

        grouped: dict[GroupKey, list[Detection]] = defaultdict(list)
        first_position: dict[GroupKey, int] = {}
        for detection in detections:
            country = str(detection.metadata.get("country_code", ""))
            key = (detection.kind, detection.canonical, country)
            grouped[key].append(detection)
            first_position.setdefault(key, detection.start)

        replacements: dict[GroupKey, SyntheticValue | str] = {}
        metadata_by_key: dict[GroupKey, dict[str, Any]] = {}
        used_generated: dict[str, set[str]] = defaultdict(set)

        keys_by_generation = sorted(grouped)
        placeholder_order = sorted(grouped, key=lambda key: first_position[key])
        placeholder_number = {key: index for index, key in enumerate(placeholder_order, start=1)}

        for key in keys_by_generation:
            kind, canonical, country = key
            representative = grouped[key][0]
            metadata: dict[str, Any] = dict(representative.metadata)
            if kind == "NAME" and gender_map.get(canonical):
                metadata["gender"] = str(gender_map[canonical])
            metadata_by_key[key] = metadata

            if mode == "redact":
                replacements[key] = f"[{kind}_{placeholder_number[key]}]"
                continue

            for attempt in range(100):
                seeded_canonical = canonical + (f"\0country={country}" if country else "")
                value_seed = self._stable_seed(effective_seed, kind, seeded_canonical, attempt)
                rng = Random(value_seed)
                locale = faker_locale_for_country(country) if kind in _ADDRESS_KINDS else "en_GB"
                faker = Faker(locale)
                faker.seed_instance(value_seed)
                generated = representative.rule.replacement_fn(representative.real, rng, faker, metadata)
                rendered_candidate = representative.rule.renderer(generated, representative.real)
                generated_key = representative.rule.canonicalizer(rendered_candidate)
                if generated_key == canonical:
                    continue
                if generated_key in used_generated[kind]:
                    continue
                replacements[key] = generated
                used_generated[kind].add(generated_key)
                break
            else:
                raise RuntimeError(f"Unable to generate a unique replacement for {kind}")

        # Preserve the direct-debit relationship in a UK IBAN when the same source
        # sort code and/or account number also appeared as separately detected fields.
        # Without this, an LLM could incorrectly report that the synthetic fields disagree.
        if mode == "synthetic":
            for key, occurrences in grouped.items():
                kind, _canonical, _country = key
                if kind != "IBAN":
                    continue
                real_compact = alnum_only(occurrences[0].real).upper()
                if len(real_compact) != 22 or not real_compact.startswith("GB"):
                    continue

                source_sort = real_compact[8:14]
                source_account = real_compact[14:22]
                sort_key = next(
                    (candidate for candidate in replacements if candidate[0] == "SORT_CODE" and candidate[1] == source_sort),
                    None,
                )
                account_key = next(
                    (
                        candidate
                        for candidate in replacements
                        if candidate[0] == "ACCOUNT_NUMBER" and candidate[1] == source_account
                    ),
                    None,
                )
                sort_replacement = replacements.get(sort_key) if sort_key else None
                account_replacement = replacements.get(account_key) if account_key else None
                current = replacements.get(key)
                if not isinstance(current, SyntheticValue):
                    continue

                fake_sort = sort_replacement.base if isinstance(sort_replacement, SyntheticValue) else None
                fake_account = (
                    account_replacement.base if isinstance(account_replacement, SyntheticValue) else None
                )
                if fake_sort is None and fake_account is None:
                    continue
                replacements[key] = rebuild_uk_iban(
                    current,
                    sort_code=fake_sort,
                    account_number=fake_account,
                )
                metadata_by_key[key]["linked_uk_routing_fields"] = "yes"

        chunks: list[str] = []
        cursor = 0
        rendered_by_key: dict[GroupKey, list[str]] = defaultdict(list)
        for detection in detections:
            chunks.append(text[cursor : detection.start])
            country = str(detection.metadata.get("country_code", ""))
            key = (detection.kind, detection.canonical, country)
            replacement = replacements[key]
            if isinstance(replacement, str):
                rendered = replacement
            else:
                rendered = detection.rule.renderer(replacement, detection.real)
            chunks.append(rendered)
            if rendered not in rendered_by_key[key]:
                rendered_by_key[key].append(rendered)
            cursor = detection.end
        chunks.append(text[cursor:])
        scrubbed = "".join(chunks)

        format_name = "plain"
        if pretty_print:
            formatted = pretty_print_log(scrubbed)
            scrubbed = formatted.text
            format_name = formatted.format_name

        if include_preamble:
            preamble = SYNTHETIC_PREAMBLE if mode == "synthetic" else REDACT_PREAMBLE
            scrubbed = preamble + "\n\n--- SCRUBBED LOG ---\n" + scrubbed

        mapping_entries: list[MappingEntry] = []
        for key in placeholder_order:
            kind, canonical, _country = key
            occurrences = grouped[key]
            replacement = replacements[key]
            if isinstance(replacement, str):
                fake_display = replacement
            else:
                fake_display = occurrences[0].rule.renderer(replacement, occurrences[0].real)
            mapping_entries.append(
                MappingEntry(
                    kind=kind,
                    fake=fake_display,
                    real=occurrences[0].real,
                    canonical_real=canonical,
                    occurrences=len(occurrences),
                    rendered_fakes=rendered_by_key[key],
                    metadata=metadata_by_key[key],
                )
            )

        stats: dict[str, int] = defaultdict(int)
        for detection in detections:
            stats[detection.kind] += 1
        stats["TOTAL"] = len(detections)
        stats["UNIQUE"] = len(grouped)
        return ScrubResult(
            text=scrubbed,
            mapping=mapping_entries,
            effective_seed=effective_seed,
            stats=dict(stats),
            format_name=format_name,
            syntax_spans=syntax_spans(scrubbed, format_name) if pretty_print else [],
        )
